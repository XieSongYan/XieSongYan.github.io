# Three-conics factor-three Key Vanishing verification

This directory is the reproducible evidence stage for the strengthened
Key Vanishing Lemma II used after the restricted zero-locus coefficient is
corrected from `2` to `3`.  The computation proves all eighteen finite
targets required for the SMT constant `5`:

```
(3,2), (4,3), (5,3), (6,4), (7,4), (8,5), (9,5),
(10,6), (11,6), (12,7), (13,7), (14,8), (15,8),
(16,9), (17,9), (18,10), (19,10), (21,11).
```

Every listed matrix has full column rank over `F_5`.  The hardest case is
`(m,t)=(21,11)`, with `81,840` columns and exact rank `81,840`.

## Exact map computed

Use either affine chart `T=1` or `Y=1`, and set

```
H     = A B C,
L1hat = B(C dA-A dC),
L2hat = A(C dB-B dC),
D     = det(A,B,C; d_1 A,d_1 B,d_1 C; d_2 A,d_2 B,d_2 C).
```

For the standard affine Wronskian `W=x'y''-x''y'`, direct differentiation
gives

```
H^3 Wbar = H^2 D W + H R3,
```

where `R3` is the cubic first-jet part of
`L1hat*d(L2hat)-L2hat*d(L1hat)`.  The program constructs `R3` from this
definition and directly checks the identity at 36 nonsingular jets on each
chart.

For a source coefficient in Wronskian layer `q`, put

```
n_q = m-2q,  s_q = m-3q,  deg(P_qij)=3n_q-t,  i+j=s_q.
```

After putting the coefficient of `W^k` over the common denominator
`H^(m-2k) J^(m-2k)`, its exact numerator contribution is

```
binom(q,k) P_qij L1hat^i L2hat^j D^k (H J^2 R3)^(q-k),  q >= k.
```

Here the homogeneous Jacobian is `J=32TXY`; on the two charts it is
`32xy` and `32tx`.  The program retains these constants modulo `5`.
For each fixed `k` and velocity monomial, contributions from **all**
`q>=k` are summed before divisibility by `J^(m-2k)` is imposed.  Thus the
matrices are the full coupled matrices, not diagonal-layer probes.

The Fermat conics are

```
A=2T^2+X^2+Y^2,
B=T^2+2X^2+Y^2,
C=T^2+X^2+2Y^2.
```

Divisibility is checked on `T=1` and `Y=1`; these charts test all three
coordinate components of `J=0`, while Hartogs extension handles their
pairwise intersection points.  No parity split, character decomposition,
involution, root-of-unity filter, or symmetry method from later papers is
used.

## Why one good prime proves the characteristic-zero statement

The transition matrix has integer entries.  Full column rank after reduction
modulo `5` exhibits a maximal minor whose determinant is nonzero modulo `5`.
That integer determinant is therefore nonzero over `Q`, so the original
matrix has full column rank over `Q` and hence over `C`.  Consequently the
kernel defining the negatively twisted logarithmic jet differential space is
zero.

## Build and run

From the root of this stage, with a C++17 compiler:

```
clang++ -std=c++17 -O3 -DNDEBUG -static \
  source/paper1_three_conics_full_verifier.cpp \
  -o bin/paper1_three_conics_full_verifier.exe

bin/paper1_three_conics_full_verifier.exe --self-test

bin/paper1_three_conics_full_verifier.exe --case 21 11 \
  --max-seconds 3600 \
  --max-pivot-nonzeros 650000000 \
  --certificate certificates/recheck_m21_t11_p5.json
```

Exit code `0` together with verdict
`PROVED_FULL_COLUMN_RANK_MOD_5` means that every expected column was
processed and the exact nullity is zero.  A timeout or memory guard produces
`UNRESOLVED_RESOURCE_LIMIT`; it is never reported as a vanishing proof.

## Evidence layout

- `source/`: auditable C++17 source.
- `bin/`: the exact Windows executable used for the final self-tested run.
- `certificates/`: JSON certificates for the eighteen required targets and
  the old Maple cross-check `(7,5)`.
- `logs/`: complete progress/result logs and the self-test log.
- `reports/CASE_SUMMARY.tsv`: compact machine-readable summary.
- `reports/COMPUTATION_REPORT.md`: mathematical and runtime report.
- `SHA256SUMS.txt`: SHA-256 digest of every staged file except the manifest
  itself.

The JSON pivot lists and FNV fingerprints are reproducibility aids, not
stand-alone determinant certificates.  The proof object is the exact
source together with a successful deterministic rerun.  The old Maple case
`(7,5)` is included as a full-coupling structural cross-check: lower
Wronskian blocks are genuinely needed to recover missing diagonal pivots.
