# Computation report

## Outcome

All eighteen factor-three Key Vanishing Lemma II targets have been proved by
exact, unsplit rank computations over `F_5`.  Every result has nullity zero.
The final target `(21,11)` completed locally with rank `81,840/81,840`.

The source first checks the homogeneous-variable counts

```
variables(m,t) = sum_q (m-3q+1) binom(3(m-2q)-t+2,2),
```

including the published old count `variables(13,9)=12,550`, the Maple
cross-check count `variables(7,5)=1,584`, and the new largest count
`variables(21,11)=81,840`.  It also verifies
`det(L1hat,L2hat)=H D` symbolically modulo `5` on both charts and compares the
logarithmic-Wronskian identity with direct first/second differentiation at
36 nonsingular jets per chart.

An independent code audit found no defect in the `q -> k` common-denominator
formula, chart substitutions, velocity indexing, divisibility criterion, or
sparse exact rank logic.  In the old Maple cross-check `(7,5)`, the diagonal
`q=1` block supplies only `329/330` pivots and the diagonal `q=2` block only
`21/30`; respectively one and nine pivots are recovered from lower
Wronskian coefficients.  This confirms that the saved run exercises the
full coupling rather than merely repeating the diagonal probe.  These two
diagonal-only ranks are diagnostic observations rather than proof inputs;
the archived proof certificates concern the complete coupled matrix.

## Host and toolchain

- Host: Microsoft Surface Pro, Windows 11, ARM64.
- Processor: Qualcomm Snapdragon X2 Elite class, 12 logical processors.
- Installed memory: approximately 31.5 GiB; storage approximately 1 TB.
- Compiler: LLVM/Clang 22.1.8, target `x86_64-w64-windows-gnu`.
- Execution note: the x86-64 static executable ran under Windows emulation on
  the ARM64 host.

The process monitor sampled approximately 17 GiB of private memory during
`(21,11)`.  The raw monitoring transcript was not retained, so this figure is
an engineering observation rather than certificate data.  The programmed
limits for that run were 3,600 seconds, four million
entries in any reduced column, and 650 million stored pivot nonzeros.  None
of the limits was reached.

## Largest runs

```
(m,t)     columns/rank       build (s)   elimination (s)   pivot nonzeros
(18,10)   45,360/45,360          2.973          241.277       191,208,552
(19,10)   56,721/56,721          4.967        1,129.583       284,998,941
(21,11)   81,840/81,840         20.250        1,925.209       572,699,685
```

Times are wall-clock measurements written by the executable.  They should
be viewed as reproducibility data, not benchmark claims.

## Logical conclusion

For every required `(m,t)`, the integral transition matrix has a maximal
minor nonzero modulo `5`.  Therefore the same minor is nonzero over `Q`, and
the characteristic-zero matrix has full column rank.  The corresponding
space of negatively twisted logarithmic invariant two-jet differentials is
zero for the chosen Fermat three-conic configuration.  Upper
semicontinuity then supplies the generic vanishing used in the manuscript.

No later symmetry, sign-character, root-of-unity, or involution method is
part of this verification.
