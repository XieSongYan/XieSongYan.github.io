// Exact, symmetry-free F_5 verifier for the full coupled transition matrix
// in the three-Fermat-conics Key Vanishing computation.
//
// Mathematical model.  On either affine chart put H=A*B*C and
//
//   L1hat = B(C dA-A dC),       L2hat = A(C dB-B dC).
//
// If W is the standard affine Wronskian and Wbar the logarithmic one, then
//
//   H^3 Wbar = H^2 D W + H R3,
//
// where D=det(A,B,C; d_1 A,d_1 B,d_1 C; d_2 A,d_2 B,d_2 C), and R3 is the
// cubic (first-jet) part of L1hat*d(L2hat)-L2hat*d(L1hat).  Hence, after
// putting every contribution to the coefficient of W^k over the common
// denominator H^(m-2k) J^(m-2k), a source coefficient in Wbar-layer q
// contributes
//
//   binom(q,k) P L1hat^i L2hat^j D^k
//       * (H J^2 R3)^(q-k),                  0 <= k <= q.
//
// Regularity away from ABC=0 is equivalent to divisibility of this summed
// numerator by J^(m-2k).  We impose the divisibility simultaneously on the
// charts T=1 and Y=1.  The actual constants J=32XY (or 32TX) and D are
// retained modulo 5, so the q-dependent units are not discarded.
//
// No parity, character, involution, or root-of-unity decomposition is used.

#include <algorithm>
#include <array>
#include <chrono>
#include <cstdint>
#include <cstdlib>
#include <fstream>
#include <iomanip>
#include <iostream>
#include <limits>
#include <sstream>
#include <stdexcept>
#include <string>
#include <unordered_map>
#include <utility>
#include <vector>

namespace {

constexpr int PRIME = 5;
using Clock = std::chrono::steady_clock;
using Row = std::uint64_t;

std::uint8_t mod5(long long x) {
    x %= PRIME;
    if (x < 0) x += PRIME;
    return static_cast<std::uint8_t>(x);
}

std::uint8_t inv5(std::uint8_t x) {
    static const std::uint8_t inv[5] = {0, 1, 3, 2, 4};
    if (!x) throw std::runtime_error("attempted inversion of zero");
    return inv[x];
}

struct Monomial {
    std::uint16_t a = 0; // first affine base exponent
    std::uint16_t b = 0; // second affine base exponent
    std::uint8_t v = 0;  // exponent of first velocity

    bool operator<(const Monomial& o) const {
        if (v != o.v) return v < o.v;
        if (a != o.a) return a < o.a;
        return b < o.b;
    }
    bool operator==(const Monomial& o) const {
        return a == o.a && b == o.b && v == o.v;
    }
};

std::uint64_t poly_key(int a, int b, int v) {
    if (a < 0 || a > 65535 || b < 0 || b > 65535 || v < 0 || v > 255)
        throw std::runtime_error("polynomial exponent overflow");
    return static_cast<std::uint64_t>(a)
         | (static_cast<std::uint64_t>(b) << 16)
         | (static_cast<std::uint64_t>(v) << 32);
}

Monomial unpack_poly(std::uint64_t z) {
    return Monomial{static_cast<std::uint16_t>(z & 0xffffu),
                    static_cast<std::uint16_t>((z >> 16) & 0xffffu),
                    static_cast<std::uint8_t>((z >> 32) & 0xffu)};
}

struct Term {
    Monomial m;
    std::uint8_t c = 0;
};
using Poly = std::vector<Term>;

Poly canonical(std::unordered_map<std::uint64_t, std::uint8_t>& acc) {
    Poly out;
    out.reserve(acc.size());
    for (const auto& z : acc) if (z.second) out.push_back({unpack_poly(z.first), z.second});
    std::sort(out.begin(), out.end(), [](const Term& x, const Term& y) {
        return x.m < y.m;
    });
    return out;
}

Poly make_poly(std::initializer_list<std::array<int,4>> data) {
    std::unordered_map<std::uint64_t, std::uint8_t> acc;
    for (const auto& z : data) {
        const auto key = poly_key(z[0], z[1], z[2]);
        acc[key] = mod5(acc[key] + z[3]);
    }
    return canonical(acc);
}

Poly scaled(const Poly& p, int c) {
    const auto z = mod5(c);
    if (!z) return {};
    Poly out = p;
    for (auto& e : out) e.c = mod5(e.c * z);
    return out;
}

Poly add_poly(const Poly& p, const Poly& q, int qscale = 1) {
    std::unordered_map<std::uint64_t, std::uint8_t> acc;
    acc.reserve(p.size() + q.size() + 1);
    for (const auto& e : p) acc[poly_key(e.m.a,e.m.b,e.m.v)] = e.c;
    const auto z = mod5(qscale);
    for (const auto& e : q) {
        const auto key = poly_key(e.m.a,e.m.b,e.m.v);
        acc[key] = mod5(acc[key] + z * e.c);
    }
    return canonical(acc);
}

Poly multiply(const Poly& p, const Poly& q) {
    if (p.empty() || q.empty()) return {};
    std::unordered_map<std::uint64_t, std::uint8_t> acc;
    const std::size_t hint = p.size() * std::min<std::size_t>(q.size(), 64);
    acc.reserve(std::min<std::size_t>(hint * 2 + 1, 4000000));
    for (const auto& x : p) for (const auto& y : q) {
        const auto key = poly_key(x.m.a + y.m.a, x.m.b + y.m.b,
                                  x.m.v + y.m.v);
        acc[key] = mod5(acc[key] + x.c * y.c);
    }
    return canonical(acc);
}

std::vector<Poly> powers(const Poly& p, int n) {
    std::vector<Poly> ans(static_cast<std::size_t>(n + 1));
    ans[0] = make_poly({{0,0,0,1}});
    for (int i = 1; i <= n; ++i) ans[i] = multiply(ans[i-1], p);
    return ans;
}

Poly derivative_base(const Poly& p, int which) {
    std::unordered_map<std::uint64_t, std::uint8_t> acc;
    acc.reserve(p.size());
    for (const auto& e : p) {
        const int exponent = which == 0 ? e.m.a : e.m.b;
        if (!exponent) continue;
        const int a = e.m.a - (which == 0 ? 1 : 0);
        const int b = e.m.b - (which == 1 ? 1 : 0);
        const auto key = poly_key(a,b,e.m.v);
        acc[key] = mod5(acc[key] + exponent * e.c);
    }
    return canonical(acc);
}

// Horizontal derivative along a curve: d_h p = p_a u + p_b v.  The input
// has a fixed total first-jet degree; v records only the u-exponent.
Poly horizontal_derivative(const Poly& p) {
    std::unordered_map<std::uint64_t, std::uint8_t> acc;
    acc.reserve(p.size() * 2 + 1);
    for (const auto& e : p) {
        if (e.m.a) {
            const auto key = poly_key(e.m.a - 1, e.m.b, e.m.v + 1);
            acc[key] = mod5(acc[key] + e.m.a * e.c);
        }
        if (e.m.b) {
            const auto key = poly_key(e.m.a, e.m.b - 1, e.m.v);
            acc[key] = mod5(acc[key] + e.m.b * e.c);
        }
    }
    return canonical(acc);
}

bool equal_poly(const Poly& p, const Poly& q) {
    if (p.size() != q.size()) return false;
    for (std::size_t i = 0; i < p.size(); ++i)
        if (!(p[i].m == q[i].m) || p[i].c != q[i].c) return false;
    return true;
}

int pow5(int x,int n) {
    int z=1;
    x=mod5(x);
    while(n>0) {
        if(n&1) z=mod5(z*x);
        x=mod5(x*x);
        n>>=1;
    }
    return z;
}

int evaluate_fixed_velocity_degree(const Poly& p,int total_velocity_degree,
                                   int a,int b,int u,int v) {
    int z=0;
    for(const auto& e:p) {
        if(e.m.v>total_velocity_degree)
            throw std::runtime_error("invalid fixed velocity degree in evaluation");
        z=mod5(z + e.c*pow5(a,e.m.a)*pow5(b,e.m.b)
                       *pow5(u,e.m.v)*pow5(v,total_velocity_degree-e.m.v));
    }
    return z;
}

int quotient5(int numerator,int denominator) {
    return mod5(numerator*inv5(mod5(denominator)));
}

Poly determinant3(const Poly& A, const Poly& B, const Poly& C) {
    const auto Aa = derivative_base(A,0), Ab = derivative_base(A,1);
    const auto Ba = derivative_base(B,0), Bb = derivative_base(B,1);
    const auto Ca = derivative_base(C,0), Cb = derivative_base(C,1);
    Poly z = multiply(A, add_poly(multiply(Ba,Cb), multiply(Bb,Ca), -1));
    z = add_poly(z, multiply(B, add_poly(multiply(Aa,Cb), multiply(Ab,Ca), -1)), -1);
    z = add_poly(z, multiply(C, add_poly(multiply(Aa,Bb), multiply(Ab,Ba), -1)));
    return z;
}

Poly velocity_coefficient(const Poly& p, int vexp) {
    Poly z;
    for (const auto& e : p) if (e.m.v == vexp) z.push_back({{e.m.a,e.m.b,0},e.c});
    return z;
}

struct ChartData {
    std::string name;
    Poly A, B, C, H, J, D, L1, L2, R3, G;
};

ChartData make_chart(const std::string& name, const Poly& A,
                     const Poly& B, const Poly& C) {
    ChartData z;
    z.name = name;
    z.A = A; z.B = B; z.C = C;
    z.H = multiply(multiply(A,B),C);
    z.J = make_poly({{1,1,0,32}}); // actual homogeneous Jacobian on both charts
    z.D = determinant3(A,B,C);

    const Poly dA = horizontal_derivative(A);
    const Poly dB = horizontal_derivative(B);
    const Poly dC = horizontal_derivative(C);
    const Poly Nu = add_poly(multiply(C,dA),multiply(A,dC),-1);
    const Poly Nv = add_poly(multiply(C,dB),multiply(B,dC),-1);
    z.L1 = multiply(B,Nu);
    z.L2 = multiply(A,Nv);
    z.R3 = add_poly(multiply(z.L1,horizontal_derivative(z.L2)),
                     multiply(z.L2,horizontal_derivative(z.L1)),-1);
    z.G = multiply(multiply(z.H,multiply(z.J,z.J)),z.R3);

    // det(coeff(L1),coeff(L2)) = H D checks the W coefficient and sign.
    const Poly p = velocity_coefficient(z.L1,1);
    const Poly q = velocity_coefficient(z.L1,0);
    const Poly r = velocity_coefficient(z.L2,1);
    const Poly s = velocity_coefficient(z.L2,0);
    const Poly detL = add_poly(multiply(p,s),multiply(q,r),-1);
    if (!equal_poly(detL,multiply(z.H,z.D)))
        throw std::runtime_error("failed det(L1hat,L2hat)=H*D in chart " + name);
    return z;
}

ChartData chart_T1() {
    return make_chart(
        "T=1",
        make_poly({{0,0,0,2},{2,0,0,1},{0,2,0,1}}),
        make_poly({{0,0,0,1},{2,0,0,2},{0,2,0,1}}),
        make_poly({{0,0,0,1},{2,0,0,1},{0,2,0,2}}));
}

ChartData chart_Y1() {
    return make_chart(
        "Y=1",
        make_poly({{0,0,0,1},{2,0,0,2},{0,2,0,1}}),
        make_poly({{0,0,0,1},{2,0,0,1},{0,2,0,2}}),
        make_poly({{0,0,0,2},{2,0,0,1},{0,2,0,1}}));
}

int binom_mod5(int n, int k) {
    if (k < 0 || k > n) return 0;
    long long z = 1;
    for (int j = 1; j <= k; ++j) z = z * (n-k+j) / j;
    return mod5(z);
}

struct HomMon { int t = 0, x = 0, y = 0; };

std::vector<HomMon> homogeneous_monomials(int d) {
    std::vector<HomMon> z;
    if (d < 0) return z;
    z.reserve(static_cast<std::size_t>((d+1)*(d+2)/2));
    for (int t = 0; t <= d; ++t)
        for (int x = 0; x <= d-t; ++x) z.push_back({t,x,d-t-x});
    return z;
}

long long choose2(int d) { return d < 0 ? 0LL : 1LL*(d+1)*(d+2)/2; }

long long variable_count(int m, int t) {
    long long z = 0;
    for (int q = 0; q <= m/3; ++q) {
        const int s = m-3*q, d = 3*(m-2*q)-t;
        z += 1LL*(s+1)*choose2(d);
    }
    return z;
}

struct FactorTable {
    // factor[q][i][k], with i the L1 exponent and s-i the L2 exponent.
    std::vector<std::vector<std::vector<Poly>>> factor;
    std::vector<std::vector<std::vector<std::size_t>>> supports;
};

FactorTable build_factors(const ChartData& c, int m) {
    const int Q = m/3;
    const auto pL1 = powers(c.L1,m);
    const auto pL2 = powers(c.L2,m);
    const auto pD = powers(c.D,Q);
    const auto pG = powers(c.G,Q);
    FactorTable table;
    table.factor.resize(Q+1);
    table.supports.resize(Q+1);
    for (int q = 0; q <= Q; ++q) {
        const int s = m-3*q;
        table.factor[q].resize(s+1);
        table.supports[q].resize(s+1);
        for (int i = 0; i <= s; ++i) {
            const Poly L = multiply(pL1[i],pL2[s-i]);
            table.factor[q][i].resize(q+1);
            table.supports[q][i].resize(q+1);
            for (int k = 0; k <= q; ++k) {
                const int bin = binom_mod5(q,k);
                if (!bin) continue;
                Poly f = multiply(multiply(L,pD[k]),pG[q-k]);
                if (bin != 1) f = scaled(f,bin);
                table.supports[q][i][k] = f.size();
                table.factor[q][i][k] = std::move(f);
            }
        }
    }
    return table;
}

// Higher W-powers are ordered first.  Within a W-block, low normal order is
// ordered first to keep the sparse elimination close to the block-triangular
// mathematical structure.  The key remains injective on the checked bounds.
Row row_key(int Q, int chart, int k, int vel, int a, int b) {
    if (Q-k < 0 || Q-k > 15 || chart < 0 || chart > 1 || vel < 0 || vel > 127
        || a < 0 || a > 1048575 || b < 0 || b > 1048575)
        throw std::runtime_error("row exponent overflow");
    const int low = std::min(a,b);
    if (low > 255) throw std::runtime_error("normal order overflow");
    return (static_cast<Row>(Q-k) << 60)
         | (static_cast<Row>(low) << 52)
         | (static_cast<Row>(chart) << 51)
         | (static_cast<Row>(vel) << 44)
         | (static_cast<Row>(a) << 22)
         | static_cast<Row>(b);
}

using Sparse = std::vector<std::pair<Row,std::uint8_t>>;

Sparse add_scaled(const Sparse& a, const Sparse& b, std::uint8_t scale) {
    // a - scale*b over F_5; both vectors are sorted by row.
    Sparse z;
    z.reserve(a.size()+b.size());
    std::size_t i=0,j=0;
    while (i<a.size() || j<b.size()) {
        if (j==b.size() || (i<a.size() && a[i].first<b[j].first)) z.push_back(a[i++]);
        else if (i==a.size() || b[j].first<a[i].first) {
            const auto c=mod5(-static_cast<int>(scale)*b[j].second);
            if (c) z.push_back({b[j].first,c});
            ++j;
        } else {
            const auto c=mod5(a[i].second-static_cast<int>(scale)*b[j].second);
            if (c) z.push_back({a[i].first,c});
            ++i; ++j;
        }
    }
    return z;
}

std::uint64_t fnv_update(std::uint64_t h, std::uint64_t x) {
    constexpr std::uint64_t prime = 1099511628211ULL;
    for (int j=0;j<8;++j) {
        h ^= static_cast<std::uint8_t>(x & 0xffu);
        h *= prime;
        x >>= 8;
    }
    return h;
}

Sparse build_column(int m, int q, int i, const HomMon& h,
                    const FactorTable& fT, const FactorTable& fY) {
    const int Q=m/3;
    Sparse out;
    auto append = [&](int chart, const FactorTable& ft, int da, int db) {
        for (int k=0;k<=q;++k) {
            const int n=m-2*k;
            const auto& p=ft.factor[q][i][k];
            for (const auto& e:p) {
                const int a=e.m.a+da, b=e.m.b+db;
                if (a>=n && b>=n) continue;
                out.push_back({row_key(Q,chart,k,e.m.v,a,b),e.c});
            }
        }
    };
    append(0,fT,h.x,h.y); // T=1
    append(1,fY,h.t,h.x); // Y=1
    std::sort(out.begin(),out.end(),[](const auto& x,const auto& y){return x.first<y.first;});
    // Key injectivity implies no duplicate, but combine defensively.
    Sparse clean;
    clean.reserve(out.size());
    for (const auto& e:out) {
        if (!clean.empty() && clean.back().first==e.first) {
            clean.back().second=mod5(clean.back().second+e.second);
            if (!clean.back().second) clean.pop_back();
        } else if (e.second) clean.push_back(e);
    }
    return clean;
}

struct Limits {
    double max_seconds=0;                 // 0 means unlimited
    std::size_t max_support=4000000;
    std::uint64_t max_pivot_nonzeros=250000000ULL;
};

struct RankResult {
    std::size_t columns=0, rank=0, zero_columns=0, peak_support=0;
    std::uint64_t pivot_nonzeros=0;
    bool completed=true;
    std::string stop_reason;
    double build_seconds=0, elimination_seconds=0;
    std::uint64_t raw_hash=1469598103934665603ULL;
    std::uint64_t echelon_hash=1469598103934665603ULL;
    std::vector<Row> pivot_rows;
    std::vector<long long> layer_columns;
};

std::string hex64(std::uint64_t z) {
    std::ostringstream out;
    out << std::hex << std::setw(16) << std::setfill('0') << z;
    return out.str();
}

RankResult rank_full_case(int m,int t,const Limits& lim) {
    RankResult result;
    const int Q=m/3;
    result.layer_columns.assign(Q+1,0);
    const auto overall=Clock::now();

    const ChartData T=chart_T1(), Y=chart_Y1();
    const FactorTable fT=build_factors(T,m), fY=build_factors(Y,m);
    result.build_seconds=std::chrono::duration<double>(Clock::now()-overall).count();

    std::unordered_map<Row,std::size_t> pivot_index;
    pivot_index.reserve(static_cast<std::size_t>(variable_count(m,t)*1.3)+1);
    std::vector<Sparse> pivots;
    pivots.reserve(static_cast<std::size_t>(variable_count(m,t)));
    const auto elimination_start=Clock::now();

    for(int q=0;q<=Q && result.completed;++q) {
        const int s=m-3*q,d=3*(m-2*q)-t;
        const auto hm=homogeneous_monomials(d);
        for(int i=0;i<=s && result.completed;++i) for(const auto& h:hm) {
            ++result.columns;
            ++result.layer_columns[q];
            Sparse col=build_column(m,q,i,h,fT,fY);
            result.raw_hash=fnv_update(result.raw_hash,static_cast<std::uint64_t>(q));
            result.raw_hash=fnv_update(result.raw_hash,static_cast<std::uint64_t>(i));
            result.raw_hash=fnv_update(result.raw_hash,static_cast<std::uint64_t>(h.t));
            result.raw_hash=fnv_update(result.raw_hash,static_cast<std::uint64_t>(h.x));
            result.raw_hash=fnv_update(result.raw_hash,static_cast<std::uint64_t>(h.y));
            for(const auto& e:col) {
                result.raw_hash=fnv_update(result.raw_hash,e.first);
                result.raw_hash=fnv_update(result.raw_hash,e.second);
            }
            if(col.empty()) { ++result.zero_columns; continue; }
            while(!col.empty()) {
                result.peak_support=std::max(result.peak_support,col.size());
                if(col.size()>lim.max_support) {
                    result.completed=false;
                    result.stop_reason="column_support_limit";
                    break;
                }
                auto p=pivot_index.find(col.front().first);
                if(p==pivot_index.end()) {
                    const auto z=inv5(col.front().second);
                    if(z!=1) for(auto& e:col)e.second=mod5(e.second*z);
                    if(result.pivot_nonzeros+col.size()>lim.max_pivot_nonzeros) {
                        result.completed=false;
                        result.stop_reason="pivot_memory_guard";
                        break;
                    }
                    const Row prow=col.front().first;
                    const std::size_t index=pivots.size();
                    result.pivot_nonzeros+=col.size();
                    result.echelon_hash=fnv_update(result.echelon_hash,prow);
                    result.echelon_hash=fnv_update(result.echelon_hash,col.size());
                    for(const auto& e:col) {
                        result.echelon_hash=fnv_update(result.echelon_hash,e.first);
                        result.echelon_hash=fnv_update(result.echelon_hash,e.second);
                    }
                    pivot_index.emplace(prow,index);
                    result.pivot_rows.push_back(prow);
                    pivots.push_back(std::move(col));
                    ++result.rank;
                    break;
                }
                col=add_scaled(col,pivots[p->second],col.front().second);
            }
            const double elapsed=std::chrono::duration<double>(Clock::now()-overall).count();
            if(result.completed && lim.max_seconds>0 && elapsed>lim.max_seconds) {
                result.completed=false;
                result.stop_reason="wall_time_limit";
            }
            if(result.columns%250==0 || !result.completed) {
                std::cerr << "PROGRESS columns=" << result.columns
                          << " rank=" << result.rank
                          << " q=" << q
                          << " pivot_nonzeros=" << result.pivot_nonzeros
                          << " peak_support=" << result.peak_support
                          << " seconds=" << std::fixed << std::setprecision(3) << elapsed
                          << "\n";
            }
        }
    }
    result.elimination_seconds=std::chrono::duration<double>(Clock::now()-elimination_start).count();
    return result;
}

std::string verdict(const RankResult& r,long long expected) {
    if(!r.completed) return "UNRESOLVED_RESOURCE_LIMIT";
    if(static_cast<long long>(r.columns)!=expected) return "INTERNAL_ENUMERATION_ERROR";
    if(r.rank==r.columns) return "PROVED_FULL_COLUMN_RANK_MOD_5";
    return "NOT_PROVED_RANK_DEFICIENT_MOD_5";
}

void write_certificate(const std::string& path,int m,int t,const Limits& lim,
                       const RankResult& r) {
    if(path.empty()) return;
    std::ofstream out(path,std::ios::binary);
    if(!out) throw std::runtime_error("cannot write certificate: "+path);
    const long long expected=variable_count(m,t);
    out << "{\n"
        << "  \"schema\": \"paper1-three-conics-full-rank-v1\",\n"
        << "  \"field_prime\": 5,\n"
        << "  \"symmetry_decomposition\": false,\n"
        << "  \"charts\": [\"T=1\", \"Y=1\"],\n"
        << "  \"fermat_conics\": [\"2T^2+X^2+Y^2\", \"T^2+2X^2+Y^2\", \"T^2+X^2+2Y^2\"],\n"
        << "  \"jacobian\": \"32*T*X*Y\",\n"
        << "  \"m\": " << m << ",\n"
        << "  \"t\": " << t << ",\n"
        << "  \"expected_columns\": " << expected << ",\n"
        << "  \"processed_columns\": " << r.columns << ",\n"
        << "  \"rank\": " << r.rank << ",\n"
        << "  \"nullity_if_completed\": " << (r.completed ? r.columns-r.rank : 0) << ",\n"
        << "  \"completed\": " << (r.completed?"true":"false") << ",\n"
        << "  \"stop_reason\": \"" << r.stop_reason << "\",\n"
        << "  \"verdict\": \"" << verdict(r,expected) << "\",\n"
        << "  \"raw_matrix_fnv1a64\": \"" << hex64(r.raw_hash) << "\",\n"
        << "  \"echelon_fnv1a64\": \"" << hex64(r.echelon_hash) << "\",\n"
        << "  \"zero_columns\": " << r.zero_columns << ",\n"
        << "  \"peak_reduced_column_support\": " << r.peak_support << ",\n"
        << "  \"stored_pivot_nonzeros\": " << r.pivot_nonzeros << ",\n"
        << "  \"factor_build_seconds\": " << std::setprecision(10) << r.build_seconds << ",\n"
        << "  \"elimination_seconds\": " << r.elimination_seconds << ",\n"
        << "  \"limits\": {\"seconds\": " << lim.max_seconds
        << ", \"column_support\": " << lim.max_support
        << ", \"pivot_nonzeros\": " << lim.max_pivot_nonzeros << "},\n"
        << "  \"layer_columns\": [";
    for(std::size_t i=0;i<r.layer_columns.size();++i) {
        if(i) out << ", ";
        out << r.layer_columns[i];
    }
    out << "],\n  \"pivot_rows_in_column_order\": [";
    for(std::size_t i=0;i<r.pivot_rows.size();++i) {
        if(i) out << ",";
        if(i%8==0) out << "\n    ";
        out << r.pivot_rows[i];
    }
    out << "\n  ]\n}\n";
}

void print_chart_summary(const ChartData& c) {
    std::cout << "CHART name=" << c.name
              << " H_terms=" << c.H.size()
              << " J_terms=" << c.J.size()
              << " D_terms=" << c.D.size()
              << " L1_terms=" << c.L1.size()
              << " L2_terms=" << c.L2.size()
              << " R3_terms=" << c.R3.size()
              << " G_terms=" << c.G.size() << "\n";
}

void direct_log_wronskian_test(const ChartData& c) {
    // Compare the cleared identity with direct first/second differentiation
    // at every nonsingular base point of F_5^2 and several jets.  This is
    // independent of the subsequent binomial/common-denominator expansion.
    const auto dA=horizontal_derivative(c.A), dB=horizontal_derivative(c.B);
    const auto dC=horizontal_derivative(c.C);
    const auto ddA=horizontal_derivative(dA), ddB=horizontal_derivative(dB);
    const auto ddC=horizontal_derivative(dC);
    const auto Aa=derivative_base(c.A,0), Ab=derivative_base(c.A,1);
    const auto Ba=derivative_base(c.B,0), Bb=derivative_base(c.B,1);
    const auto Ca=derivative_base(c.C,0), Cb=derivative_base(c.C,1);
    int tested=0;
    for(int a=0;a<PRIME;++a) for(int b=0;b<PRIME;++b) {
        const int A=evaluate_fixed_velocity_degree(c.A,0,a,b,0,0);
        const int B=evaluate_fixed_velocity_degree(c.B,0,a,b,0,0);
        const int C=evaluate_fixed_velocity_degree(c.C,0,a,b,0,0);
        if(!A || !B || !C) continue;
        const int H=mod5(A*B*C);
        for(const auto& jet:std::array<std::array<int,4>,4>{{
                {{1,2,3,4}},{{2,1,4,1}},{{3,3,2,4}},{{4,2,1,3}}}}) {
            const int u=jet[0],v=jet[1],ua=jet[2],va=jet[3];
            auto second=[&](const Poly& dd,const Poly& pa,const Poly& pb) {
                return mod5(evaluate_fixed_velocity_degree(dd,2,a,b,u,v)
                            +ua*evaluate_fixed_velocity_degree(pa,0,a,b,0,0)
                            +va*evaluate_fixed_velocity_degree(pb,0,a,b,0,0));
            };
            const int A1=evaluate_fixed_velocity_degree(dA,1,a,b,u,v);
            const int B1=evaluate_fixed_velocity_degree(dB,1,a,b,u,v);
            const int C1=evaluate_fixed_velocity_degree(dC,1,a,b,u,v);
            const int A2=second(ddA,Aa,Ab), B2=second(ddB,Ba,Bb), C2=second(ddC,Ca,Cb);
            const int Up=mod5(quotient5(A1,A)-quotient5(C1,C));
            const int Vp=mod5(quotient5(B1,B)-quotient5(C1,C));
            const int Upp=mod5(quotient5(A2,A)-quotient5(A1*A1,A*A)
                               -quotient5(C2,C)+quotient5(C1*C1,C*C));
            const int Vpp=mod5(quotient5(B2,B)-quotient5(B1*B1,B*B)
                               -quotient5(C2,C)+quotient5(C1*C1,C*C));
            const int lhs=mod5(Up*Vpp-Upp*Vp);
            const int D=evaluate_fixed_velocity_degree(c.D,0,a,b,0,0);
            const int R=evaluate_fixed_velocity_degree(c.R3,3,a,b,u,v);
            const int W=mod5(u*va-ua*v);
            const int rhs=mod5(quotient5(D*W,H)+quotient5(R,H*H));
            if(lhs!=rhs)
                throw std::runtime_error("direct logarithmic Wronskian test failed in chart "+c.name);
            ++tested;
        }
    }
    if(tested<4) throw std::runtime_error("too few nonsingular direct test points");
    std::cout << "DIRECT_IDENTITY_TEST chart=" << c.name << " jets=" << tested << " PASS\n";
}

void self_test() {
    if(variable_count(13,9)!=12550) throw std::runtime_error("old variable count 12550 failed");
    if(variable_count(7,5)!=1584) throw std::runtime_error("old Maple m=7,t=5 variable count failed");
    if(variable_count(21,11)!=81840) throw std::runtime_error("new variable count 81840 failed");
    if(static_cast<long long>(homogeneous_monomials(12).size())!=choose2(12))
        throw std::runtime_error("homogeneous monomial enumeration failed");
    const auto T=chart_T1(),Y=chart_Y1();
    print_chart_summary(T); print_chart_summary(Y);
    // D=16xy on T=1 and D=16tx on Y=1.
    const Poly plus=make_poly({{1,1,0,16}});
    if(!equal_poly(T.D,plus)) throw std::runtime_error("T=1 determinant constant/sign failed");
    if(!equal_poly(Y.D,plus)) throw std::runtime_error("Y=1 determinant constant/sign failed");
    direct_log_wronskian_test(T);
    direct_log_wronskian_test(Y);
    std::cout << "SELF_TEST PASS variable_counts=12550,1584,81840"
              << " full_coupled_identity=checked actual_J_constants=retained"
              << " symmetry_decomposition=no\n";
}

int run_case(int m,int t,const Limits& lim,const std::string& certificate) {
    if(m<1 || t<1 || 3*m-t<0) throw std::runtime_error("invalid (m,t)");
    const long long expected=variable_count(m,t);
    std::cout << "CASE m=" << m << " t=" << t
              << " expected_columns=" << expected
              << " field=F_5 full_coupled=yes symmetry_decomposition=no\n";
    const RankResult r=rank_full_case(m,t,lim);
    const std::string v=verdict(r,expected);
    std::cout << "RESULT processed_columns=" << r.columns
              << " rank=" << r.rank
              << " nullity=" << (r.completed?r.columns-r.rank:0)
              << " zero_columns=" << r.zero_columns
              << " peak_support=" << r.peak_support
              << " pivot_nonzeros=" << r.pivot_nonzeros
              << " build_seconds=" << std::fixed << std::setprecision(6) << r.build_seconds
              << " elimination_seconds=" << r.elimination_seconds
              << " raw_hash=" << hex64(r.raw_hash)
              << " echelon_hash=" << hex64(r.echelon_hash)
              << " completed=" << (r.completed?"yes":"no")
              << " verdict=" << v << "\n";
    write_certificate(certificate,m,t,lim,r);
    if(v=="PROVED_FULL_COLUMN_RANK_MOD_5") return 0;
    if(!r.completed) return 4;
    return 3;
}

} // namespace

int main(int argc,char**argv) try {
    if(argc==1 || std::string(argv[1])=="--self-test") { self_test(); return 0; }
    if(std::string(argv[1])!="--case" || argc<4) {
        std::cerr << "usage: verifier --self-test | --case m t"
                  << " [--max-seconds S] [--max-support N]"
                  << " [--max-pivot-nonzeros N] [--certificate FILE]\n";
        return 2;
    }
    const int m=std::atoi(argv[2]),t=std::atoi(argv[3]);
    Limits lim; std::string certificate;
    for(int i=4;i<argc;++i) {
        const std::string a=argv[i];
        if(a=="--max-seconds" && i+1<argc) lim.max_seconds=std::atof(argv[++i]);
        else if(a=="--max-support" && i+1<argc) lim.max_support=std::strtoull(argv[++i],nullptr,10);
        else if(a=="--max-pivot-nonzeros" && i+1<argc) lim.max_pivot_nonzeros=std::strtoull(argv[++i],nullptr,10);
        else if(a=="--certificate" && i+1<argc) certificate=argv[++i];
        else throw std::runtime_error("unknown or incomplete option: "+a);
    }
    return run_case(m,t,lim,certificate);
} catch(const std::exception& e) {
    std::cerr << "ERROR " << e.what() << "\n";
    return 1;
}
