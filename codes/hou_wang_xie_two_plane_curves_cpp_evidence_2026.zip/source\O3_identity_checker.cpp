/* Exact checker for the six local identities in the O(3) field package.

   (1)--(3) are the value, gradient, and Hessian tensor forms equivalent to
   V(E0)=0, V(E1)=d N(xi)E0, and
   V(E2)=d N(eta)E0+2d N(xi)E1.

   (4)--(6) are the three residual-curvature commutators.  They are checked
   as polynomial identities in u,v on a basis of the six-dimensional space
   of pairs of symmetric 2x2 matrices, hence for symbolic a,b,c,d,e,f by
   linearity.  No floating-point arithmetic or external CAS is used.
*/

#include <array>
#include <cstdint>
#include <cstdlib>
#include <iostream>
#include <map>
#include <numeric>
#include <stdexcept>
#include <utility>

namespace {

using i64=std::int64_t;

struct Rat {
    i64 n=0,d=1;
    Rat()=default;
    Rat(i64 value):n(value),d(1) {}
    Rat(i64 nn,i64 dd):n(nn),d(dd) {
        if (d==0) throw std::runtime_error("zero rational denominator");
        if (d<0) {n=-n;d=-d;}
        const i64 g=std::gcd(std::llabs(n),d);
        n/=g;d/=g;
    }
    bool zero() const {return n==0;}
};

Rat operator+(const Rat &a,const Rat &b) {return {a.n*b.d+b.n*a.d,a.d*b.d};}
Rat operator-(const Rat &a,const Rat &b) {return {a.n*b.d-b.n*a.d,a.d*b.d};}
Rat operator-(const Rat &a) {return {-a.n,a.d};}
Rat operator*(const Rat &a,const Rat &b) {return {a.n*b.n,a.d*b.d};}

struct Poly {
    std::map<std::pair<int,int>,Rat> c;
    static Poly constant(Rat value) {
        Poly p;
        if (!value.zero()) p.c[{0,0}]=value;
        return p;
    }
    static Poly monomial(int x,int y,Rat value=Rat(1)) {
        Poly p;
        if (!value.zero()) p.c[{x,y}]=value;
        return p;
    }
    void add(int x,int y,Rat value) {
        if (value.zero()) return;
        auto &slot=c[{x,y}];
        slot=slot+value;
        if (slot.zero()) c.erase({x,y});
    }
    Poly derivative(int variable) const {
        Poly out;
        for (const auto &[exponent,coefficient]:c) {
            const int power=variable==0?exponent.first:exponent.second;
            if (power==0) continue;
            auto reduced=exponent;
            if (variable==0) --reduced.first; else --reduced.second;
            out.add(reduced.first,reduced.second,coefficient*Rat(power));
        }
        return out;
    }
    Rat evaluate(Rat x,Rat y) const {
        Rat sum;
        for (const auto &[exponent,coefficient]:c) {
            Rat term=coefficient;
            for (int i=0;i<exponent.first;++i) term=term*x;
            for (int i=0;i<exponent.second;++i) term=term*y;
            sum=sum+term;
        }
        return sum;
    }
    bool zero() const {return c.empty();}
};

Poly operator+(Poly a,const Poly &b) {
    for (const auto &[e,v]:b.c) a.add(e.first,e.second,v);
    return a;
}
Poly operator-(Poly a,const Poly &b) {
    for (const auto &[e,v]:b.c) a.add(e.first,e.second,-v);
    return a;
}
Poly operator*(const Poly &a,const Poly &b) {
    Poly out;
    for (const auto &[ea,ca]:a.c) for (const auto &[eb,cb]:b.c)
        out.add(ea.first+eb.first,ea.second+eb.second,ca*cb);
    return out;
}
Poly operator*(const Poly &a,Rat scalar) {
    Poly out;
    for (const auto &[e,c]:a.c) out.add(e.first,e.second,c*scalar);
    return out;
}
Poly operator*(Rat scalar,const Poly &a) {return a*scalar;}

using Vec=std::array<Rat,2>;
using Mat=std::array<std::array<Rat,2>,2>;
using SymMap=std::array<Mat,2>;

Mat zero_matrix() {return {{{Rat(0),Rat(0)},{Rat(0),Rat(0)}}};}

Poly deterministic_f(int degree) {
    Poly f;
    for (int i=0;i<=degree;++i) for (int j=0;i+j<=degree;++j)
        f.add(i,j,Rat(1+2*i+3*j+i*j));
    return f;
}

void require_zero(const Rat &value,const char *message) {
    if (!value.zero()) throw std::runtime_error(message);
}

void check_tangency_for_degree(int degree) {
    const Poly x=Poly::monomial(1,0),y=Poly::monomial(0,1);
    const Vec z{{Rat(2),Rat(-1)}};
    const Poly h0=x-Poly::constant(z[0]);
    const Poly h1=y-Poly::constant(z[1]);
    const std::array<Poly,2> h{{h0,h1}};
    const Mat T{{{Rat(2),Rat(3)},{Rat(-1),Rat(-2)}}};
    const SymMap C{{
        {{{Rat(1),Rat(2)},{Rat(2),Rat(-1)}}},
        {{{Rat(-2),Rat(1)},{Rat(1),Rat(3)}}}
    }};
    const Vec N{{Rat(4),Rat(-3)}};
    const Poly f=deterministic_f(degree);
    const std::array<Poly,2> df{{f.derivative(0),f.derivative(1)}};

    std::array<Poly,2> Th{{Poly{},Poly{}}};
    Poly Nh;
    std::array<Poly,2> Ch{{Poly{},Poly{}}};
    for (int a=0;a<2;++a) {
        Nh=Nh+h[static_cast<std::size_t>(a)]*N[static_cast<std::size_t>(a)];
        for (int b=0;b<2;++b)
            Th[static_cast<std::size_t>(a)]=Th[static_cast<std::size_t>(a)]+
                h[static_cast<std::size_t>(b)]*T[static_cast<std::size_t>(a)][static_cast<std::size_t>(b)];
        for (int r=0;r<2;++r) for (int s=0;s<2;++s)
            Ch[static_cast<std::size_t>(a)]=Ch[static_cast<std::size_t>(a)]+
                h[static_cast<std::size_t>(r)]*h[static_cast<std::size_t>(s)]*
                C[static_cast<std::size_t>(a)][static_cast<std::size_t>(r)][static_cast<std::size_t>(s)];
    }
    Poly Q;
    for (int a=0;a<2;++a) {
        Q=Q-df[static_cast<std::size_t>(a)]*Th[static_cast<std::size_t>(a)];
        Q=Q-Rat(1,2)*df[static_cast<std::size_t>(a)]*Ch[static_cast<std::size_t>(a)];
    }
    Q=Q+Rat(degree)*f*Nh;

    const Rat F=f.evaluate(z[0],z[1]);
    Vec p;
    Mat H=zero_matrix(),HQ=zero_matrix();
    Vec gradQ;
    for (int i=0;i<2;++i) {
        p[static_cast<std::size_t>(i)]=df[static_cast<std::size_t>(i)].evaluate(z[0],z[1]);
        gradQ[static_cast<std::size_t>(i)]=Q.derivative(i).evaluate(z[0],z[1]);
        for (int j=0;j<2;++j) {
            H[static_cast<std::size_t>(i)][static_cast<std::size_t>(j)]=
                df[static_cast<std::size_t>(i)].derivative(j).evaluate(z[0],z[1]);
            HQ[static_cast<std::size_t>(i)][static_cast<std::size_t>(j)]=
                Q.derivative(i).derivative(j).evaluate(z[0],z[1]);
        }
    }

    // Tangency identity (1): Q(z)=0.
    require_zero(Q.evaluate(z[0],z[1]),"V(E0) identity failed");
    // Tangency identity (2): dQ+pT-d F N=0.
    for (int j=0;j<2;++j) {
        Rat value=gradQ[static_cast<std::size_t>(j)]-Rat(degree)*F*N[static_cast<std::size_t>(j)];
        for (int a=0;a<2;++a)
            value=value+p[static_cast<std::size_t>(a)]*
                T[static_cast<std::size_t>(a)][static_cast<std::size_t>(j)];
        require_zero(value,"V(E1) identity failed");
    }
    // Tangency identity (3), the symmetric quadratic coefficient in xi.
    for (int i=0;i<2;++i) for (int j=0;j<2;++j) {
        Rat value=HQ[static_cast<std::size_t>(i)][static_cast<std::size_t>(j)]-
            Rat(degree)*(N[static_cast<std::size_t>(i)]*p[static_cast<std::size_t>(j)]+
                         p[static_cast<std::size_t>(i)]*N[static_cast<std::size_t>(j)]);
        for (int a=0;a<2;++a) {
            value=value+p[static_cast<std::size_t>(a)]*
                C[static_cast<std::size_t>(a)][static_cast<std::size_t>(i)][static_cast<std::size_t>(j)];
            value=value+T[static_cast<std::size_t>(a)][static_cast<std::size_t>(i)]*
                H[static_cast<std::size_t>(a)][static_cast<std::size_t>(j)];
            value=value+H[static_cast<std::size_t>(i)][static_cast<std::size_t>(a)]*
                T[static_cast<std::size_t>(a)][static_cast<std::size_t>(j)];
        }
        require_zero(value,"V(E2) identity failed");
    }
}

Mat multiply(const Mat &a,const Mat &b) {
    Mat out=zero_matrix();
    for (int i=0;i<2;++i) for (int j=0;j<2;++j) for (int k=0;k<2;++k)
        out[static_cast<std::size_t>(i)][static_cast<std::size_t>(j)]=
            out[static_cast<std::size_t>(i)][static_cast<std::size_t>(j)]+
            a[static_cast<std::size_t>(i)][static_cast<std::size_t>(k)]*
            b[static_cast<std::size_t>(k)][static_cast<std::size_t>(j)];
    return out;
}

Mat subtract(const Mat &a,const Mat &b) {
    Mat out=zero_matrix();
    for (int i=0;i<2;++i) for (int j=0;j<2;++j)
        out[static_cast<std::size_t>(i)][static_cast<std::size_t>(j)]=
            a[static_cast<std::size_t>(i)][static_cast<std::size_t>(j)]-
            b[static_cast<std::size_t>(i)][static_cast<std::size_t>(j)];
    return out;
}

Poly quadratic_form(const Mat &matrix) {
    const std::array<Poly,2> q{{Poly::monomial(1,0),Poly::monomial(0,1)}};
    Poly out;
    for (int i=0;i<2;++i) for (int j=0;j<2;++j)
        out=out+matrix[static_cast<std::size_t>(i)][static_cast<std::size_t>(j)]*
            q[static_cast<std::size_t>(i)]*q[static_cast<std::size_t>(j)];
    return out;
}

Poly residual_S(const Mat &T,const Mat &K1,const Mat &K2) {
    Mat M1=zero_matrix(),M2=zero_matrix();
    for (int i=0;i<2;++i) for (int j=0;j<2;++j) for (int a=0;a<2;++a) {
        M1[static_cast<std::size_t>(i)][static_cast<std::size_t>(j)]=
            M1[static_cast<std::size_t>(i)][static_cast<std::size_t>(j)]+
            T[static_cast<std::size_t>(a)][static_cast<std::size_t>(i)]*
            K1[static_cast<std::size_t>(a)][static_cast<std::size_t>(j)]+
            K1[static_cast<std::size_t>(i)][static_cast<std::size_t>(a)]*
            T[static_cast<std::size_t>(a)][static_cast<std::size_t>(j)];
        M2[static_cast<std::size_t>(i)][static_cast<std::size_t>(j)]=
            M2[static_cast<std::size_t>(i)][static_cast<std::size_t>(j)]+
            T[static_cast<std::size_t>(a)][static_cast<std::size_t>(i)]*
            K2[static_cast<std::size_t>(a)][static_cast<std::size_t>(j)]+
            K2[static_cast<std::size_t>(i)][static_cast<std::size_t>(a)]*
            T[static_cast<std::size_t>(a)][static_cast<std::size_t>(j)];
    }
    const Poly u=Poly::monomial(1,0),v=Poly::monomial(0,1);
    // C_T=(-xi^T M1 xi,-xi^T M2 xi), S=det(xi,C_T).
    return v*quadratic_form(M1)-u*quadratic_form(M2);
}

Poly linear_action(const Mat &T,const Poly &p) {
    const Poly u=Poly::monomial(1,0),v=Poly::monomial(0,1);
    const Poly Tu=T[0][0]*u+T[0][1]*v;
    const Poly Tv=T[1][0]*u+T[1][1]*v;
    return Tu*p.derivative(0)+Tv*p.derivative(1);
}

Poly curvature(const Mat &A,const Mat &B,const Mat &K1,const Mat &K2) {
    // The displayed residual curvature is the vertical coefficient of
    // [D_A,D_B]-D_[B,A].  Compute that coefficient directly.
    const Mat BAminusAB=subtract(multiply(B,A),multiply(A,B));
    return linear_action(A,residual_S(B,K1,K2))-
           linear_action(B,residual_S(A,K1,K2))-
           residual_S(BAminusAB,K1,K2);
}

void check_curvature() {
    const Mat H{{{Rat(1),Rat(0)},{Rat(0),Rat(-1)}}};
    const Mat E{{{Rat(0),Rat(1)},{Rat(0),Rat(0)}}};
    const Mat F{{{Rat(0),Rat(0)},{Rat(1),Rat(0)}}};
    const Poly u=Poly::monomial(1,0),v=Poly::monomial(0,1);
    for (int parameter=0;parameter<6;++parameter) {
        Mat K1=zero_matrix(),K2=zero_matrix();
        if (parameter==0) K1[0][0]=Rat(1);       // a
        if (parameter==1) K1[0][1]=K1[1][0]=Rat(1); // b
        if (parameter==2) K1[1][1]=Rat(1);       // c
        if (parameter==3) K2[0][0]=Rat(1);       // d
        if (parameter==4) K2[0][1]=K2[1][0]=Rat(1); // e
        if (parameter==5) K2[1][1]=Rat(1);       // f
        const Poly Lambda=(parameter==0 || parameter==4?u:Poly{})+
                          (parameter==1 || parameter==5?v:Poly{});
        if (!(curvature(H,E,K1,K2)-Rat(-2)*v*v*Lambda).zero())
            throw std::runtime_error("[D_H,D_E] curvature identity failed");
        if (!(curvature(H,F,K1,K2)-Rat(-2)*u*u*Lambda).zero())
            throw std::runtime_error("[D_H,D_F] curvature identity failed");
        if (!(curvature(E,F,K1,K2)-Rat(-2)*u*v*Lambda).zero())
            throw std::runtime_error("[D_E,D_F] curvature identity failed");
    }
}

} // namespace

int main() {
    try {
        for (int degree:{2,3,5}) check_tangency_for_degree(degree);
        check_curvature();
        std::cout << "O3 IDENTITY CHECK PASSED: 3 tangency identities at degrees 2,3,5; "
                     "3 curvature commutators on the symbolic six-parameter basis.\n";
        return 0;
    } catch (const std::exception &error) {
        std::cerr << "O3 IDENTITY CHECK FAILED: " << error.what() << '\n';
        return 1;
    }
}
