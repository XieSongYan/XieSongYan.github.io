# Independent audit of the degree-one finite-vanishing computation

Date: 2026-08-23  
Scope: the finite key-vanishing matrices for `(d1,d2)=(1,8)` and `(1,9)`.  This report does **not** audit the separate global `O(3)` slanted-vector-field argument.

## Conclusion

The original experimental certificate for

`A=Z, B=X^8+Y^8+Z^8+X^4Y^4`

is invalid for the intended cohomology group and must not be cited or packaged.  Here `A` coincides with the auxiliary line `L={Z=0}`, the determinant `Delta` is divisible by `z=A`, and both computational charts omit the entire line component.  In addition, the first experimental implementation scaled `Delta` without applying the same scale to `E`.  The files `finite_vanishing_18_p5_perturbed.jsonl` and `.txt` are therefore obsolete even though their recorded matrices have full rank.

The computation was redesigned with the line `A=Y` and auxiliary line `L=Z`.  The corrected program now certifies the following two pairs:

1. `(1,8)`: `A=Y`, `B=X^8+Y^8+Z^8+X^4Y^4`;
2. `(1,9)`: `A=Y`, `B=X^9+Y^9+Z^9+X^3Y^3Z^3`.

All required complete coupled matrices have full column rank over both `F_5` and `F_11`.  The `p=5` certificates contain every pivot-row label; the independent `p=11` certificates contain deterministic matrix and echelon fingerprints.  Thus the finite key-vanishing part is certified over `Q`, subject to the normal-form theorem stated in the paper.

## 1. Geometry of the corrected `(1,8)` pair

Let

`A=Y`, `B=X^8+Y^8+Z^8+X^4Y^4`, and `L=Z`.

The octic is smooth.  Its partial derivatives are

`B_X=4X^3(2X^4+Y^4)`, `B_Y=4Y^3(2Y^4+X^4)`, `B_Z=8Z^7`.

At a singular point one would have `Z=0`.  Neither `X` nor `Y` can vanish, and the remaining equations would be

`2X^4+Y^4=0`, `X^4+2Y^4=0`.

Their coefficient determinant is `3`, so they force `X=Y=0`, a contradiction.  On `A`, the intersection equation is `X^8+Z^8=0`; hence `X,Z` are nonzero and the octic gradient is not proportional to `dY`.  The same argument applies on `L`.  Finally, `A` and `L` meet at `[1:0:0]`, which is not on `B`.  Therefore `A+B+L` is SNC.

On the `X`-chart, with `u=Y/X` and `z=Z/X`, take the integral projectively invariant form

`q=8 dlog(a_X)-dlog(b_X)`,

where

`a_X=u`, `b_X=1+u^8+z^8+u^4`.

The exact coefficients are

`Delta=8b_X-u(b_X)_u=8+8z^8+4u^4`,

`E=-u(b_X)_z=-8uz^7`.

They are the formulas implemented in the audited source.

The factors `z`, `u`, `b_X`, and `Delta` are pairwise coprime over `C[u,z]`.  Only `gcd(b_X,Delta)=1` needs comment.  Put `v=u^4`, `w=z^8`, and `delta_0=Delta/4=2+2w+v`.  Then

`2b_X-delta_0=v(2v+1)`.

A common irreducible factor would have to divide `u` or `2u^4+1`; direct substitution in `b_X` or `delta_0` rules out both possibilities.  Consequently `U_0={ZAB != 0}` and `U_X={X Delta != 0}` miss only finitely many points, and localization at `Delta` does not alter the valuations along `z`, `A`, or `B`.

## 2. Geometry of the corrected `(1,9)` pair

Let

`A=Y`, `B=X^9+Y^9+Z^9+X^3Y^3Z^3`, and `L=Z`.

If a singular point of `B` has a zero coordinate, the other two partial derivatives force all coordinates to vanish.  At an all-nonzero singular point, putting `a=X^3`, `b=Y^3`, `c=Z^3` gives

`3a^2+bc=3b^2+ac=3c^2+ab=0`.

Multiplication yields `27=-1`, equivalently `1^3=-27`, which is false over `C`.  More generally, for coefficient `lambda` in front of `X^3Y^3Z^3`, singularity forces `lambda^3=-27`; `lambda=1` is therefore good.  The intersections with `A` and `L` are transverse, and their mutual intersection `[1:0:0]` is not on `B`.  Hence `A+B+L` is SNC.

On the `X`-chart use

`q=9 dlog(a_X)-dlog(b_X)`,

with

`a_X=u`, `b_X=1+u^9+z^9+u^3z^3`.

Then

`Delta=9+9z^9+6u^3z^3`,

`E=-9uz^8-3u^4z^2`.

Again `z`, `u`, `b_X`, and `Delta` are pairwise coprime.  For the only non-obvious pair, a common factor of `b_X` and `Delta=9b_X-u(b_X)_u` would divide `u(b_X)_u`.  It cannot divide `u`.  After removing the factor `u^2` from `(b_X)_u`, the remaining equation is `3u^6+z^3=0`; on it,

`b_X=1-2u^9-27u^18`,

which is not identically zero on any component.  The same coverage and valuation conclusions follow.

## 3. Correct symmetry decomposition

Both corrected divisors are preserved by

`[X:Y:Z] -> [zeta X:zeta^{-1}Y:Z]`, `zeta^e=1`.

They are **not** preserved by `X<->Y`, because the distinguished line is `Y=0`.  Therefore the old involution splitting must not be used.  The source is split into exactly `e` cyclic character spaces.

There is also a necessary character shift absent from the first experiment.  Since `a=y` has character `-1`, the denominator `a^{-n_k}` contributes `+n_k`, where `n_k=m-2k`.  Thus

`char(x^r y^s (x')^i (y')^j W^k / (a^{n_k}b^{n_k}))`

is

`r-s+i-j+n_k (mod e)`.

The corrected generator uses this layer-dependent shift.  Its self-test does more than count source monomials: for every complete transformed column at `m=3`, it checks that each nonzero target row has the predicted same character.  If a cleared row has monomial `u^U z^Z`, `q`-degree `Q`, and target Wronskian layer `k`, the checked character is

`-2U-Z+2(m-2k)+Q (mod e)`.

This verifies equivariance of the implemented full overlap equations.

## 4. Exact divisibility implementation

For a target layer `k`, the cleared numerator is

`N=z^{n_k} a_X^{n_k} b_X^{n_k} Delta^{n_k} R`.

For the corrected line pair, `a_X=u`.  The required factor is therefore

`z^{n_k+t} u^{n_k} b_X^{n_k}`.

Its leading coefficient as a polynomial in `z` is not a constant, so the former one-shot univariate remainder routine is inapplicable.  The corrected code uses pairwise coprimality and imposes the three equivalent linear conditions separately:

1. no term of `N` has `z`-degree below `n_k+t`;
2. no term of `N` has `u`-degree below `n_k`;
3. the remainder of `N` modulo the monic polynomial `b_X^{n_k}` in `F_p[u][z]` is zero.

The three row families receive disjoint row labels, so all conditions are imposed simultaneously.  This is an exact linear test, not a heuristic.

## 5. Ambient counts and rank results

For `(1,e)`, the number of ambient variables is

`N_e(m)=sum_{0<=k<=floor(m/3)} (m-3k+1) binom(e m-(2e+1)k+2,2)`.

The independently checked counts and maximum character-block sizes are:

| degree pair | `(m,t)` | raw columns | blocks | maximum block |
|---|---:|---:|---:|---:|
| `(1,8)` | `(3,2)` | 1,336 | 8 | 174 |
| `(1,8)` | `(4,2)` | 3,077 | 8 | 398 |
| `(1,8)` | `(5,2)` | 6,066 | 8 | 779 |
| `(1,8)` | `(6,3)` | 10,807 | 8 | 1,382 |
| `(1,8)` | `(7,3)` | 17,876 | 8 | 2,279 |
| `(1,8)` | `(8,3)` | 27,849 | 8 | 3,543 |
| `(1,9)` | `(3,3)` | 1,669 | 9 | 186 |
| `(1,9)` | `(4,3)` | 3,857 | 9 | 429 |

At `p=5`, every one of the 48 required `(1,8)` blocks has rank equal to its number of columns, for 67,011 pivots in total.  Every one of the 18 required `(1,9)` blocks also has full column rank, for 5,526 pivots in total.  The full certificates contain exactly one pivot-row label per column.

The complete calculations were repeated at `p=11`; all 48 and 18 blocks again have full column rank.  The attempted `p=7` runs are deliberately excluded: several integral minors vanish modulo 7, and the degree-nine test curve has bad reduction there because `1^3=-27 (mod 7)`.  A bad reduction prime does not weaken a full-rank certificate at a good prime.

The independent aggregation checker reports:

`CERTIFICATE SET VERIFIED: 48 required full-rank block(s), deterministic fingerprints present.`

`CERTIFICATE SET VERIFIED: 18 required full-rank block(s), deterministic fingerprints present.`

It checks the exact required case/block set, full-mode status, positive column count, `rank=columns`, zero nullity, nonempty matrix/echelon fingerprints, duplicate consistency, and the audited degree-one run metadata.  It does not rebuild the matrices; that remains the role of the separately compiled generator.

## 6. Build and runtime checks

Both C++ programs compile warning-free under Clang with

`-Wall -Wextra -Wpedantic -Wconversion -Wshadow -Wsign-conversion`.

The generator self-test passes at `p=5`, `p=7`, and `p=11`.  Address/undefined-behavior instrumented runs completed the self-test and the smallest full `(1,8)` and `(1,9)` cases without reporting a memory or undefined-behavior violation.  The Windows sanitizer runtime emitted interception warnings, so this instrumented run is supporting evidence rather than part of the mathematical certificate.

## 7. Audited pre-nomenclature snapshot and hashes

The audited artifacts at the time of this degree-one review were:

| file | bytes | SHA-256 |
|---|---:|---|
| `two_components_finite_vanishing_O3.cpp` | 70,526 | `F1E397FFA22FF4A6B4E86D729601AF4B9489B40839C4FA6258A46C840F9BAE9F` |
| `verify_finite_vanishing_certificates.cpp` | 13,055 | `C1392DEB6C2861DA51C1F2939450D36D89AA9B61E3C816DAED5EB1623A09067E` |
| `certificates/proof/pair_18_p5.jsonl` | 1,044,672 | `4CDB406132A608FE24E5F3DC685E4052F05E908DA4E04147B76714E1A4EE0300` |
| `certificates/replays/pair_18_p11.jsonl` | 13,437 | `1AA004AD2C224B70877EFCA1DD399C8635572E99BD1A53C5A4DE109D3759B445` |
| `certificates/proof/pair_19_p5.jsonl` | 88,864 | `37066F31909D44D2DA39DF846F6E82D62DFA329295ED77B66FFF079820BBCCE8` |
| `certificates/replays/pair_19_p11.jsonl` | 5,139 | `3733A3A458C7946FDCEBEA449972A6E9F634D60058A64C31B410428FA2BD74BA` |

This pre-nomenclature source hash includes the transformed-row equivariance self-test
and the later enumeration of the additional conic--quintic case `(8,3)`.
That later enumeration does not change the audited degree-one matrix model or
any of the four degree-one certificate files listed above.
The primary release source subsequently received profile-label and
documentation changes only; its SHA-256 is
`CC7A1825ADCC2226C882F78F3F239DD3C026EF25C9D32E0F1F8CC2BAF27766D0`.

## 8. Reproduction commands

```text
.\bin\two_components_finite_vanishing_O3.exe --self-test --prime 5

.\bin\two_components_finite_vanishing_O3.exe --degrees 1 8 --all --prime 5 --jobs 6 --mode full --full-certificate --certificate pair_18_p5.jsonl --report pair_18_p5.txt

.\bin\two_components_finite_vanishing_O3.exe --degrees 1 9 --all --prime 5 --jobs 6 --mode full --full-certificate --certificate pair_19_p5.jsonl --report pair_19_p5.txt

.\bin\verify_finite_vanishing_certificates.exe --degrees 1 8 certificates\proof\pair_18_p5.jsonl certificates\replays\pair_18_p11.jsonl

.\bin\verify_finite_vanishing_certificates.exe --degrees 1 9 certificates\proof\pair_19_p5.jsonl certificates\replays\pair_19_p11.jsonl
```

## Final limitation

These computations rigorously settle the finite key-vanishing inputs for the displayed test pairs.  They do not by themselves prove the paper's geometric theorem for `(1,e)`: the degree-one adaptation of the global `O(3)` differentiation package is a separate logical dependency and must be audited in the manuscript before the new theorem range is asserted.
