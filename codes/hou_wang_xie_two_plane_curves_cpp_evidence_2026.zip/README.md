# Two-component key-vanishing evidence, factor-three / SMT-57 release

This directory contains the exact finite-rank evidence for six degree pairs in the accompanying paper on two-component logarithmic invariant two-jet differentials. All matrix entries and eliminations are exact; no floating-point arithmetic enters a rank proof.

## Certified proof sets

| degrees | profile or cases | blocks | columns | proof prime | independent replay |
|---|---|---:|---:|---:|---:|
| `(3,3)` | SMT-57, 14 cases | 168 | 280,798 | 5 | case `(9,2)` at 7 |
| `(3,4)` | `(m,t)=(3,3)` | 1 | 781 | 5 | 7 |
| `(2,6)` | `(m,t)=(3,3)` | 8 | 1,040 | 7 | 11 |
| `(2,5)` | six cases through `(8,3)` | 36 | 38,286 | 5 | 7 |
| `(1,8)` | six boundary cases | 48 | 67,011 | 5 | 11 |
| `(1,9)` | `(3,3),(4,3)` | 18 | 5,526 | 5 | 11 |

Every proof block uses the complete coupled matrix, has rank equal to its number of columns, and has nullity zero. The complete `(3,3)` proof set was regenerated in one source-bound run with the exact pre-nomenclature producer preserved under `provenance/producer_snapshot`; all 168 cubic blocks use the current schema with separate matrix and echelon fingerprints and recorded pivot rows. The primary generator under `source` differs from that producer only in profile nomenclature and documentation, not in the matrices or elimination. Proof JSONL files and readable reports are under `certificates/proof`; independent-prime replays are under `certificates/replays`.

The degree-one proof pairs are

- `(1,8)`: `A=Y`, `B=X^8+Y^8+Z^8+X^4Y^4`;
- `(1,9)`: `A=Y`, `B=X^9+Y^9+Z^9+X^3Y^3Z^3`.

No experimental file using `A=Z` belongs to this release. That earlier model coincided with the auxiliary line at infinity and did not test extension across the line component. The release checker also requires degree-one certificates to identify the audited `A=Y` model, character shift, and separate divisibility implementation in their run header.

The `(2,6),p=5` rank-deficient calculation remains isolated under `certificates/diagnostics`; it is not proof evidence. Prime 7 is likewise not used for the degree-one models. The valid degree-one proof and replay primes are 5 and 11.

## Fast verification

From this directory in PowerShell:

```powershell
./bin/verify_finite_vanishing_certificates.exe --degrees 3 3 --profile smt57 ./certificates/proof/cubic_smt38_p5.jsonl ./certificates/replays/cubic_m9_t2_p7.jsonl
./bin/verify_finite_vanishing_certificates.exe --degrees 3 4 ./certificates/proof/pair_34_p5.jsonl ./certificates/replays/pair_34_p7.jsonl
./bin/verify_finite_vanishing_certificates.exe --degrees 2 6 ./certificates/proof/pair_26_p7.jsonl ./certificates/replays/pair_26_p11.jsonl
./bin/verify_finite_vanishing_certificates.exe --degrees 2 5 ./certificates/proof/pair_25_p5.jsonl ./certificates/proof/pair_25_m8_t3_p5.jsonl ./certificates/replays/pair_25_p7.jsonl ./certificates/replays/pair_25_m8_t3_p7.jsonl
./bin/verify_finite_vanishing_certificates.exe --degrees 1 8 ./certificates/proof/pair_18_p5.jsonl ./certificates/replays/pair_18_p11.jsonl
./bin/verify_finite_vanishing_certificates.exe --degrees 1 9 ./certificates/proof/pair_19_p5.jsonl ./certificates/replays/pair_19_p11.jsonl
```

The expected accepted block counts are `168`, `1`, `8`, `36`, `48`, and `18`.

The cubic certificate filenames retain the historical string `smt38` because
the matrices were generated before the coefficient-three correction changed
the theorem's displayed SMT constant.  The finite range itself is unchanged:
`--profile smt57` is canonical and `--profile smt38` is an exact historical
alias.

Internal checks:

```powershell
./bin/two_components_finite_vanishing_O3.exe --self-test --prime 5
./bin/two_components_finite_vanishing_O3.exe --self-test --prime 7
./bin/two_components_finite_vanishing_O3.exe --self-test --prime 11
./bin/O3_identity_checker.exe
```

The degree-one self-test verifies the projectively invariant mixed frames, exhaustion of all cyclic character spaces, the layer-dependent denominator character shift, and equivariance of every transformed row at the first nontrivial weight.

## What is not claimed

This archive certifies the finite key-vanishing inputs. The global degree-one `O(3)` differentiation argument is a separate geometric dependency and is not proved merely by these matrices.

The fast verifier is deliberately a coverage and metadata-consistency checker; it does not reconstruct the matrices or recompute their ranks. Source-bound rank evidence is supplied by the frozen generator and complete run, together with the independent symbolic and entrywise reconstruction tests under `independent_audit`. The tangency part of `O3_identity_checker.exe` is a deterministic regression test; the manuscript contains the universal algebraic argument. Its curvature-commutator part is symbolic on a full parameter basis.

For `(1,7)`, the Riemann--Roch endpoint formally produces 178 finite cases extending through `m=180`. The present method may encounter genuine nonvanishing there; no `(1,7)` certificate or theorem claim is included. A future large-cluster calculation can test that boundary, but a deficient matrix would remain inconclusive until an exact characteristic-zero kernel is established.

## Layout and integrity

- `source`: frozen C++ sources;
- `bin`: warning-clean statically linked C++ binaries;
- `certificates/proof`: proof-effective full-rank certificates;
- `certificates/replays`: independent-prime reproductions;
- `certificates/diagnostics`: explicitly non-proof diagnostics;
- `guide`: standalone TeX/PDF mathematical guide;
- `documentation`: computation and machine notes;
- `reports`: build, checker, provenance, and audit transcripts;
- `independent_audit`: independent symbolic reconstruction sources, results, and the mathematics-to-C++ audit;
- `provenance/producer_snapshot`: the exact source and executable that produced the complete cubic proof run;
- `provenance/legacy`: earlier mixed-schema cubic logs retained only as audit history.

`SHA256SUMS.txt` lists every payload file except itself, using release-relative
paths.  See `reports/FACTOR3_FRONTIER_AUDIT.md` for the final staged
verification and the uncomputed-frontier feasibility analysis.
