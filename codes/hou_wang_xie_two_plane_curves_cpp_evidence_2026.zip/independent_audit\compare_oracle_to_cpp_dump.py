#!/usr/bin/env python3
"""Entry-by-entry comparison of independent SymPy and production C++ matrices."""

from __future__ import annotations

import json
from pathlib import Path
import sys

sys.path.insert(0, str(Path(__file__).resolve().parent))
import independent_symbolic_oracle as oracle


SPECS = {
    "p34_m1_all": ((3, 4), 1, 1, "all", 0),
    "p25_m1_c0_plus": ((2, 5), 1, 1, "c0", 1),
    "p18_m1_c0": ((1, 8), 1, 1, "c0", 0),
    "p33_m3_00_plus": ((3, 3), 3, 1, "00", 1),
}


def read_cpp_dump(path: Path):
    tests = {}
    current = None
    column = None
    for line in path.read_text(encoding="utf-8").splitlines():
        fields = line.split()
        if fields[0] == "TEST":
            current = fields[1]
            tests[current] = []
            column = None
        elif fields[0] == "COL":
            column = {}
            tests[current].append(column)
        else:
            row, coefficient = map(int, fields)
            column[row] = coefficient
    return tests


def main():
    cpp = read_cpp_dump(Path(__file__).with_name("cpp_small_matrices.txt"))
    results = []
    for name, (degrees, m, t, orbit, epsilon) in SPECS.items():
        cur = oracle.curve(*degrees)
        vectors = oracle.basis(cur, m, orbit, epsilon)
        symbolic = [oracle.reduce_column(oracle.vector_rows(cur, m, t, atoms), 5)
                    for atoms in vectors]
        expected = cpp[name]
        mismatch = None
        if len(symbolic) != len(expected):
            mismatch = f"column count {len(symbolic)} != {len(expected)}"
        else:
            for index, (left, right) in enumerate(zip(symbolic, expected)):
                if left != right:
                    mismatch = f"first differing column {index}"
                    break
        item = {
            "name": name,
            "columns": len(symbolic),
            "nonzero_entries": sum(len(column) for column in symbolic),
            "passed": mismatch is None,
            "mismatch": mismatch,
        }
        results.append(item)
        print(json.dumps(item, sort_keys=True), flush=True)
    output = Path(__file__).with_name("oracle_cpp_entrywise_comparison.json")
    output.write_text(json.dumps(results, indent=2) + "\n", encoding="utf-8")
    if not all(item["passed"] for item in results):
        raise SystemExit(1)


if __name__ == "__main__":
    main()
