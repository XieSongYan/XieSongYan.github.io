# Unequal-degree finite-vanishing certificates

All entries below are exact full-mode ranks. `rows` is the number of distinct
nonzero rows actually encountered in that modular block. Timings are per-block
wall seconds measured with `std::chrono::steady_clock`; for a fully parallel
case, the maximum block time is the critical path (apart from small setup and
I/O overhead). `matrix_hash` and `echelon_hash` are preserved in the raw JSONL.

## Case totals at proof primes

| degrees | `(m,t)` | prime | blocks | sum rows | columns | rank | nullity | max block sec |
|---|---:|---:|---:|---:|---:|---:|---:|---:|
| `(3,4)` | `(3,3)` | 5 | 1 | 2659 | 781 | 781 | 0 | 4.002 |
| `(2,6)` | `(3,3)` | 7 | 8 | 7056 | 1040 | 1040 | 0 | 0.506 |
| `(2,5)` | `(3,2)` | 5 | 6 | 5231 | 781 | 781 | 0 | 0.134 |
| `(2,5)` | `(4,2)` | 5 | 6 | 12282 | 1781 | 1781 | 0 | 1.999 |
| `(2,5)` | `(5,2)` | 5 | 6 | 21569 | 3489 | 3489 | 0 | 8.149 |
| `(2,5)` | `(6,3)` | 5 | 6 | 42646 | 6187 | 6187 | 0 | 46.468 |
| `(2,5)` | `(7,3)` | 5 | 6 | 70882 | 10199 | 10199 | 0 | 242.959 |
| `(2,5)` | `(8,3)` | 5 | 6 | 113331 | 15849 | 15849 | 0 | 1170.066 |
| `(1,8)` | `(3,2)` | 5 | 8 | 3623 | 1336 | 1336 | 0 | 0.009 |
| `(1,8)` | `(4,2)` | 5 | 8 | 8799 | 3077 | 3077 | 0 | 0.045 |
| `(1,8)` | `(5,2)` | 5 | 8 | 17902 | 6066 | 6066 | 0 | 0.216 |
| `(1,8)` | `(6,3)` | 5 | 8 | 30627 | 10807 | 10807 | 0 | 1.005 |
| `(1,8)` | `(7,3)` | 5 | 8 | 51623 | 17876 | 17876 | 0 | 3.986 |
| `(1,8)` | `(8,3)` | 5 | 8 | 81487 | 27849 | 27849 | 0 | 14.516 |
| `(1,9)` | `(3,3)` | 5 | 9 | 4527 | 1669 | 1669 | 0 | 0.020 |
| `(1,9)` | `(4,3)` | 5 | 9 | 10970 | 3857 | 3857 | 0 | 0.110 |

Check primes reproduce full rank: prime 7 for `(3,4)` and every `(2,5)`
case, and prime 11 for `(2,6)`, `(1,8)`, and `(1,9)`. Prime 5 is a deliberately retained bad-prime
diagnostic for `(2,6)`: block `c0-` has rank `92/93` and nullity one; it is
not proof evidence.

## Degree-one line pairs

The valid line models use `A=Y`, not `A=Z`:

- `(1,8)`: `B=X^8+Y^8+Z^8+X^4Y^4`;
- `(1,9)`: `B=X^9+Y^9+Z^9+X^3Y^3Z^3`.

Both are preserved by the cyclic action of order `e`, but not by coordinate exchange. Since `a=y` has character `-1`, the denominator contributes the shift `n_k=m-2k`; source character is `r-s+i-j+n_k mod e`. Thus the proof has eight character blocks per `(1,8)` case and nine per `(1,9)` case, with no involution sign.

On the `X`-chart, `a_X=u` and the integral projectively invariant form is `q=e dlog(a_X)-dlog(b_X)`. The required divisor is `z^{n_k+t}u^{n_k}b_X^{n_k}`. Since it is not monic in `z`, the code separately tests its pairwise-coprime `z`, `u`, and `b_X` factors. The totals are 48 blocks and 67,011 columns for `(1,8)`, and 18 blocks and 5,526 columns for `(1,9)`.

No obsolete `A=Z` output belongs to the staged release. The `(1,7)` profile remains uncomputed and may exhibit genuine nonvanishing; it is reserved for a future cluster calculation.

## `(3,4)` full unsplit block

| block | rows | columns | p5 pivot | p7 pivot | p5 sec | p7 sec |
|---|---:|---:|---|---|---:|---:|
| all | 2659 | 781 | `e1de804353f5b5d3` | `7c5b504c1b6d5df1` | 4.002 | 4.241 |

## `(2,6)`: eight cyclic-character/involution blocks

| block | rows | columns | p7 pivot | p11 pivot | p7 sec | p11 sec |
|---|---:|---:|---|---|---:|---:|
| c0- | 617 | 93 | `f3c7a2c8e5fe9b0d` | `1295768fed7363a9` | 0.112 | 0.152 |
| c0+ | 591 | 89 | `5905916b996fe3b5` | `dbf1936b1cb5bcd6` | 0.131 | 0.123 |
| c1- | 1140 | 165 | `19a792b958ac076a` | `84ed5d8bfa5d2bac` | 0.450 | 0.285 |
| c1+ | 1140 | 165 | `19a792b958ac076a` | `84ed5d8bfa5d2bac` | 0.469 | 0.385 |
| c2- | 1211 | 181 | `7fbfe0053f41da46` | `846d713b5d4fa29a` | 0.506 | 0.399 |
| c2+ | 1211 | 181 | `7fbfe0053f41da46` | `846d713b5d4fa29a` | 0.403 | 0.421 |
| c3- | 573 | 83 | `0b99acf48cd1ddba` | `8a248ce20054fb44` | 0.123 | 0.125 |
| c3+ | 573 | 83 | `8be2f0469d299f3a` | `d24a7c43985abe94` | 0.143 | 0.140 |

## `(2,5)`: thirty-six blocks, proof/replay primes 5/7

| `(m,t)` | block | rows p5 | columns | p5 pivot | p7 pivot | p5 sec | p7 sec |
|---:|---|---:|---:|---|---|---:|---:|
| `(3,2)` | c0- | 533 | 80 | `d741c7272682e015` | `93b765cbcdd5b11b` | 0.043 | 0.081 |
|  | c0+ | 512 | 77 | `54e686018acda87f` | `d2c87464404b30e1` | 0.035 | 0.097 |
|  | c1- | 1054 | 156 | `943aabc032e2a40f` | `134b253c032d551a` | 0.134 | 0.327 |
|  | c1+ | 1054 | 156 | `943aabc032e2a40f` | `134b253c032d551a` | 0.132 | 0.331 |
|  | c2- | 1039 | 156 | `8f2fa1e656690c83` | `ea719506f26c4001` | 0.127 | 0.307 |
|  | c2+ | 1039 | 156 | `8f2fa1e656690c83` | `ea719506f26c4001` | 0.129 | 0.326 |
| `(4,2)` | c0- | 1209 | 172 | `45c643e147e03d83` | `d0e4af74dda15054` | 0.417 | 0.442 |
|  | c0+ | 1233 | 185 | `6b5767c2caa51545` | `fc1d1a2dbfcff4af` | 0.496 | 0.484 |
|  | c1- | 2448 | 356 | `f2db4cf7054ebef7` | `570ae0612d97f25f` | 1.992 | 1.748 |
|  | c1+ | 2448 | 356 | `f2db4cf7054ebef7` | `570ae0612d97f25f` | 1.978 | 1.729 |
|  | c2- | 2472 | 356 | `e6ab8363102eef5f` | `e2228ebec44c29c5` | 1.999 | 1.661 |
|  | c2+ | 2472 | 356 | `e6ab8363102eef5f` | `e2228ebec44c29c5` | 1.952 | 1.817 |
| `(5,2)` | c0- | 2154 | 354 | `a96e0c1ddefb96c9` | `f77385e082296e80` | 1.562 | 4.359 |
|  | c0+ | 2121 | 345 | `29f7253c859f3a91` | `8e3af44eb2e81e4d` | 1.601 | 4.030 |
|  | c1- | 4316 | 697 | `ff8606a6613d1027` | `c698122157bfda56` | 8.050 | 18.745 |
|  | c1+ | 4316 | 697 | `ff8606a6613d1027` | `c698122157bfda56` | 8.071 | 18.515 |
|  | c2- | 4331 | 698 | `7d1e4a5b80069289` | `9fffbb2768259f4d` | 8.149 | 18.473 |
|  | c2+ | 4331 | 698 | `7d1e4a5b80069289` | `9fffbb2768259f4d` | 8.114 | 18.839 |
| `(6,3)` | c0- | 4229 | 607 | `9c31eada5720e8fa` | `c89b2f247a949ef7` | 10.111 | 28.226 |
|  | c0+ | 4279 | 632 | `50ee613c7f47ff62` | `d7311d3e88b2810e` | 12.082 | 32.087 |
|  | c1- | 8542 | 1237 | `b8455b167915c569` | `730777374b8de5af` | 45.894 | 94.216 |
|  | c1+ | 8542 | 1237 | `b8455b167915c569` | `730777374b8de5af` | 43.849 | 96.230 |
|  | c2- | 8527 | 1237 | `91b0b38769dfcab4` | `b24ace07139175b4` | 46.468 | 92.494 |
|  | c2+ | 8527 | 1237 | `91b0b38769dfcab4` | `b24ace07139175b4` | 46.197 | 91.770 |
| `(7,3)` | c0- | 7084 | 1028 | `2f1f4eb557f933e8` | `3bec95d428b92e6a` | 66.615 | 90.858 |
|  | c0+ | 7018 | 1013 | `3a01bdedb0e23ebf` | `ea3081c53573a049` | 62.119 | 94.172 |
|  | c1- | 14170 | 2039 | `f85c7d189c852dc2` | `c7d74cabda0b14b` | 234.343 | 329.000 |
|  | c1+ | 14170 | 2039 | `f85c7d189c852dc2` | `c7d74cabda0b14b` | 239.870 | 329.798 |
|  | c2- | 14220 | 2040 | `d40a35ebef780fe7` | `53ec6786f73a6460` | 242.959 | 324.709 |
|  | c2+ | 14220 | 2040 | `d40a35ebef780fe7` | `53ec6786f73a6460` | 242.059 | 331.965 |
| `(8,3)` | c0- | 11272 | 1567 | `ec0faec59eb8263c` | `7f7fa245a203236a` | 329.229 | 187.002 |
|  | c0+ | 11349 | 1604 | `412fbe2045594799` | `30c4bbdf7466a52c` | 355.739 | 198.748 |
|  | c1- | 22679 | 3169 | `878ef3be4e5dd5fe` | `54d916ce8513ccae` | 1167.310 | 805.853 |
|  | c1+ | 22679 | 3169 | `878ef3be4e5dd5fe` | `54d916ce8513ccae` | 1170.066 | 806.143 |
|  | c2- | 22676 | 3170 | `4a9efd0bce188429` | `c5c469c4a5ebf2fb` | 1166.673 | 803.967 |
|  | c2+ | 22676 | 3170 | `4a9efd0bce188429` | `c5c469c4a5ebf2fb` | 1163.057 | 805.361 |

The p7 row counts for `(2,5)` can differ from p5 because some nonzero
integer coefficients vanish after reduction modulo one prime. They are
recorded exactly in `certificates/replays/pair_25_p7.jsonl` and
`certificates/replays/pair_25_m8_t3_p7.jsonl`; columns and ranks agree.

## Raw evidence and SHA-256

```text
certificates/proof/pair_34_p5.jsonl                    51A2E753D8702ABF43792C2A7AE30D2AE02FAC943F514AC0DFA33DC98B149756
certificates/replays/pair_34_p7.jsonl                  92D7D528841C849BE40261B38052FA3571ED35767534386C99799C7CDE6799CC
certificates/proof/pair_26_p7.jsonl                    7536A3EF5D3D70E4FC48014BE7C5D86AEA12D3C2CA667DF4E4C216C06CC8EFC2
certificates/replays/pair_26_p11.jsonl                 87B68C296C332A1E0D7698F703685F7D9A887C5609FB3A0F03907062819F4F6E
certificates/diagnostics/pair_26_p5_BAD_PRIME.jsonl    2DC75691F012EB0F7BF71D916791C4265125DDC0D7C577CC5D4427F40285EC03
certificates/proof/pair_25_p5.jsonl                    EC29B7135F077F3CE8C50D586C166361901FAF967E5CBFF74E4488308B6B7E09
certificates/proof/pair_25_m8_t3_p5.jsonl              D344FC9E55B990D9A7E03C1FA70832AC4503AE12E08F8EC9E8ACD34EF08A7C0F
certificates/replays/pair_25_p7.jsonl                  92FB8A1A602E11A426CD4E9D3648FEA4BC5E746302C5C499479FC68A097A767E
certificates/replays/pair_25_m8_t3_p7.jsonl            7EE590823256F95A17FD10FB66ABB2B82C726BC3E2AF7511F859BB1DB269D666
certificates/proof/pair_18_p5.jsonl                    4CDB406132A608FE24E5F3DC685E4052F05E908DA4E04147B76714E1A4EE0300
certificates/replays/pair_18_p11.jsonl                 1AA004AD2C224B70877EFCA1DD399C8635572E99BD1A53C5A4DE109D3759B445
certificates/proof/pair_19_p5.jsonl                    37066F31909D44D2DA39DF846F6E82D62DFA329295ED77B66FFF079820BBCCE8
certificates/replays/pair_19_p11.jsonl                 3733A3A458C7946FDCEBEA449972A6E9F634D60058A64C31B410428FA2BD74BA
```

The independent aggregator reported respectively `1`, `8`, `36`, `48`, and
`18` required full-rank blocks for `(3,4)`, `(2,6)`, `(2,5)`, `(1,8)`, and
`(1,9)`.

## TeX-ready symmetry/normal-form description

For `(2,e)`, `e in {5,6}`, use the SNC pair
`A=XY+Z^2`, `B=X^e+Y^e+Z^e`. The action
`[X:Y:Z] -> [zeta X:zeta^{-1}Y:Z]`, `zeta^e=1`, preserves both components.
On `Z=1`, a normal-form monomial
`x^r y^s (x')^i(y')^j W_xy^k` has character
`r-s+i-j mod e`, since `W_xy` has character zero. The involution `X<->Y`
sends character `chi` to `-chi` and multiplies `W_xy^k` by `(-1)^k`.
Thus the `e=5` candidate space is the direct sum of six blocks indexed by
`{0},{1,4},{2,3}` and the two involution eigenvalues; for `e=6` there are
eight blocks indexed by `{0},{1,5},{2,4},{3}` and the two eigenvalues.

Writing `S=d1+d2`, `n_k=m-2k`, `s_k=m-3k`, the finite ambient normal form is

```tex
\sum_{k=0}^{\lfloor m/3\rfloor}\ \sum_{i+j=s_k}
\frac{P_{i,j,k}(x,y)}{a^{n_k}b^{n_k}}
(x')^i(y')^jW_{xy}^k,
\qquad
\deg P_{i,j,k}\le (S-1)m-(2S-1)k.
```

For the symmetric `(2,e)` pair, on the `X`-chart
`a_X=u+z^2`, `b_X=1+u^e+z^e`, and the projectively invariant form
`q=dlog(a_X)-(2/e)dlog(b_X)` gives
`Delta=b_X-2u^{e-1}a_X`, `E=2zb_X-2z^{e-1}a_X`, and
`u'=(a_Xb_X/Delta)q-(E/Delta)z'`. After the exact triangular Wronskian
substitution, regularity and twist are equivalent to divisibility by
`z^{n_k+t}a_X^{n_k}b_X^{n_k}`. These equations are homogeneous integral
linear equations in the coefficients of the `P_{i,j,k}`.
