# Paper 4 mathematics-to-C++ correctness audit

Date: 2026-08-23 (Asia/Shanghai)  
Scope: read-only audit of the finite key-vanishing computation in
`work/two_cubics_O3.tex`, the frozen generator
`work/evidence_release_stage_v3/source/two_components_finite_vanishing_O3.cpp`,
the structural certificate checker, the separate `O(3)` identity checker,
and the staged certificates.

## Release-resolution addendum

The certificate-provenance deficiency recorded below was repaired after this
audit.  A complete `(3,3)` run containing all 168 current-schema blocks now
replaces the mixed-schema proof file, and the exact producing source and
executable are preserved under `provenance/producer_snapshot`.  Their hashes,
the complete output hashes, and the independently replayed verifier result are
recorded in `reports/CURRENT_SOURCE_CUBIC_RUN_PROVENANCE.md`.  Thus the P1
release condition identified in this report is resolved.  The discussion
below is retained to document the problem that prompted the repair and the
independent implementation checks that remain relevant.

## Executive verdict

**Finite-matrix implementation:** serious and mathematically faithful.  I found
no P0 defect in the finite ansatz, chart substitution, denominator clearing,
divisibility rows, symmetry splitting, or modular column-rank algorithm.  An
independent SymPy implementation, derived from the displayed formulas rather
than the C++ polynomial classes, agrees entry by entry with the production C++
on four small matrices covering all qualitatively different code paths.  A
fifth, theorem-relevant conic--quintic block agrees in dimensions, full modular
rank, and canonical complete-matrix fingerprint.  Several small matrices were
also proved full rank directly over `Q` by the independent implementation.

**Prime logic:** sound.  In particular, using prime 5 for `(2,5)` is valid even
though 5 divides the cyclic order and the scalar relating the unnormalized and
primitive logarithmic frames.  The computation reduces a fixed integral matrix
obtained after a rational change of frame.  Full rank of that integral matrix
modulo 5 proves its full rank over `Q`; no semisimplicity or good geometric
reduction in characteristic 5 is needed.  The live TeX now states this
normalization correctly at lines 3328--3355.

**Certificate release (audit-time finding, now resolved as above):** at the
time of the initial audit the release was not yet uniformly source-bound.  The 24 modern cubic
blocks at `m=9,14` and all unequal-degree records have complete matrix and
echelon fingerprints.  The other 144 cubic blocks are legacy run records with
only a pivot-row hash and no preserved exact producer/source binding.  A fresh
`m=3` run from the frozen current source has the same columns, rows, rank,
nullity, and pivot-row hash as the archive, but 11 of 12 reported pivot products
differ.  This is consistent with a harmless earlier column/frame scaling, but
the legacy record does not contain enough information to prove that.  Those
144 JSON records therefore do **not**, by themselves, constitute a rigorous
source-bound certificate proof.  The current generator remains capable of
recomputing the proof, but the release should regenerate those records with the
frozen current source before claiming a homogeneous, source-bound certificate
set.

**Overall:** the code is not placeholder or fake code.  It is a credible exact
computational proof engine.  Publication readiness required the P1 evidence
repair described below; the complete rerun and preserved producer snapshot in
the release-resolution addendum now supply that repair.

Snapshot hashes used for this report:

- live TeX after the normalization repair: SHA-256
  `380F5EDC1138DD418165DB17920A4F36496BDC31E0416FAE7FF7D8F27611D8A0`
  (4,220 lines);
- frozen generator source: SHA-256
  `F1E397FFA22FF4A6B4E86D729601AF4B9489B40839C4FA6258A46C840F9BAE9F`
  (1,780 lines);
- frozen structural checker source: SHA-256
  `C1392DEB6C2861DA51C1F2939450D36D89AA9B61E3C816DAED5EB1623A09067E`;
- frozen `O(3)` checker source: SHA-256
  `F63B15D9F86839474FB18E7B1F4C168595AE9D6CC0E56C141AD9681DC445B648`.

## 1. Exact mathematical-to-code trace

### 1.1 Test pairs and chart polynomials

The six TeX test pairs are at lines 3090--3234, with the defining table at
3093--3102.  They map to:

- `CurveConfig` and `curve_config`, C++ lines 118--164;
- `aX,bX`, C++ lines 692--705;
- the primitive `Delta,H,E`, C++ lines 706--733.

The formulas agree:

- `(3,3)`: `a_X=1+2u^3+z^3`, `b_X=2+u^3+z^3`;
- `(3,4)`: the two Fermat polynomials;
- `(2,e)`: `a_X=u+z^2`, `b_X=1+u^e+z^e`,
  `Delta=b_X-2a_Xu^(e-1)`,
  `E=2zb_X-2a_Xz^(e-1)`;
- `(1,8)` and `(1,9)`: exactly the extra mixed monomials and the displayed
  integral `Delta,E`.

An independent exact gcd check gave
`gcd(z,Delta)=gcd(a_X,Delta)=gcd(b_X,Delta)=gcd(a_X,b_X)=1` for all six
models.  This supports the TeX cover and valuation claims around lines
3300--3306 and 3679--3718.

### 1.2 Primitive normalization of `q`

The unnormalized projectively invariant form is displayed at TeX
3315--3326.  The implementation uses primitive rational rescalings:

- diagonal/Fermat models:
  `q_cmp=(1/d1)dlog(a_X)-(1/d2)dlog(b_X)`;
- mixed conic:
  `q_cmp=dlog(a_X)-(2/e)dlog(b_X)`;
- line models: `q_cmp=e dlog(a_X)-dlog(b_X)`.

These are documented in C++ comments 706--709 and in the supplementary guide
at lines 327--378.  The live main TeX now records the exact split at
3328--3355.  This was an important proof/code interface: for `(2,5)`, the
code's `q_cmp` is `q/5`, not the reduction modulo 5 of the unnormalized frame.
The matrix constructed in the primitive frame nevertheless has integral
entries.  A nonzero maximal minor modulo 5 is consequently a nonzero integer
minor, and the rational frame change identifies the characteristic-zero
kernels.  This is the correct argument.

### 1.3 Finite invariant-two-jet ansatz

The local invariant normal form is stated at TeX 564--578.  The finite ambient
normal form and its bounds are at 3476--3496:

```
k = 0,...,floor(m/3)
i+j = m-3k
n_k = m-2k
deg P_{i,j,k} <= (d1+d2-1)m-(2(d1+d2)-1)k.
```

The exact code realization is:

- `Atom`/`BasisVector`, C++ 479--488;
- cubic basis, C++ 524--559, with `5m-11k`;
- cyclic/involution basis, C++ 585--615;
- degree-one shifted-character basis, C++ 618--637;
- unsplit `(3,4)` basis, C++ 640--657;
- independent raw count, C++ 659--667.

Every tuple `(k,i,j,r,s)` with the stated bounds appears exactly once before
symmetry reduction.  The denominator exponent is not stored in `Atom`; it is
recovered as `nr=m-2*source_k` at C++ 886--887.  No quotient relation is
silently imposed beyond the standard free local invariant-two-jet normal form
in `x',y',W_xy`.

For the endpoint `m=14`, an independent combinatorial enumeration gave the
12 block dimensions

```
4402, 4428, 4260, 4284, 4118, 4143,
8261, 8261, 8544, 8544, 8830, 8830,
```

whose sum is 76,905, equal to the raw ansatz count.  Thus the block splitting
does not lose endpoint columns even though the built-in cubic count self-test
currently stops at `m=12`.

### 1.4 Exact mixed-chart transformation

The TeX transition is at 3557--3641, including the full triangular identity
at 3635--3641.  It maps to:

- `A=H/Delta`, `B=-E/Delta`, C++ 760--766;
- `zu'-uz'=zAq+(zB-u)z'`, C++ 768--772;
- leading Wronskian term, C++ 774--775;
- all three lower Wronskian terms, C++ 777--784;
- powers `z'^i(zu'-uz')^jW_zu^k`, C++ 787--803.

The C++ formula is exactly

```
W_zu = -A W_X
       + A A_u q^2 z'
       + (A_u B+A_z+A B_u) q (z')^2
       + (B B_u+B_z) (z')^3.
```

The code uses exact sparse rational functions with denominators tracked only
as powers of `Delta` (`RationalDelta`/`RationalRing`, C++ 365--424).  It checks
the target weighted-degree invariant and the denominator bound at C++
893--901.  The chart sign `(-1)^(i+k)` is applied at 889--890 and agrees with
the TeX ordinary-chart transition.

### 1.5 Clearing and divisibility rows

The cleared numerator and divisibility criterion are at TeX 3674--3717.  The
code implements

```
N = z^n_t a_X^n_t b_X^n_t Delta^n_t R
```

at C++ 903--921.  The exponent

```
n_t+(d1+d2-2)m+(-2(d1+d2)+3)source_k-(r+s)
```

is exactly the TeX `z`-clearing exponent.

For cubics, conics, and `(3,4)`, the divisor
`z^(n_t+t)a_X^n_t b_X^n_t` is monic in `z`.  `remainder_z`, C++ 327--363,
performs deterministic exact division in `F_p[u][z]`; zero remainder is
equivalent to divisibility.

For line pairs, C++ 922--932 imposes three disjoint row families:

1. all coefficients with `z`-degree below `n_t+t`;
2. all coefficients with `u`-degree below `n_t`;
3. the remainder modulo monic `b_X^n_t`.

This is exactly TeX 3719--3734 and is equivalent because the three factors
are pairwise coprime.  `RowKey`, C++ 814--838, separately encodes condition,
target Wronskian layer, `q`-degree, `u`-degree, and `z`-degree.  The omitted
`z'` exponent is determined by weighted degree and is explicitly checked at
C++ 897--899, so no target monomials collide accidentally.

### 1.6 Symmetry decomposition and exhaustiveness

The cubic characters and involution are at TeX 3739--3823.  They map to
`ORBITS`, `sigma_atom`, and `generate_basis`, C++ 503--559.  The character
filter `(r+i+k,s+j+k) mod 3` and involution scalar
`epsilon*(-1)^k` are exact.

The `(2,e)` cyclic/involution blocks described at TeX 3201--3217 map to C++
568--615.  The line characters at TeX 3224--3234 map to C++ 618--637, including
the essential shift `+n_k`.  Runtime task enumeration is at C++ 1430--1455.
The source self-tests sum all cyclic blocks to the raw basis dimensions at
C++ 1340--1356 and check transformed-row equivariance for line models at
1385--1414.

One expository dependency remains: TeX has a formal cubic exhaustion lemma
at 3803--3823 and a formal line exhaustion lemma at 3825--3837, but no
corresponding `(2,e)` lemma.  Proposition 3839--3868 is stated for all test
pairs and cites only those two lemmas.  The missing argument is the same
characteristic-zero semisimplicity plus involution-orbit argument and the C++
count test confirms the enumeration, but it should be stated explicitly.

### 1.7 Modular column rank

The mathematical implication is stated at TeX 3985--4031.  The code is:

- prime validation and field operations, C++ 166--201 and 1258--1259;
- sparse column construction, C++ 883--945;
- deterministic column elimination, C++ 959--1010;
- full coupled block construction, C++ 1050--1077;
- theorem case enumeration, C++ 1177--1190 and 1590--1613.

For each column, the smallest remaining row is used as pivot.  Stored pivots
are normalized, and later columns are reduced by exact finite-field column
operations.  The returned rank is therefore the exact column rank over
`F_p`.  If rank equals the number of columns, a maximal minor is nonzero
modulo `p`; the same integer minor is nonzero over `Q` and `C`.

The symmetry decomposition is required only over `C`.  The program does not
use roots of unity or Maschke's theorem inside `F_p`; it simply reduces the
integer matrices of bases already chosen for the characteristic-zero blocks.
Thus `p=5` dividing the order of `mu_5` does not invalidate the inference.
Likewise, geometric bad reduction of a test curve at a prime can make that
prime unhelpful, but cannot turn a full-rank reduction of the fixed integer
matrix into a false characteristic-zero conclusion.

## 2. Independent tests performed

### 2.1 Build, self-tests, structural coverage, and manifest

- Rebuilt all three C++ sources with the staged LLVM-MinGW 22.1.8 toolchain;
  the static builds succeeded.
- Archived and rebuilt generators passed `--self-test` at primes 5, 7, 11.
- Archived and rebuilt `O3_identity_checker` exited zero.
- The structural checker accepted all six required collections with exactly
  `168,1,8,36,48,18` blocks.
- Independently recomputed all 62 entries in `SHA256SUMS.txt`; no missing or
  mismatched payload occurred.

### 2.2 Independent symbolic oracle

Audit source:
`work/paper4_math_cpp_audit/independent_symbolic_oracle.py`, SHA-256
`AE5EA39ADA1562C3FAACAFECD701555201C2FE1A632B490D37B2F412010A9730`.

The oracle uses SymPy rational functions over `Q`, directly substitutes the
displayed `A,B,W` formulas, clears denominators over `Z`, performs independent
monic polynomial division, independently enumerates the symmetry bases, and
only then reduces the integer matrix modulo `p`.  It does not import or call
the production polynomial or rank code.

Results:

| path tested | columns | rows | modular rank | direct `Q` rank | production matrix hash | result |
|---|---:|---:|---:|---:|---|---|
| `(3,4),m=1,t=1`, unsplit | 56 | 115 | 56 | 56 | `89769bc49dcd8c97` | pass |
| `(2,5),m=1,t=1,c0,+` | 6 | 22 | 6 | 6 | `7ca17d90d533ed90` | pass |
| `(2,5),m=3,t=2,c0,+` | 77 | 512 | 77 | 77 certified from the independently built integral matrix mod 5 | `d6928cfdb4d1eb53` | pass |
| `(1,8),m=1,t=1,c0` | 13 | 24 | 13 | 13 | `711295a4c77f900e` | pass |
| `(3,3),m=3,t=1,00,+` | 36 | 223 | 36 | 36 | `0578690cbbe1c476` | pass |

The conic--quintic `m=3,t=2` case is theorem-relevant and deliberately tests
the prime-5 normalization issue.  Its independently constructed integral
matrix has exactly the archived complete-matrix fingerprint and full rank
modulo 5.

For four matrices, an audit-only extractor included the unmodified production
source and serialized every nonzero entry.  The independent oracle agreed
entry by entry, not merely in rank or hash:

| matrix | columns | compared nonzero entries | result |
|---|---:|---:|---|
| `(3,4),m=1` | 56 | 323 | exact match |
| `(2,5),m=1,c0,+` | 6 | 38 | exact match |
| `(1,8),m=1,c0` | 13 | 49 | exact match |
| `(3,3),m=3,00,+` | 36 | 1,858 | exact match |

The entrywise result file is
`work/paper4_math_cpp_audit/oracle_cpp_entrywise_comparison.json`, SHA-256
`D51C7EFE946A6CB66BB75EFECA46138805EE5C8BD0BA05A5B5859AC62EC799CF`.

### 2.3 Fresh proof-case replays

Using a rebuild of the frozen current source in full mode, I reran one
theorem-relevant case for every degree pair and also the modern cubic `m=9`
case:

- `(3,3),(3,1),p=5`: all 12 blocks full rank;
- `(3,3),(9,2),p=5`: all 12 blocks full rank and every modern archived
  matrix/echelon/rank field matched exactly;
- `(3,4),(3,3),p=5`: exact archived fingerprint match;
- `(2,6),(3,3),p=7`: all eight exact archived fingerprint matches;
- `(2,5),(3,2),p=5`: all six exact archived fingerprint matches;
- `(1,8),(3,2),p=5`: all eight exact archived fingerprint matches;
- `(1,9),(3,3),p=5`: all nine exact archived fingerprint matches.

The preserved historical `m=14` producer was also run on cubic `m=3`; it
produced exactly the same matrix/echelon hashes and pivot products as the
current frozen source.  This is strong evidence that the expensive modern
`m=14` record and current matrix logic agree, although it is not a substitute
for preserving the exact producer source or rerunning `m=14` with the current
source.

## 3. Certificate and verifier audit

### 3.1 What the JSON records establish

Current generator output at C++ 1089--1145 records declared dimensions,
rank, nullity, pivot product, pivot-row hash, input-matrix FNV hash, normalized
echelon FNV hash, and optionally pivot rows.  These are useful deterministic
regression data.  FNV is not collision-resistant; the SHA-256 manifest binds
the archive files but does not transform a declared rank into an independently
checkable rank witness.

The structural checker says exactly what it does at source lines 1--9.  It
constructs expected keys (134--167), accepts only declared full-mode/full-rank
records (220--253), and checks coverage/duplicate consistency (254--284).  It
does **not** regenerate a matrix, check a pivot minor, recompute elimination,
validate that a hash came from the frozen source, or even derive the declared
rank from certificate data.  This is transparently documented in the guide at
711--744.  Calling it a structural checker is accurate; calling it an
independent rank verifier would not be.

### 3.2 Legacy cubic records

For 144 cubic blocks with `m != 9,14`, the verifier's compatibility path at
lines 243--246 copies one legacy `pivot_hash` string into both the nominal
matrix and echelon slots.  It explicitly does not pretend these are two
fingerprints.  These records lack the data needed to bind the reported rank
to the current source matrix.

A fresh current-source `m=3` run compared with the archive as follows:

- same 12 block keys;
- same columns, nonzero-row counts, ranks, nullities, and pivot-row hashes;
- different `det_mod_p` in 11 of 12 blocks;
- the legacy archive has no input-matrix/echelon hash with which to make a
  stronger comparison.

The preserved historical `m=14` producer agrees exactly with the current
source on `m=3`, while the legacy `m=3` record does not agree in pivot product.
Therefore that preserved binary is not a demonstrated exact producer of the
144 legacy records.  The differences may be only nonzero column scalings and
do not suggest nonvanishing, but the archive does not prove that equivalence.

**Precise verdict:** the legacy JSON is credible historical evidence of runs,
but not a rigorous source-bound proof certificate.  The mathematical theorem
can still be supported by the reviewed generator and fresh recomputation; the
release as currently staged does not independently establish that the current
source produced all 144 declared full ranks.

### 3.3 Required repair or release caveat

Preferred repair:

1. rerun all 144 legacy cubic blocks with the frozen current source using
   `--mode full --full-certificate`;
2. store current-schema `matrix_hash`, `echelon_hash`, pivot rows, exact
   command, program version, source SHA-256, binary SHA-256, prime, and exit
   code in a run manifest;
3. replace the legacy records rather than mapping one pivot hash into two
   compatibility slots;
4. have a second program regenerate the selected pivot-row minor and verify
   its nonzero determinant, or independently rebuild the complete matrix;
5. for the expensive `m=14` case, either preserve the exact producer source
   and build provenance or rerun it once with the frozen current source on the
   available cluster.

If regeneration is deferred, use an explicit caveat such as:

> The records with `m != 9,14` are retained as historical full-rank run logs.
> They are not independently source-bound certificates; verification of those
> ranks requires rebuilding and rerunning the frozen generator.  The separate
> checker verifies coverage and metadata consistency only.

Do not describe the fast structural checker alone as verifying the rank proof.

## 4. `O(3)` identity checker

This checker is logically separate from the finite key-vanishing matrices.
Its curvature part is genuinely symbolic: C++ 266--287 checks polynomial
identities in `u,v` on all six basis parameters for the two symmetric matrices,
so linearity gives the general six-parameter identity.

The tangency part is only a deterministic regression test.  C++ 113--199 uses:

- one polynomial `f` per degree;
- one point `(2,-1)`;
- one fixed matrix `T`;
- one fixed quadratic tensor `C`;
- one fixed vector `N`;
- degrees only `2,3,5`.

It evaluates value, gradient, and Hessian identities at that one point.  It
does not test a basis of polynomial coefficients or of `T,C,N`, and hence
linearity does not promote these samples to the universal identities claimed
in the guide's broad wording at lines 748--753.  For example, an erroneous
extra term vanishing to third order at the selected point would evade all
three checks.  The main TeX supplies a mathematical derivation, so this does
not invalidate the finite key-vanishing proof, but the executable should be
called a regression checker unless it is upgraded to symbolic parameter/basis
verification for all component degrees needed by the paper.

## 5. Findings by severity

### P0 -- none found

No fatal mismatch was found in the finite matrix construction or modular-rank
inference.

### P1 -- release was not uniformly source-bound (resolved)

At the time of this audit, the 144 legacy cubic records were declared-rank historical logs, not rigorous
source-bound certificates.  Fresh `m=3` output proves that the current source
does not reproduce their pivot products byte for byte, and the legacy schema
has no complete matrix/echelon hashes to diagnose the difference.  Regenerate
them or add the caveat in Section 3.3.  The modern `m=9` record, all tested
unequal-degree records, and the independent oracle comparisons pass exactly.

### P2 -- missing conic symmetry lemma

The `(2,e)` block exhaustion is described and correctly implemented, but
Proposition 3839--3868 cites formal exhaustion lemmas only for cubic and line
models.  Add the one-paragraph cyclic/involution semisimplicity argument for
the conic models.

### P2 -- `O(3)` tangency checker overstates universality

The curvature checker is symbolic; the tangency checker is sample-based.
Rename it as a regression check or test coefficient/parameter bases
symbolically.  This is separate from the finite KVL engine.

### P2 -- structural verifier is not a rank verifier

This limitation is honestly documented, but the release language must preserve
the distinction.  A forged JSON record with plausible full-rank fields would
pass unless it conflicted with coverage or a duplicate fingerprint.  Stronger
certification requires matrix regeneration or a checkable minor witness.

### P3 -- extend endpoint self-tests

The built-in cubic symmetry-count self-test stops at `m=12` (C++ 1294--1308),
while the proof runs through `m=14`.  Independent enumeration confirms exact
exhaustion at `m=14`; extend the cheap count self-test to 14 so the source
checks its own endpoint.

### P3 -- clarify “good prime” terminology

For the maximal-minor argument, a proof-effective prime is simply one at
which the chosen integral matrix has full column rank.  It need not be a prime
of SNC geometric reduction or contain the relevant roots of unity.  A
rank-deficient reduction is inconclusive, not evidence of a characteristic-zero
kernel.  The live normalization paragraph resolves the delicate prime-5 case;
the later discussion of bad reductions should remain diagnostic rather than a
logical hypothesis.

## Final assessment

The finite C++ implementation constitutes a serious exact proof computation:
the mathematical ansatz is exhaustive, the chart and Wronskian formulas are
implemented faithfully, all divisibility conditions are present, symmetry
blocks exhaust the characteristic-zero candidate space, and modular full rank
has the correct maximal-minor meaning.  The independent entrywise oracle gives
strong evidence against a faithful-implementation error.

The audit-time staged archive was best described as **a strong reproducibility
package with one legacy source-binding gap**, rather than a uniformly
source-bound certificate proof.  That repair has now been completed: the
proof-effective cubic file contains all 168 current-schema blocks from one
run, and its exact producer source and executable are included in
`provenance/producer_snapshot`.  The obsolete mixed-schema file remains only
under `provenance/legacy` and is not an input to the final proof check.
