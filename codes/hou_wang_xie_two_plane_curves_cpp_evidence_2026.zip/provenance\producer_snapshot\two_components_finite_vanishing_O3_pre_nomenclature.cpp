/*
  Exact finite-vanishing verifier for two plane-curve components
  ================================================================

This program implements the finite computation described in Section
"Proof of the finite key vanishing theorem: a symmetry-adapted finite
computation" of the accompanying paper.  Its computational style follows
  Appendix A of

      Hou--Huynh--Merker--Xie,
      A Second Main Theorem for Entire Curves Intersecting Three Conics,
      arXiv:2512.03948v2,

  while using the symmetry-block/modular-C++ strategy of

      Cui--Hou--Liu--Xie,
      A Symmetry Method for Key Vanishing Lemmas and Optimal 2-Jet
      Thresholds for Hyperbolicity, arXiv:2606.19155.

  Mathematical target
  -------------------
  For the following certified simple-normal-crossing pairs

    (3,3): A=X^3+2Y^3+Z^3, B=2X^3+Y^3+Z^3;
    (3,4): A=X^3+Y^3+Z^3,  B=X^4+Y^4+Z^4;
    (2,e): A=XY+Z^2,       B=X^e+Y^e+Z^e, e=5,6;
    (1,8): A=Y,            B=X^8+Y^8+Z^8+X^4Y^4;
    (1,9): A=Y,            B=X^9+Y^9+Z^9+X^3Y^3Z^3;

  verify, for the finite boundary cases selected by --all,

      H^0(P^2,E_{2,m}T^*_{P^2}(log(A+B)) tensor O(-t)) = 0

  By upper semicontinuity, vanishing at a certified pair proves it on a nonempty
  Zariski-open set of pairs of the same bidegree.

  Proof certificate
  -----------------
  Each regularity condition is an integral homogeneous linear equation.
  The program reduces the system modulo a prime p != 2,3.  Full column rank
  over F_p implies full column rank over Q, hence only the zero section exists.

  The default "auto" mode first uses only the diagonal Wronskian layer.  The
  chart transformation is triangular in Wronskian degree, so full column rank
  in every diagonal layer proves vanishing by descending induction.  If a
  diagonal layer is deficient, auto mode rebuilds and solves the complete
  coupled system; thus the shortcut cannot create a false vanishing result.

  Build
  -----
      clang++ -O3 -std=c++17 -DNDEBUG -pthread -static \
          -Wall -Wextra -Wpedantic -Wconversion -Wshadow -Wsign-conversion \
          two_components_finite_vanishing_O3.cpp \
          -o two_components_finite_vanishing_O3

  Typical runs
  ------------
      ./two_components_finite_vanishing_O3 --self-test
      ./two_components_finite_vanishing_O3 --degrees 2 5 --all \
          --prime 5 --jobs 6 --mode full \
          --certificate finite_vanishing_25_p5.jsonl \
          --report finite_vanishing_25_p5.txt
      ./two_components_finite_vanishing_O3 --all --prime 5 --jobs 4 \
          --mode full --certificate finite_vanishing_p5.jsonl \
          --report finite_vanishing_p5.txt

  --all with --profile baseline checks t=ceil(m/4), 1<=m<=12.
  The current cubic profiles are smt38, with t=ceil((m+1)/5) and
  1<=m<=14, and smt23, with t=ceil((m+1)/6) and 1<=m<=17.  The old
  name smt57 is a deprecated exact alias of smt38.  The old name smt27
  remains available as a deprecated compatibility profile, retaining its
  original range t=ceil((m+1)/7), 1<=m<=20.  Vanishing for O(-t) implies
  vanishing for every O(-t') with t'>=t.  Use --all-explicit to run every
  admissible t between the profile's minimal twist and 3.

  The cubic pair uses (mu_3)^2 and the transposition X<->Y.  The pairs
  (2,e) use mu_e: (X,Y,Z)->(zeta X,zeta^{-1}Y,Z) and X<->Y, giving six
  blocks for e=5 and eight for e=6.  The (1,e) pairs, e=8,9, have the
  corresponding mu_e action but not the transposition, and therefore split
  into e character blocks.  The (3,4) case is small enough to run unsplit.  --orbit/--epsilon and
  --shard-prefix produce independent cluster jobs.  No external library is
  required.
*/

#include <algorithm>
#include <array>
#include <atomic>
#include <cassert>
#include <chrono>
#include <cstdint>
#include <cstdlib>
#include <fstream>
#include <iomanip>
#include <iostream>
#include <limits>
#include <map>
#include <mutex>
#include <optional>
#include <set>
#include <sstream>
#include <stdexcept>
#include <string>
#include <thread>
#include <tuple>
#include <unordered_map>
#include <utility>
#include <vector>

namespace fv {

using i64 = std::int64_t;
using u64 = std::uint64_t;

static int MODULUS = 5;

static constexpr const char *PROGRAM_VERSION = "2.3-degree-one-lines";

struct CurveConfig {
    enum class Symmetry { none, product_mu3, cyclic };
    int d1 = 3, d2 = 3;
    std::array<int,3> a{{1,2,1}};
    std::array<int,3> b{{2,1,1}};
    Symmetry symmetry=Symmetry::product_mu3;
    int cyclic_order=0;
    bool mixed_conic=false;
    bool linear_component=false;
    bool cyclic_involution=true;

    int total_degree() const { return d1+d2; }
    std::string tag() const { return std::to_string(d1)+"_"+std::to_string(d2); }
    std::string description() const {
        std::ostringstream os;
        if (mixed_conic) {
            os << "A=XY+Z^2, B=X^" << d2 << "+Y^" << d2 << "+Z^" << d2;
            return os.str();
        }
        if (linear_component) {
            os << "A=Y, B=X^" << d2 << "+Y^" << d2 << "+Z^" << d2;
            if (d2==8) os << "+X^4Y^4";
            else if (d2==9) os << "+X^3Y^3Z^3";
            return os.str();
        }
        os << "A=" << a[0] << "X^" << d1 << '+' << a[1] << "Y^" << d1
           << '+' << a[2] << "Z^" << d1 << ", B=" << b[0] << "X^" << d2
           << '+' << b[1] << "Y^" << d2 << '+' << b[2] << "Z^" << d2;
        return os.str();
    }
};

CurveConfig curve_config(int d1, int d2) {
    if (d1>d2) std::swap(d1,d2);
    if (d1==3 && d2==3) return {};
    if (d1==3 && d2==4)
        return {3,4,{{1,1,1}},{{1,1,1}},
                CurveConfig::Symmetry::none,0,false};
    if (d1==2 && (d2==5 || d2==6))
        return {2,d2,{{0,0,0}},{{1,1,1}},
                CurveConfig::Symmetry::cyclic,d2,true};
    if (d1==1 && (d2==8 || d2==9))
        return {1,d2,{{0,1,0}},{{1,1,1}},
                CurveConfig::Symmetry::cyclic,d2,false,true,false};
    throw std::runtime_error(
        "supported degree pairs are (3,3), (3,4), (2,6), (2,5), (1,8), and (1,9)");
}

int mod(i64 a) {
    a %= MODULUS;
    if (a < 0) a += MODULUS;
    return static_cast<int>(a);
}

int addm(int a, int b) { return mod(static_cast<i64>(a) + b); }
int subm(int a, int b) { return mod(static_cast<i64>(a) - b); }
int mulm(int a, int b) { return mod(static_cast<i64>(a) * b); }

int powm(int a, int e) {
    int r = 1;
    while (e > 0) {
        if (e & 1) r = mulm(r, a);
        a = mulm(a, a);
        e >>= 1;
    }
    return r;
}

int invm(int a) {
    if (a == 0) throw std::runtime_error("division by zero in F_p");
    return powm(a, MODULUS - 2);
}

int imod3(int a) {
    a %= 3;
    if (a < 0) a += 3;
    return a;
}

bool is_prime(int p) {
    if (p < 2) return false;
    for (int q = 2; static_cast<i64>(q) * q <= p; ++q)
        if (p % q == 0) return false;
    return true;
}

// A sparse polynomial in F_p[u,z].  The key order is (z-degree,u-degree),
// which makes univariate long division in z deterministic.
struct Poly {
    std::map<std::uint32_t, int> c;

    static std::uint32_t key(int udeg, int zdeg) {
        if (udeg < 0 || zdeg < 0 || udeg > 65535 || zdeg > 65535)
            throw std::runtime_error("polynomial exponent out of range");
        return (static_cast<std::uint32_t>(zdeg) << 16) |
               static_cast<std::uint32_t>(udeg);
    }
    static int udeg(std::uint32_t k) { return static_cast<int>(k & 0xffffU); }
    static int zdeg(std::uint32_t k) { return static_cast<int>(k >> 16); }

    bool zero() const { return c.empty(); }
    std::size_t size() const { return c.size(); }

    void add_term(int u, int z, int a) {
        a = mod(a);
        if (a == 0) return;
        auto k = key(u, z);
        auto it = c.find(k);
        if (it == c.end()) c.emplace(k, a);
        else {
            int v = addm(it->second, a);
            if (v == 0) c.erase(it);
            else it->second = v;
        }
    }

    static Poly constant(int a) {
        Poly r;
        r.add_term(0, 0, a);
        return r;
    }
    static Poly monomial(int u, int z, int a = 1) {
        Poly r;
        r.add_term(u, z, a);
        return r;
    }

    int max_z() const { return zero() ? -1 : zdeg(c.rbegin()->first); }

    Poly scaled(int a) const {
        Poly r;
        a = mod(a);
        if (a == 0) return r;
        for (const auto &[k, v] : c) r.c.emplace(k, mulm(a, v));
        return r;
    }

    Poly shifted(int du, int dz) const {
        if (du < 0 || dz < 0)
            throw std::runtime_error("negative Laurent shift survived denominator clearing");
        Poly r;
        for (const auto &[k, v] : c)
            r.add_term(udeg(k) + du, zdeg(k) + dz, v);
        return r;
    }

    Poly derivative_u() const {
        Poly r;
        for (const auto &[k, v] : c) {
            int d = udeg(k);
            if (d > 0) r.add_term(d - 1, zdeg(k), mulm(v, mod(d)));
        }
        return r;
    }

    Poly derivative_z() const {
        Poly r;
        for (const auto &[k, v] : c) {
            int d = zdeg(k);
            if (d > 0) r.add_term(udeg(k), d - 1, mulm(v, mod(d)));
        }
        return r;
    }
};

Poly operator+(Poly a, const Poly &b) {
    for (const auto &[k, v] : b.c) a.add_term(Poly::udeg(k), Poly::zdeg(k), v);
    return a;
}

Poly operator-(Poly a, const Poly &b) {
    for (const auto &[k, v] : b.c) a.add_term(Poly::udeg(k), Poly::zdeg(k), -v);
    return a;
}

Poly operator*(const Poly &a, const Poly &b) {
    Poly r;
    if (a.zero() || b.zero()) return r;
    for (const auto &[ka, va] : a.c) {
        const int ua = Poly::udeg(ka), za = Poly::zdeg(ka);
        for (const auto &[kb, vb] : b.c)
            r.add_term(ua + Poly::udeg(kb), za + Poly::zdeg(kb), mulm(va, vb));
    }
    return r;
}

Poly poly_pow(Poly a, int e) {
    if (e < 0) throw std::runtime_error("negative polynomial power");
    Poly r = Poly::constant(1);
    while (e > 0) {
        if (e & 1) r = r * a;
        e >>= 1;
        if (e) a = a * a;
    }
    return r;
}

Poly multiply_smallest_first(std::vector<Poly> factors) {
    if (factors.empty()) return Poly::constant(1);
    while (factors.size() > 1) {
        std::sort(factors.begin(), factors.end(),
                  [](const Poly &a, const Poly &b) { return a.size() < b.size(); });
        Poly p = factors[0] * factors[1];
        factors.erase(factors.begin(), factors.begin() + 2);
        factors.push_back(std::move(p));
    }
    return std::move(factors[0]);
}

// Remainder in F_p[u][z].  The leading z-coefficient of the divisor must be
// a nonzero constant.  Keeping this routine univariate over F_p[u] makes the
// divisibility test exact and deterministic.
Poly remainder_z(Poly r, const Poly &d) {
    if (d.zero()) throw std::runtime_error("zero divisor in polynomial remainder");
    const int dd = d.max_z();

    int leading_terms = 0;
    int leading_const = 0;
    for (auto it = d.c.lower_bound(Poly::key(0, dd)); it != d.c.end(); ++it) {
        if (Poly::zdeg(it->first) != dd) break;
        ++leading_terms;
        if (Poly::udeg(it->first) == 0) leading_const = it->second;
    }
    if (leading_terms != 1 || leading_const == 0)
        throw std::runtime_error("divisor has no invertible constant leading z-coefficient");
    const int leading_inverse = invm(leading_const);

    while (!r.zero() && r.max_z() >= dd) {
        const int top = r.max_z();
        const int shift_z = top - dd;
        std::vector<std::pair<int, int>> q;
        auto it = r.c.lower_bound(Poly::key(0, top));
        while (it != r.c.end() && Poly::zdeg(it->first) == top) {
            q.emplace_back(Poly::udeg(it->first), it->second);
            ++it;
        }
        for (const auto &[uq, cq0] : q) {
            const int cq=mulm(cq0,leading_inverse);
            for (const auto &[kd, cd] : d.c) {
                r.add_term(uq + Poly::udeg(kd), shift_z + Poly::zdeg(kd),
                           -mulm(cq, cd));
            }
        }
    }
    return r;
}

struct RationalDelta {
    Poly num;
    int de = 0; // denominator Delta^de
};

struct RationalRing {
    Poly Delta;
    std::vector<Poly> delta_pow;

    explicit RationalRing(Poly delta, int max_power)
        : Delta(std::move(delta)),
          delta_pow(static_cast<std::size_t>(max_power+1)) {
        delta_pow[0] = Poly::constant(1);
        for (int i = 1; i <= max_power; ++i)
            delta_pow[static_cast<std::size_t>(i)] =
                delta_pow[static_cast<std::size_t>(i-1)]*Delta;
    }

    RationalDelta polynomial(const Poly &p) const { return {p, 0}; }

    RationalDelta add(const RationalDelta &a, const RationalDelta &b) const {
        const int e = std::max(a.de, b.de);
        Poly an=a.num*delta_pow[static_cast<std::size_t>(e-a.de)];
        Poly bn=b.num*delta_pow[static_cast<std::size_t>(e-b.de)];
        return {an + bn, e};
    }

    RationalDelta neg(const RationalDelta &a) const { return {a.num.scaled(-1), a.de}; }

    RationalDelta sub(const RationalDelta &a, const RationalDelta &b) const {
        return add(a, neg(b));
    }

    RationalDelta mul(const RationalDelta &a, const RationalDelta &b) const {
        return {a.num * b.num, a.de + b.de};
    }

    RationalDelta scale_poly(const RationalDelta &a, const Poly &p) const {
        return {a.num * p, a.de};
    }

    RationalDelta scale_const(const RationalDelta &a, int s) const {
        return {a.num.scaled(s), a.de};
    }

    RationalDelta du(const RationalDelta &a) const {
        // (N/Delta^e)_u = (N_u Delta - e N Delta_u)/Delta^(e+1).
        if (a.de == 0) return {a.num.derivative_u(), 0};
        Poly n = a.num.derivative_u() * Delta;
        n = n - (a.num * Delta.derivative_u()).scaled(a.de);
        return {n, a.de + 1};
    }

    RationalDelta dz(const RationalDelta &a) const {
        if (a.de == 0) return {a.num.derivative_z(), 0};
        Poly n = a.num.derivative_z() * Delta;
        n = n - (a.num * Delta.derivative_z()).scaled(a.de);
        return {n, a.de + 1};
    }
};

struct JExp {
    int zp = 0, q = 0, wx = 0;
    bool operator<(const JExp &o) const {
        return std::tie(wx, q, zp) < std::tie(o.wx, o.q, o.zp);
    }
};

struct JetPoly {
    std::map<JExp, RationalDelta> c;
};

void jet_add_term(JetPoly &f, const JExp &e, const RationalDelta &a,
                  const RationalRing &rr) {
    if (a.num.zero()) return;
    auto it = f.c.find(e);
    if (it == f.c.end()) f.c.emplace(e, a);
    else {
        it->second = rr.add(it->second, a);
        if (it->second.num.zero()) f.c.erase(it);
    }
}

JetPoly jet_mul(const JetPoly &a, const JetPoly &b, const RationalRing &rr) {
    JetPoly r;
    for (const auto &[ea, ca] : a.c)
        for (const auto &[eb, cb] : b.c)
            jet_add_term(r, {ea.zp + eb.zp, ea.q + eb.q, ea.wx + eb.wx},
                         rr.mul(ca, cb), rr);
    return r;
}

JetPoly jet_pow(JetPoly a, int e, const RationalRing &rr) {
    JetPoly r;
    r.c.emplace(JExp{}, rr.polynomial(Poly::constant(1)));
    while (e > 0) {
        if (e & 1) r = jet_mul(r, a, rr);
        e >>= 1;
        if (e) a = jet_mul(a, a, rr);
    }
    return r;
}

JetPoly jet_monomial(const JExp &e, const RationalDelta &a) {
    JetPoly r;
    if (!a.num.zero()) r.c.emplace(e, a);
    return r;
}

JetPoly jet_add(JetPoly a, const JetPoly &b, const RationalRing &rr) {
    for (const auto &[e, c] : b.c) jet_add_term(a, e, c, rr);
    return a;
}

struct Atom {
    int layer = 0;
    int i = 0, j = 0;
    int xr = 0, ys = 0;
    int scalar = 1;
};

struct BasisVector {
    std::vector<Atom> atoms;
};

struct Orbit {
    int a = 0, b = 0; // representative character
    std::string label;
    bool diagonal() const { return a == b; }
    std::string name() const {
        if (!label.empty()) return label;
        if (a<0 || b<0) return "all";
        std::ostringstream os;
        os << a << b;
        return os.str();
    }
};

const std::array<Orbit, 6> ORBITS{{
    {0,0,"00"},{1,1,"11"},{2,2,"22"},
    {0,1,"01"},{0,2,"02"},{1,2,"12"}}};

Atom sigma_atom(const Atom &a) {
    Atom b = a;
    std::swap(b.i, b.j);
    std::swap(b.xr, b.ys);
    return b;
}

bool same_atom(const Atom &a, const Atom &b) {
    return std::tie(a.layer,a.i,a.j,a.xr,a.ys) ==
           std::tie(b.layer,b.i,b.j,b.xr,b.ys);
}

bool atom_less(const Atom &a, const Atom &b) {
    return std::tie(a.layer,a.i,a.j,a.xr,a.ys) <
           std::tie(b.layer,b.i,b.j,b.xr,b.ys);
}

std::vector<BasisVector> generate_basis(int m, const Orbit &orb, int eps,
                                        std::optional<int> only_layer = std::nullopt) {
    std::vector<BasisVector> out;
    const int K = m / 3;
    for (int k = K; k >= 0; --k) {
        if (only_layer && k != *only_layer) continue;
        const int s = m - 3*k;
        const int d = 5*m - 11*k;
        for (int i = 0; i <= s; ++i) {
            int j = s - i;
            for (int xr = 0; xr <= d; ++xr) {
                for (int ys = 0; ys + xr <= d; ++ys) {
                    if (imod3(xr + i + k) != orb.a ||
                        imod3(ys + j + k) != orb.b) continue;
                    Atom a{k,i,j,xr,ys,1};
                    Atom b = sigma_atom(a);
                    const int sig = eps * ((k & 1) ? -1 : 1);

                    if (!orb.diagonal()) {
                        b.scalar = sig;
                        out.push_back({{a,b}});
                    } else {
                        // Take one representative of each sigma orbit.
                        if (atom_less(b,a)) continue;
                        if (same_atom(a,b)) {
                            if (sig == 1) out.push_back({{a}});
                        } else {
                            b.scalar = sig;
                            out.push_back({{a,b}});
                        }
                    }
                }
            }
        }
    }
    return out;
}

int imod(int value,int modulus) {
    value%=modulus;
    if (value<0) value+=modulus;
    return value;
}

std::vector<Orbit> cyclic_orbits(int order) {
    std::vector<Orbit> out;
    out.push_back({0,0,"c0"});
    for (int character=1;character*2<order;++character)
        out.push_back({character,order-character,"c"+std::to_string(character)});
    if (order%2==0) out.push_back({order/2,order/2,"c"+std::to_string(order/2)});
    return out;
}

std::vector<Orbit> cyclic_characters(int order) {
    std::vector<Orbit> out;
    out.reserve(static_cast<std::size_t>(order));
    for (int character=0;character<order;++character)
        out.push_back({character,character,"c"+std::to_string(character)});
    return out;
}

std::vector<BasisVector> generate_cyclic_basis(
        int m,int order,int total_degree,const Orbit &orb,int eps,
        std::optional<int> only_layer=std::nullopt) {
    std::vector<BasisVector> out;
    for (int k=m/3;k>=0;--k) {
        if (only_layer && k!=*only_layer) continue;
        const int s=m-3*k;
        const int d=(total_degree-1)*m-(2*total_degree-1)*k;
        for (int i=0;i<=s;++i) {
            const int j=s-i;
            for (int xr=0;xr<=d;++xr) for (int ys=0;ys+xr<=d;++ys) {
                if (imod(xr-ys+i-j,order)!=orb.a) continue;
                Atom a{k,i,j,xr,ys,1};
                Atom b=sigma_atom(a);
                const int sig=eps*((k&1)?-1:1);
                if (!orb.diagonal()) {
                    b.scalar=sig;
                    out.push_back({{a,b}});
                } else {
                    if (atom_less(b,a)) continue;
                    if (same_atom(a,b)) {
                        if (sig==1) out.push_back({{a}});
                    } else {
                        b.scalar=sig;
                        out.push_back({{a,b}});
                    }
                }
            }
        }
    }
    return out;
}

std::vector<BasisVector> generate_cyclic_character_basis(
        int m,int order,int total_degree,const Orbit &character,
        int denominator_a_character,
        std::optional<int> only_layer=std::nullopt) {
    std::vector<BasisVector> out;
    for (int k=m/3;k>=0;--k) {
        if (only_layer && k!=*only_layer) continue;
        const int s=m-3*k;
        const int d=(total_degree-1)*m-(2*total_degree-1)*k;
        for (int i=0;i<=s;++i) {
            const int j=s-i;
            for (int xr=0;xr<=d;++xr) for (int ys=0;ys+xr<=d;++ys) {
                const int n=m-2*k;
                if (imod(xr-ys+i-j+denominator_a_character*n,order)!=
                    character.a) continue;
                out.push_back({{{k,i,j,xr,ys,1}}});
            }
        }
    }
    return out;
}

std::vector<BasisVector> generate_unsplit_basis(
        int m, int total_degree,
        std::optional<int> only_layer=std::nullopt) {
    std::vector<BasisVector> out;
    for (int k=m/3;k>=0;--k) {
        if (only_layer && k!=*only_layer) continue;
        const int s=m-3*k;
        const int d=(total_degree-1)*m-(2*total_degree-1)*k;
        if (d<0) continue;
        for (int i=0;i<=s;++i) {
            const int j=s-i;
            for (int xr=0;xr<=d;++xr)
                for (int ys=0;ys+xr<=d;++ys)
                    out.push_back({{{k,i,j,xr,ys,1}}});
        }
    }
    return out;
}

i64 raw_count(int m, int total_degree=6) {
    i64 n = 0;
    for (int k = 0; k <= m/3; ++k) {
        i64 d = static_cast<i64>(total_degree-1)*m-
                static_cast<i64>(2*total_degree-1)*k;
        if (d<0) continue;
        n += static_cast<i64>(m - 3*k + 1) * (d + 1) * (d + 2) / 2;
    }
    return n;
}

struct TemplateKey {
    int layer = 0, i = 0;
    bool operator<(const TemplateKey &o) const {
        return std::tie(layer,i) < std::tie(o.layer,o.i);
    }
};

struct Context {
    CurveConfig curve;
    int m, t;
    int total_degree;
    int K;
    Poly aX, bX, Delta, H, E;
    std::vector<Poly> a_pow, b_pow, delta_pow;
    std::vector<Poly> divisors;
    RationalRing rr;
    JetPoly first_factor;
    JetPoly w_lead;
    JetPoly w_full;
    std::map<TemplateKey, JetPoly> diagonal_templates;
    std::map<TemplateKey, JetPoly> full_templates;

    Context(int mm, int tt, CurveConfig cc={})
        : curve(std::move(cc)),m(mm), t(tt), total_degree(curve.total_degree()),K(mm/3),
          aX(curve.mixed_conic?
              (Poly::monomial(1,0,1)+Poly::monomial(0,2,1)):
              (Poly::constant(curve.a[0])+
               Poly::monomial(curve.d1,0,curve.a[1])+
               Poly::monomial(0,curve.d1,curve.a[2]))),
          bX(Poly::constant(curve.b[0])+
              Poly::monomial(curve.d2,0,curve.b[1])+
              Poly::monomial(0,curve.d2,curve.b[2])+
              (curve.linear_component && curve.d2==8?
                   Poly::monomial(4,0,1):Poly{})+
              (curve.linear_component && curve.d2==9?
                   Poly::monomial(3,3,1):Poly{})),
          // q is projectively invariant.  In diagonal cases use
          // (1/d1)dlog(a_X)-(1/d2)dlog(b_X).  For A=XY+Z^2 use
          // dlog(a_X)-(2/d2)dlog(b_X).  For A=Y and d2=8 we use the
          // integral scaling 8*dlog(a_X)-dlog(b_X).
          Delta(curve.mixed_conic?
                (bX-(aX*Poly::monomial(curve.d2-1,0,2))):
                (curve.linear_component?
                 (curve.d2==8?
                  (Poly::constant(8)+Poly::monomial(0,8,8)+
                   Poly::monomial(4,0,4)):
                  (Poly::constant(9)+Poly::monomial(0,9,9)+
                   Poly::monomial(3,3,6))):
                 ((Poly::monomial(curve.d1-1,0,curve.a[1])*bX)-
                  (aX*Poly::monomial(curve.d2-1,0,curve.b[1]))))),
          H(aX*bX),
          E(curve.mixed_conic?
            ((Poly::monomial(0,1,2)*bX)-
             (aX*Poly::monomial(0,curve.d2-1,2))):
            (curve.linear_component?
             (curve.d2==8?
              Poly::monomial(1,7,-8):
              (Poly::monomial(1,8,-9)+Poly::monomial(4,2,-3))):
             ((Poly::monomial(0,curve.d1-1,curve.a[2])*bX)-
              (aX*Poly::monomial(0,curve.d2-1,curve.b[2]))))),
          a_pow(static_cast<std::size_t>(mm+1)),
          b_pow(static_cast<std::size_t>(mm+1)),
          delta_pow(static_cast<std::size_t>(mm+1)),
          divisors(static_cast<std::size_t>(K+1)),rr(Delta,3*mm+3) {
        if (m < 1 || t < 1) throw std::runtime_error("m,t must be positive");
        build_powers_and_divisors();
        build_frames();
    }

    void build_powers_and_divisors() {
        a_pow[0] = b_pow[0] = delta_pow[0] = Poly::constant(1);
        for (int n = 1; n <= m; ++n) {
            const auto nn=static_cast<std::size_t>(n);
            const auto nm=static_cast<std::size_t>(n-1);
            a_pow[nn]=a_pow[nm]*aX;
            b_pow[nn]=b_pow[nm]*bX;
            delta_pow[nn]=delta_pow[nm]*Delta;
        }
        for (int k = 0; k <= K; ++k) {
            int n = m - 2*k;
            const auto kk=static_cast<std::size_t>(k);
            const auto nn=static_cast<std::size_t>(n);
            divisors[kk]=(a_pow[nn]*b_pow[nn]).shifted(0,n+t);
            const int expected_z_degree=
                (curve.linear_component?curve.d2+1:total_degree+1)*n+t;
            if (divisors[kk].max_z()!=expected_z_degree)
                throw std::runtime_error("unexpected divisor degree");
        }
    }

    void build_frames() {
        const Poly U = Poly::monomial(1,0,1);
        const Poly Z = Poly::monomial(0,1,1);
        const RationalDelta A{H,1};
        const RationalDelta B{E.scaled(-1),1};
        const RationalDelta Au = rr.du(A), Az = rr.dz(A);
        const RationalDelta Bu = rr.du(B), Bz = rr.dz(B);

        // z*u' - u*z' = z*A*q + (z*B-u)*z'.
        RationalDelta fq = rr.scale_poly(A,Z);
        RationalDelta fz = rr.sub(rr.scale_poly(B,Z), rr.polynomial(U));
        first_factor = jet_add(jet_monomial({0,1,0},fq),
                               jet_monomial({1,0,0},fz), rr);

        // Leading part -A*W_X.
        w_lead = jet_monomial({0,0,1}, rr.neg(A));

        // Exact formula from (u-second-exact) and (Wzu-to-WX-triangular).
        RationalDelta c2 = rr.mul(A,Au); // A A_u
        RationalDelta c1 = rr.add(rr.add(rr.mul(Au,B),Az),rr.mul(A,Bu));
        RationalDelta c0 = rr.add(rr.mul(B,Bu),Bz);
        w_full = w_lead;
        w_full = jet_add(w_full,jet_monomial({1,2,0},c2),rr);
        w_full = jet_add(w_full,jet_monomial({2,1,0},c1),rr);
        w_full = jet_add(w_full,jet_monomial({3,0,0},c0),rr);
    }

    JetPoly make_template(int layer, int i, bool full) const {
        int j = m - 3*layer - i;
        if (j < 0) throw std::runtime_error("bad source jet exponent");
        JetPoly zpi = jet_monomial({i,0,0},rr.polynomial(Poly::constant(1)));
        JetPoly fj = jet_pow(first_factor,j,rr);
        JetPoly wk = jet_pow(full ? w_full : w_lead,layer,rr);
        return jet_mul(jet_mul(zpi,fj,rr),wk,rr);
    }

    void precompute(bool full) {
        auto &cache = full ? full_templates : diagonal_templates;
        if (!cache.empty()) return;
        for (int k = 0; k <= K; ++k) {
            int s = m - 3*k;
            for (int i = 0; i <= s; ++i)
                cache.emplace(TemplateKey{k,i},make_template(k,i,full));
        }
    }

    const JetPoly &get_template(int layer, int i, bool full) const {
        const auto &cache = full ? full_templates : diagonal_templates;
        auto it = cache.find({layer,i});
        if (it == cache.end()) throw std::runtime_error("template not precomputed");
        return it->second;
    }
};

using RowKey = u64;

RowKey row_key(int K, int target_layer, int qdeg, int udeg, int zdeg,
               int condition=0) {
    const int qslot=32*condition+qdeg;
    if (K-target_layer >= 256 || qdeg >= 32 || condition<0 || condition>=8 ||
        qslot >= 256 || udeg >= (1<<20) || zdeg >= (1<<20))
        throw std::runtime_error("row exponent out of range");
    return (static_cast<RowKey>(K-target_layer) << 56) |
           (static_cast<RowKey>(qslot) << 48) |
           (static_cast<RowKey>(zdeg) << 24) |
           static_cast<RowKey>(udeg);
}

std::string decode_row(RowKey r, int K) {
    int ko = static_cast<int>((r >> 56) & 0xffU);
    int qslot = static_cast<int>((r >> 48) & 0xffU);
    int condition=qslot/32;
    int q=qslot%32;
    int z = static_cast<int>((r >> 24) & 0xffffffU);
    int u = static_cast<int>(r & 0xffffffU);
    std::ostringstream os;
    os << "(" << condition << "," << (K-ko) << "," << q << ","
       << u << "," << z << ")";
    return os.str();
}

using SparseVector = std::map<RowKey,int>;

void hash_u64(u64 &h,u64 value) {
    // FNV-1a on an explicit little-endian eight-byte encoding.
    for (int byte=0;byte<8;++byte) {
        h^=(value>>static_cast<unsigned>(8*byte))&0xffULL;
        h*=1099511628211ULL;
    }
}

void vector_add(SparseVector &v, RowKey r, int a) {
    a = mod(a);
    if (a == 0) return;
    auto it = v.find(r);
    if (it == v.end()) v.emplace(r,a);
    else {
        int x = addm(it->second,a);
        if (x == 0) v.erase(it);
        else it->second = x;
    }
}

void add_poly_to_column(SparseVector &v, const Poly &r, int K,
                        int target_layer, int qdeg, int scale,
                        int condition=0) {
    for (const auto &[pk,c] : r.c)
        vector_add(v,row_key(K,target_layer,qdeg,Poly::udeg(pk),Poly::zdeg(pk),
                             condition),
                   mulm(scale,c));
}

void add_low_exponent_terms(SparseVector &v,const Poly &polynomial,int K,
                            int target_layer,int qdeg,int threshold,
                            bool use_z_degree,int condition) {
    for (const auto &[pk,c]:polynomial.c) {
        const int exponent=use_z_degree?Poly::zdeg(pk):Poly::udeg(pk);
        if (exponent<threshold)
            vector_add(v,row_key(K,target_layer,qdeg,Poly::udeg(pk),
                                 Poly::zdeg(pk),condition),c);
    }
}

// Add the image of one source monomial to a matrix column.
void add_atom_image(SparseVector &column, const Context &ctx, const Atom &a,
                    bool full) {
    const int source_k = a.layer;
    const int nr = ctx.m - 2*source_k;
    const int degree = a.xr + a.ys;
    const int chart_sign = ((a.i + source_k) & 1) ? -1 : 1;
    const int scalar = mod(a.scalar * chart_sign);
    const JetPoly &templ = ctx.get_template(source_k,a.i,full);

    for (const auto &[je,rat] : templ.c) {
        const int target_k = je.wx;
        if (!full && target_k != source_k) continue;
        const int nt = ctx.m - 2*target_k;
        const int st = ctx.m - 3*target_k;
        if (je.zp + je.q != st)
            throw std::runtime_error("jet weight invariant failed");
        if (nt < nr || rat.de > nt)
            throw std::runtime_error("denominator bound n_k failed");

        // N_{j,k}=z^nt aX^nt bX^nt Delta^nt R_{j,k}.
        // P=x^xr y^ys contributes u^ys times
        // z^((d1+d2-2)m+(-2(d1+d2)+3)r-xr-ys).
        const int zshift = nt+(ctx.total_degree-2)*ctx.m+
                           (-2*ctx.total_degree+3)*source_k-degree;
        if (zshift < 0)
            throw std::runtime_error("z-pole bound failed");

        std::vector<Poly> factors;
        factors.push_back(rat.num);
        if (nt > nr) {
            const auto diff=static_cast<std::size_t>(nt-nr);
            factors.push_back(ctx.a_pow[diff]);
            factors.push_back(ctx.b_pow[diff]);
        }
        if (nt>rat.de)
            factors.push_back(ctx.delta_pow[static_cast<std::size_t>(nt-rat.de)]);
        Poly N = multiply_smallest_first(std::move(factors));
        N = N.shifted(a.ys,zshift).scaled(scalar);
        if (ctx.curve.linear_component) {
            // Here a_X=u.  The three factors z^(nt+t), u^nt, and b_X^nt
            // are pairwise coprime.  Testing divisibility by them separately
            // avoids pretending that their product is monic in z.
            add_low_exponent_terms(column,N,ctx.K,target_k,je.q,nt+ctx.t,
                                   true,1);
            add_low_exponent_terms(column,N,ctx.K,target_k,je.q,nt,
                                   false,2);
            Poly rem_b=remainder_z(
                N,ctx.b_pow[static_cast<std::size_t>(nt)]);
            add_poly_to_column(column,rem_b,ctx.K,target_k,je.q,1,3);
        } else {
            Poly rem=remainder_z(
                std::move(N),ctx.divisors[static_cast<std::size_t>(target_k)]);
            add_poly_to_column(column,rem,ctx.K,target_k,je.q,1);
        }
    }
}

SparseVector build_column(const Context &ctx, const BasisVector &b, bool full) {
    SparseVector v;
    for (const Atom &a : b.atoms) add_atom_image(v,ctx,a,full);
    return v;
}

struct RankResult {
    i64 columns = 0;
    i64 rows = 0;
    i64 rank = 0;
    int det_mod_p = 1;
    std::vector<RowKey> pivot_rows;
    u64 pivot_hash = 1469598103934665603ULL;
    u64 matrix_hash = 1469598103934665603ULL;
    u64 echelon_hash = 1469598103934665603ULL;
    double seconds = 0.0;
};

RankResult sparse_column_rank(const Context &ctx,
                              const std::vector<BasisVector> &basis,
                              bool full, bool keep_pivots) {
    const auto started = std::chrono::steady_clock::now();
    std::map<RowKey,SparseVector> pivots;
    std::set<RowKey> encountered_rows;
    RankResult ans;
    ans.columns = static_cast<i64>(basis.size());
    if (keep_pivots) ans.pivot_rows.reserve(basis.size());

    for (std::size_t col = 0; col < basis.size(); ++col) {
        SparseVector v = build_column(ctx,basis[col],full);
        hash_u64(ans.matrix_hash,static_cast<u64>(col));
        hash_u64(ans.matrix_hash,static_cast<u64>(v.size()));
        for (const auto &[row, coefficient] : v) {
            hash_u64(ans.matrix_hash,row);
            hash_u64(ans.matrix_hash,static_cast<u64>(coefficient));
            encountered_rows.insert(row);
        }
        while (!v.empty()) {
            auto lead = v.begin();
            RowKey row = lead->first;
            int coeff = lead->second;
            auto pit = pivots.find(row);
            if (pit == pivots.end()) {
                ans.det_mod_p = mulm(ans.det_mod_p,coeff);
                int inv = invm(coeff);
                for (auto &entry : v) entry.second = mulm(entry.second,inv);
                pivots.emplace(row,std::move(v));
                const auto &stored=pivots.find(row)->second;
                hash_u64(ans.echelon_hash,row);
                hash_u64(ans.echelon_hash,static_cast<u64>(stored.size()));
                for (const auto &[erow,ecoeff]:stored) {
                    hash_u64(ans.echelon_hash,erow);
                    hash_u64(ans.echelon_hash,static_cast<u64>(ecoeff));
                }
                ++ans.rank;
                ans.pivot_hash ^= row;
                ans.pivot_hash *= 1099511628211ULL;
                if (keep_pivots) ans.pivot_rows.push_back(row);
                break;
            }
            // The stored pivot is normalized to coefficient 1.
            for (const auto &[r,c] : pit->second)
                vector_add(v,r,-mulm(coeff,c));
        }
    }
    ans.seconds = std::chrono::duration<double>(
        std::chrono::steady_clock::now()-started).count();
    ans.rows = static_cast<i64>(encountered_rows.size());
    if (ans.rank != ans.columns) ans.det_mod_p = 0;
    return ans;
}

struct LayerResult {
    int layer = -1;
    RankResult rank;
};

struct BlockResult {
    Orbit orbit;
    int eps = 1;
    bool proved = false;
    bool used_full = false;
    std::vector<LayerResult> layers;
    RankResult full_rank;
};

BlockResult run_diagonal_block(const Context &ctx, const Orbit &orb, int eps,
                               bool keep_pivots) {
    BlockResult br;
    br.orbit = orb;
    br.eps = eps;
    br.proved = true;
    for (int k = ctx.K; k >= 0; --k) {
        std::vector<BasisVector> basis;
        if (ctx.curve.symmetry==CurveConfig::Symmetry::cyclic)
            basis=ctx.curve.cyclic_involution?
                generate_cyclic_basis(ctx.m,ctx.curve.cyclic_order,
                                      ctx.total_degree,orb,eps,k):
                generate_cyclic_character_basis(ctx.m,ctx.curve.cyclic_order,
                                                ctx.total_degree,orb,1,k);
        else basis=generate_basis(ctx.m,orb,eps,k);
        RankResult rr = sparse_column_rank(ctx,basis,false,keep_pivots);
        br.layers.push_back({k,std::move(rr)});
        if (br.layers.back().rank.rank != br.layers.back().rank.columns)
            br.proved = false;
    }
    return br;
}

BlockResult run_full_block(const Context &ctx, const Orbit &orb, int eps,
                           bool keep_pivots) {
    BlockResult br;
    br.orbit = orb;
    br.eps = eps;
    br.used_full = true;
    std::vector<BasisVector> basis;
    if (ctx.curve.symmetry==CurveConfig::Symmetry::cyclic)
        basis=ctx.curve.cyclic_involution?
            generate_cyclic_basis(ctx.m,ctx.curve.cyclic_order,
                                  ctx.total_degree,orb,eps):
            generate_cyclic_character_basis(ctx.m,ctx.curve.cyclic_order,
                                            ctx.total_degree,orb,1);
    else basis=generate_basis(ctx.m,orb,eps);
    br.full_rank = sparse_column_rank(ctx,basis,true,keep_pivots);
    br.proved = br.full_rank.rank == br.full_rank.columns;
    return br;
}

BlockResult run_unsplit_block(const Context &ctx, bool keep_pivots) {
    BlockResult br;
    br.orbit={-1,-1,"all"};
    br.eps=0;
    br.used_full=true;
    auto basis=generate_unsplit_basis(ctx.m,ctx.total_degree);
    br.full_rank=sparse_column_rank(ctx,basis,true,keep_pivots);
    br.proved=br.full_rank.rank==br.full_rank.columns;
    return br;
}

std::string json_escape(const std::string &s) {
    std::ostringstream os;
    for (char c : s) {
        if (c == '"' || c == '\\') os << '\\' << c;
        else if (c == '\n') os << "\\n";
        else os << c;
    }
    return os.str();
}

void write_rank_json(std::ostream &os, const RankResult &r, int K,
                     bool full_certificate) {
    os << "{\"columns\":" << r.columns
       << ",\"rows\":" << r.rows
       << ",\"rank\":" << r.rank
       << ",\"nullity\":" << (r.columns-r.rank)
       << ",\"det_mod_p\":" << r.det_mod_p
       << ",\"pivot_hash\":\"" << std::hex << r.pivot_hash << std::dec << "\""
       << ",\"matrix_hash\":\"" << std::hex << r.matrix_hash << std::dec << "\""
       << ",\"echelon_hash\":\"" << std::hex << r.echelon_hash << std::dec << "\""
       << ",\"seconds\":" << std::fixed << std::setprecision(6) << r.seconds;
    if (full_certificate) {
        os << ",\"pivot_rows\":[";
        for (std::size_t i=0;i<r.pivot_rows.size();++i) {
            if (i) os << ',';
            os << '"' << decode_row(r.pivot_rows[i],K) << '"';
        }
        os << ']';
    }
    os << '}';
}

void write_case_json(std::ostream &os, int m, int t, int p,
                     const CurveConfig &curve,
                     const std::vector<BlockResult> &blocks,
                     bool full_certificate) {
    bool proved = std::all_of(blocks.begin(),blocks.end(),
                              [](const BlockResult &b){return b.proved;});
    os << "{\"kind\":\"finite-vanishing-case\",\"m\":" << m
       << ",\"t\":" << t << ",\"d1\":" << curve.d1
       << ",\"d2\":" << curve.d2 << ",\"prime\":" << p
       << ",\"proved\":" << (proved?"true":"false")
       << ",\"blocks\":[";
    for (std::size_t b=0;b<blocks.size();++b) {
        if (b) os << ',';
        const auto &br=blocks[b];
        os << "{\"character_orbit\":\"" << br.orbit.name()
           << "\",\"epsilon\":" << br.eps
           << ",\"proof\":\"" << (br.used_full?"full":"diagonal-triangular")
           << "\",\"proved\":" << (br.proved?"true":"false");
        if (br.used_full) {
            os << ",\"rank_data\":";
            write_rank_json(os,br.full_rank,m/3,full_certificate);
        } else {
            os << ",\"layers\":[";
            for (std::size_t q=0;q<br.layers.size();++q) {
                if (q) os << ',';
                os << "{\"k\":" << br.layers[q].layer << ",\"rank_data\":";
                write_rank_json(os,br.layers[q].rank,m/3,full_certificate);
                os << '}';
            }
            os << ']';
        }
        os << '}';
    }
    os << "]}\n";
}

struct Options {
    bool self_test = false;
    bool all = false;
    bool all_explicit = false;
    bool full_certificate = false;
    int m = -1, t = -1;
    int d1 = 3, d2 = 3;
    int prime = 5;
    int jobs = 1;
    std::string orbit;
    int epsilon = 0;
    std::string mode = "auto";
    std::string profile = "baseline";
    bool estimate_only = false;
    bool list_shards = false;
    std::string certificate = "finite_vanishing_certificate.jsonl";
    std::string report = "finite_vanishing_report.txt";
    std::string shard_prefix;
};

bool known_profile(const std::string &profile) {
    return profile=="baseline" || profile=="smt38" || profile=="smt23" ||
           profile=="smt57" || profile=="smt27";
}

bool cubic_only_profile(const std::string &profile) {
    return profile!="baseline";
}

int cubic_profile_maximum(const std::string &profile) {
    if (profile=="baseline") return 12;
    if (profile=="smt38" || profile=="smt57") return 14;
    if (profile=="smt23") return 17;
    if (profile=="smt27") return 20;
    throw std::runtime_error("unknown finite-range profile: "+profile);
}

int cubic_profile_twist(const std::string &profile,int m) {
    if (profile=="baseline") return (m+3)/4;
    if (profile=="smt38" || profile=="smt57") return (m+5)/5;
    if (profile=="smt23") return (m+6)/6;
    if (profile=="smt27") return (m+7)/7;
    throw std::runtime_error("unknown finite-range profile: "+profile);
}

void warn_legacy_profile(const std::string &profile) {
    if (profile=="smt57")
        std::cerr << "WARNING: --profile smt57 is a deprecated compatibility "
                     "alias of --profile smt38; both enumerate the same 14 "
                     "cases and 168 symmetry shards.\n";
    else if (profile=="smt27")
        std::cerr << "WARNING: --profile smt27 is a deprecated legacy profile "
                     "that retains t=ceil((m+1)/7), 1<=m<=20.  Use smt23 for "
                     "the revised 17-case range.\n";
}

void usage(std::ostream &os) {
    os <<
      "Usage:\n"
      "  two_components_finite_vanishing_O3 --self-test\n"
      "  two_components_finite_vanishing_O3 --m M --t T [options]\n"
      "  two_components_finite_vanishing_O3 --all [options]\n\n"
      "Options:\n"
      "  --prime P             prime modulus, P != 2,3 (default 5)\n"
      "  --degrees D1 D2       supported pair (default 3 3)\n"
      "  --mode auto|diagonal|full\n"
      "  --profile baseline|smt38|smt23|smt57|smt27\n"
      "                        cubic finite-range profile; smt57 and smt27 are legacy\n"
      "  --jobs N              parallel character blocks (default 1)\n"
      "  --orbit NAME          one symmetry orbit (cubic: 00,...; cyclic: c0,...)\n"
      "  --epsilon -1|1        with --orbit, run one involution eigenspace\n"
      "                        (omit for the degree-one character blocks)\n"
      "  --certificate FILE    write JSONL certificates to FILE\n"
      "  --report FILE         write a human-readable rank report\n"
      "  --shard-prefix PREFIX derive unique case/block output names from PREFIX\n"
      "  --full-certificate    include every pivot-row label\n"
      "  --estimate-only       print exact variable/block counts; build no matrices\n"
      "  --list-shards         print one reproducible command per symmetry shard\n"
      "  --all-explicit        run every t from the profile minimum through 3\n";
}

Options parse_options(int argc, char **argv) {
    Options o;
    auto need = [&](int &i)->std::string {
        if (++i >= argc) throw std::runtime_error("missing option value");
        return argv[i];
    };
    for (int i=1;i<argc;++i) {
        std::string a=argv[i];
        if (a=="--self-test") o.self_test=true;
        else if (a=="--all") o.all=true;
        else if (a=="--all-explicit") {o.all=true;o.all_explicit=true;}
        else if (a=="--full-certificate") o.full_certificate=true;
        else if (a=="--m") o.m=std::stoi(need(i));
        else if (a=="--t") o.t=std::stoi(need(i));
        else if (a=="--degrees") {o.d1=std::stoi(need(i));o.d2=std::stoi(need(i));}
        else if (a=="--prime") o.prime=std::stoi(need(i));
        else if (a=="--jobs") o.jobs=std::stoi(need(i));
        else if (a=="--orbit") o.orbit=need(i);
        else if (a=="--epsilon") o.epsilon=std::stoi(need(i));
        else if (a=="--mode") o.mode=need(i);
        else if (a=="--profile") o.profile=need(i);
        else if (a=="--estimate-only") o.estimate_only=true;
        else if (a=="--list-shards") o.list_shards=true;
        else if (a=="--certificate") o.certificate=need(i);
        else if (a=="--report") o.report=need(i);
        else if (a=="--shard-prefix") o.shard_prefix=need(i);
        else if (a=="--help" || a=="-h") {usage(std::cout);std::exit(0);}
        else throw std::runtime_error("unknown option: "+a);
    }
    if (!is_prime(o.prime) || o.prime==2 || o.prime==3)
        throw std::runtime_error("prime must be a prime different from 2 and 3");
    if (o.mode!="auto" && o.mode!="diagonal" && o.mode!="full")
        throw std::runtime_error("mode must be auto, diagonal, or full");
    if (!known_profile(o.profile))
        throw std::runtime_error(
            "profile must be baseline, smt38, smt23, smt57, or smt27");
    if (o.jobs<1) throw std::runtime_error("jobs must be positive");
    (void)curve_config(o.d1,o.d2);
    if (!o.orbit.empty()) {
        const auto config=curve_config(o.d1,o.d2);
        if (config.symmetry==CurveConfig::Symmetry::none)
            throw std::runtime_error("--orbit requires a configured finite symmetry");
        if (config.cyclic_involution) {
            if (o.epsilon!=-1 && o.epsilon!=1)
                throw std::runtime_error("--orbit requires --epsilon -1 or 1");
        } else if (o.epsilon!=0) {
            throw std::runtime_error(
                "the degree-one cyclic-character shards do not use --epsilon");
        }
    } else if (o.epsilon!=0) {
        throw std::runtime_error("--epsilon requires --orbit");
    }
    if (o.m>20 || o.t>3)
        throw std::runtime_error("this audited build is bounded by m<=20 and t<=3");
    return o;
}

void self_test() {
    const std::array<std::pair<int,i64>,3> counts{{
        {4,1265},{8,11109},{12,44570}}};
    for (auto [m,want] : counts) {
        i64 got=raw_count(m);
        if (got!=want) throw std::runtime_error("raw variable count self-test failed");
    }

    for (int m=1;m<=12;++m) {
        i64 symmetry_total=0;
        i64 max_block=0;
        for (const auto &o:ORBITS) for (int eps:{-1,1}) {
            i64 n=static_cast<i64>(generate_basis(m,o,eps).size());
            symmetry_total+=n;
            max_block=std::max(max_block,n);
        }
        if (symmetry_total!=raw_count(m))
            throw std::runtime_error("character/eigenspace count self-test failed at m="+
                                     std::to_string(m));
        if (m==4 && max_block!=156) throw std::runtime_error("m=4 block count failed");
        if (m==8 && max_block!=1303) throw std::runtime_error("m=8 block count failed");
        if (m==12 && max_block!=5141) throw std::runtime_error("m=12 block count failed");
    }

    i64 total = 0;
    for (int t=1;t<=3;++t)
        for (int m=1;m<=4*t;++m) total += raw_count(m);
    if (total!=173991)
        throw std::runtime_error("finite-range total count self-test failed");

    // Verify the polynomial remainder routine on f=q*d+r.
    Poly u=Poly::monomial(1,0), z=Poly::monomial(0,1);
    Poly d=poly_pow(z,3)+(u*Poly::constant(2))+Poly::constant(1);
    Poly q=poly_pow(u,2)+z+Poly::constant(3);
    Poly r=u+Poly::constant(4);
Poly got=remainder_z(q*d+r,d);
    if (got.c!=r.c) throw std::runtime_error("polynomial remainder self-test failed");

    // Low-degree end-to-end cases.  These are deliberately tiny and fast.
    for (auto [m,t] : std::array<std::pair<int,int>,2>{{{1,1},{2,1}}}) {
        Context ctx(m,t);
        ctx.precompute(false);
        for (const auto &o:ORBITS) for (int eps:{-1,1}) {
            BlockResult b=run_diagonal_block(ctx,o,eps,false);
            if (!b.proved)
                throw std::runtime_error("low-degree vanishing self-test failed");
        }
    }
    // Independent unsplit-basis counts for every supported total degree.
    for (int total_degree:{6,7,8,9,10}) for (int m=1;m<=4;++m) {
        const auto basis=generate_unsplit_basis(m,total_degree);
        if (static_cast<i64>(basis.size())!=raw_count(m,total_degree))
            throw std::runtime_error("unsplit-basis count self-test failed");
    }
    for (int order:{5,6}) for (int m=1;m<=7;++m) {
        i64 symmetry_total=0;
        for (const auto &orbit:cyclic_orbits(order)) for (int eps:{-1,1})
            symmetry_total+=static_cast<i64>(
                generate_cyclic_basis(m,order,order+2,orbit,eps).size());
        if (symmetry_total!=raw_count(m,order+2))
            throw std::runtime_error("cyclic-symmetry exhaustion self-test failed");
    }
    for (int order:{8,9}) for (int m=1;m<=8;++m) {
        i64 symmetry_total=0;
        for (const auto &character:cyclic_characters(order))
            symmetry_total+=static_cast<i64>(
                generate_cyclic_character_basis(m,order,order+1,
                                                character,1).size());
        if (symmetry_total!=raw_count(m,order+1))
            throw std::runtime_error(
                "degree-one cyclic-symmetry exhaustion self-test failed");
    }
    // Fingerprint the special degree-one frame.  These equalities guard the
    // integral projectively invariant forms e*dlog(a_X)-dlog(b_X).
    {
        Context line_ctx(3,2,curve_config(1,8));
        const Poly expected_a=Poly::monomial(1,0,1);
        const Poly expected_b=Poly::constant(1)+Poly::monomial(8,0,1)+
            Poly::monomial(0,8,1)+Poly::monomial(4,0,1);
        const Poly expected_delta=Poly::constant(8)+Poly::monomial(0,8,8)+
            Poly::monomial(4,0,4);
        const Poly expected_e=Poly::monomial(1,7,-8);
        if (line_ctx.aX.c!=expected_a.c || line_ctx.bX.c!=expected_b.c ||
            line_ctx.Delta.c!=expected_delta.c || line_ctx.E.c!=expected_e.c)
            throw std::runtime_error("degree-(1,8) mixed-frame fingerprint failed");
    }
    {
        Context line_ctx(3,3,curve_config(1,9));
        const Poly expected_a=Poly::monomial(1,0,1);
        const Poly expected_b=Poly::constant(1)+Poly::monomial(9,0,1)+
            Poly::monomial(0,9,1)+Poly::monomial(3,3,1);
        const Poly expected_delta=Poly::constant(9)+Poly::monomial(0,9,9)+
            Poly::monomial(3,3,6);
        const Poly expected_e=Poly::monomial(1,8,-9)+
            Poly::monomial(4,2,-3);
        if (line_ctx.aX.c!=expected_a.c || line_ctx.bX.c!=expected_b.c ||
            line_ctx.Delta.c!=expected_delta.c || line_ctx.E.c!=expected_e.c)
            throw std::runtime_error("degree-(1,9) mixed-frame fingerprint failed");
    }
    // Verify equivariance of the complete transformed equations, not merely
    // exhaustion of the source monomials.  A cleared target row with monomial
    // u^U z^Z, q-degree Q, and target layer k has character
    // -2U-Z+2(m-2k)+Q modulo e.
    for (int order:{8,9}) {
        Context line_ctx(3,order==8?2:3,curve_config(1,order));
        line_ctx.precompute(true);
        for (const auto &character:cyclic_characters(order)) {
            const auto basis=generate_cyclic_character_basis(
                3,order,order+1,character,1);
            for (const auto &basis_vector:basis) {
                const SparseVector column=build_column(line_ctx,basis_vector,true);
                for (const auto &[row,coefficient]:column) {
                    (void)coefficient;
                    const int target_k=line_ctx.K-
                        static_cast<int>((row>>56)&0xffU);
                    const int qslot=static_cast<int>((row>>48)&0xffU);
                    const int qdegree=qslot%32;
                    const int zdegree=static_cast<int>((row>>24)&0xffffffU);
                    const int udegree=static_cast<int>(row&0xffffffU);
                    const int target_n=line_ctx.m-2*target_k;
                    const int row_character=imod(
                        -2*udegree-zdegree+2*target_n+qdegree,order);
                    if (row_character!=character.a)
                        throw std::runtime_error(
                            "degree-one transformed-row equivariance failed");
                }
            }
        }
    }
    // A deterministic exact-matrix regression fingerprint.  Unlike a mere
    // dimension check, this detects changes in chart transformation,
    // denominator clearing, monomial order, and elimination.
    if (MODULUS==5) {
        Context ctx(2,1);
        ctx.precompute(true);
        const auto regression=run_full_block(ctx,{0,0,"00"},-1,false).full_rank;
        if (regression.columns!=12 || regression.rank!=12 ||
            regression.matrix_hash!=0xd99b62be8d7cd0a8ULL ||
            regression.echelon_hash!=0x044e2c4d276612f8ULL)
            throw std::runtime_error("deterministic matrix fingerprint failed");
    }
    std::cout << "SELF-TEST PASSED: formulas, counts, symmetry blocks, and m=1,2 vanishing.\n";
}

std::vector<BlockResult> run_case(const Options &opt, int m, int t) {
    const CurveConfig curve=curve_config(opt.d1,opt.d2);
    Context ctx(m,t,curve);
    const bool want_full = opt.mode=="full";
    ctx.precompute(want_full || curve.symmetry==CurveConfig::Symmetry::none);

    if (curve.symmetry==CurveConfig::Symmetry::none) {
        BlockResult result=run_unsplit_block(ctx,opt.full_certificate);
        std::cerr << "m=" << m << " t=" << t << " block=all "
                  << (result.proved?"FULL-RANK":"DEFICIENT") << "\n";
        return {std::move(result)};
    }

    std::vector<std::pair<Orbit,int>> tasks;
    const std::vector<Orbit> active_orbits=
        curve.symmetry==CurveConfig::Symmetry::cyclic?
        (curve.cyclic_involution?cyclic_orbits(curve.cyclic_order):
                                 cyclic_characters(curve.cyclic_order)):
        std::vector<Orbit>(ORBITS.begin(),ORBITS.end());
    const std::vector<int> active_eps=curve.cyclic_involution?
        std::vector<int>{-1,1}:std::vector<int>{0};
    for (const auto &o:active_orbits) for (int eps:active_eps) {
        if (!opt.orbit.empty() && (o.name()!=opt.orbit || eps!=opt.epsilon))
            continue;
        tasks.emplace_back(o,eps);
    }
    if (tasks.empty()) throw std::runtime_error("requested symmetry orbit does not exist");
    std::vector<BlockResult> results(tasks.size());
    std::atomic<std::size_t> next{0};
    std::mutex io_mutex;

    auto worker=[&]() {
        while (true) {
            std::size_t q=next.fetch_add(1);
            if (q>=tasks.size()) return;
            const auto &[orb,eps]=tasks[q];
            BlockResult r = want_full
                ? run_full_block(ctx,orb,eps,opt.full_certificate)
                : run_diagonal_block(ctx,orb,eps,opt.full_certificate);
            results[q]=std::move(r);
            std::lock_guard<std::mutex> lock(io_mutex);
            std::cerr << "m=" << m << " t=" << t << " chi=" << orb.name();
            if (curve.cyclic_involution) std::cerr << " eps=" << eps;
            std::cerr << " "
                      << (results[q].proved?"FULL-RANK":"DEFICIENT") << "\n";
        }
    };
    std::vector<std::thread> pool;
    int nj=std::min<int>(opt.jobs,static_cast<int>(tasks.size()));
    for (int j=0;j<nj;++j) pool.emplace_back(worker);
    for (auto &th:pool) th.join();

    if (opt.mode=="auto") {
        std::vector<std::size_t> deficient;
        for (std::size_t q=0;q<results.size();++q)
            if (!results[q].proved) deficient.push_back(q);
        if (!deficient.empty()) {
            std::cerr << "Diagonal test deficient in " << deficient.size()
                      << " block(s); building the exact full transformation.\n";
            ctx.precompute(true);
            next.store(0);
            auto full_worker=[&]() {
                while (true) {
                    std::size_t j=next.fetch_add(1);
                    if (j>=deficient.size()) return;
                    std::size_t q=deficient[j];
                    const auto &[orb,eps]=tasks[q];
                    results[q]=run_full_block(ctx,orb,eps,opt.full_certificate);
                }
            };
            pool.clear();
            nj=std::min<int>(opt.jobs,static_cast<int>(deficient.size()));
            for (int j=0;j<nj;++j) pool.emplace_back(full_worker);
            for (auto &th:pool) th.join();
        }
    }
    return results;
}

std::string finite_range_description(const CurveConfig &curve,
                                     const std::string &profile) {
    if (curve.d1==3 && curve.d2==3 && profile=="smt38")
        return "SMT-38 profile: t=ceil((m+1)/5), 1<=m<=14";
    if (curve.d1==3 && curve.d2==3 && profile=="smt23")
        return "SMT-23 profile: t=ceil((m+1)/6), 1<=m<=17";
    if (curve.d1==3 && curve.d2==3 && profile=="smt57")
        return "deprecated smt57 alias of SMT-38: t=ceil((m+1)/5), 1<=m<=14";
    if (curve.d1==3 && curve.d2==3 && profile=="smt27")
        return "deprecated legacy smt27 profile: t=ceil((m+1)/7), 1<=m<=20";
    if (curve.d1==3 && curve.d2==3)
        return "minimal twists t=ceil(m/4), 1<=m<=12";
    if ((curve.d1==3 && curve.d2==4) ||
        (curve.d1==2 && curve.d2==6)) return "(m,t)=(3,3)";
    if (curve.d1==2 && curve.d2==5)
        return "(m,t)=(3,2),(4,2),(5,2),(6,3),(7,3),(8,3)";
    if (curve.d1==1 && curve.d2==8)
        return "(m,t)=(3,2),(4,2),(5,2),(6,3),(7,3),(8,3)";
    if (curve.d1==1 && curve.d2==9)
        return "(m,t)=(3,3),(4,3)";
    return "(m,t)=(3,2),(4,2),(5,2),(6,3),(7,3)";
}

void write_human_header(std::ostream &os, int p, const std::string &mode,
                        const CurveConfig &curve,const std::string &profile) {
    os << "FINITE VANISHING VERIFICATION FOR TWO PLANE-CURVE COMPONENTS\n"
       << curve.description() << "\n"
       << "Target: H^0(P^2,E_{2,m}T^*(log(A+B)) tensor O(-t))=0\n"
       << "Finite range: " << finite_range_description(curve,profile) << "\n"
       << "Field: F_" << p << "\n"
       << "Mode: " << mode << "\n\n";
}

void write_human_case(std::ostream &os, int m, int t,
                      const std::vector<BlockResult> &blocks) {
    bool proved = std::all_of(blocks.begin(),blocks.end(),
                              [](const BlockResult &b){return b.proved;});
    os << "CASE (m,t)=(" << m << ',' << t << ")\n"
       << "chi  eps  method                 rows  columns  rank  nullity  det  seconds  result\n";
    for (const auto &br:blocks) {
        if (br.used_full) {
            const auto &r=br.full_rank;
            os << std::setw(3) << br.orbit.name() << "  "
               << std::setw(3) << br.eps << "  "
               << std::left << std::setw(21) << "full" << std::right
               << std::setw(7) << r.rows
               << std::setw(9) << r.columns
               << std::setw(6) << r.rank
               << std::setw(9) << (r.columns-r.rank)
               << std::setw(5) << r.det_mod_p
               << std::setw(9) << std::fixed << std::setprecision(3) << r.seconds
               << "  " << (br.proved?"ZERO":"UNRESOLVED") << "\n";
            if (br.proved)
                os << "Voir_" << m << '_' << t << "_chi" << br.orbit.name()
                   << "_eps" << (br.eps==0?"none":(br.eps>0?"plus":"minus"))
                   << " := 0;\n";
        } else {
            for (const auto &lr:br.layers) {
                const auto &r=lr.rank;
                std::ostringstream method;
                method << "diagonal k=" << lr.layer;
                os << std::setw(3) << br.orbit.name() << "  "
                   << std::setw(3) << br.eps << "  "
                   << std::left << std::setw(21) << method.str() << std::right
                   << std::setw(7) << r.rows
                   << std::setw(9) << r.columns
                   << std::setw(6) << r.rank
                   << std::setw(9) << (r.columns-r.rank)
                   << std::setw(5) << r.det_mod_p
                   << std::setw(9) << std::fixed << std::setprecision(3) << r.seconds
                   << "  " << (r.rank==r.columns?"ZERO":"UNRESOLVED") << "\n";
            }
            if (br.proved)
                os << "Voir_" << m << '_' << t << "_chi" << br.orbit.name()
                   << "_eps" << (br.eps==0?"none":(br.eps>0?"plus":"minus"))
                   << " := 0;\n";
        }
    }
    os << "CASE RESULT: " << (proved?"VANISHING PROVED":"NOT PROVED") << "\n\n";
}

std::vector<std::pair<int,int>> selected_cases(const Options &opt,
                                                const CurveConfig &curve) {
    if (!opt.all) return {{opt.m,opt.t}};
    std::vector<std::pair<int,int>> cases;
    if (curve.d1==3 && curve.d2==3) {
        const int maximum=cubic_profile_maximum(opt.profile);
        for (int m=1;m<=maximum;++m) {
            const int t0=cubic_profile_twist(opt.profile,m);
            if (opt.all_explicit)
                for (int t=t0;t<=3;++t) cases.emplace_back(m,t);
            else cases.emplace_back(m,t0);
        }
    } else if ((curve.d1==3 && curve.d2==4) ||
               (curve.d1==2 && curve.d2==6)) {
        cases.emplace_back(3,3);
    } else if (curve.d1==1 && curve.d2==8) {
        cases={{3,2},{4,2},{5,2},{6,3},{7,3},{8,3}};
    } else if (curve.d1==1 && curve.d2==9) {
        cases={{3,3},{4,3}};
    } else if (curve.d1==2 && curve.d2==5) {
        cases={{3,2},{4,2},{5,2},{6,3},{7,3},{8,3}};
    } else {
        cases={{3,2},{4,2},{5,2},{6,3},{7,3}};
    }
    return cases;
}

void print_estimates(const CurveConfig &curve,
                     const std::vector<std::pair<int,int>> &cases) {
    std::cout << "degree_pair,m,t,raw_variables,blocks,max_block_variables,"
                 "max_layer_block_variables\n";
    for (const auto &[m,t]:cases) {
        i64 maximum=0,maximum_layer=0;
        int blocks=1;
        if (curve.symmetry==CurveConfig::Symmetry::product_mu3) {
            blocks=12;
            for (const auto &orbit:ORBITS) for (int eps:{-1,1}) {
                maximum=std::max(maximum,static_cast<i64>(
                    generate_basis(m,orbit,eps).size()));
                for (int layer=0;layer<=m/3;++layer)
                    maximum_layer=std::max(maximum_layer,static_cast<i64>(
                        generate_basis(m,orbit,eps,layer).size()));
            }
        } else if (curve.symmetry==CurveConfig::Symmetry::cyclic) {
            const auto orbits=curve.cyclic_involution?
                cyclic_orbits(curve.cyclic_order):
                cyclic_characters(curve.cyclic_order);
            const std::vector<int> epsilons=curve.cyclic_involution?
                std::vector<int>{-1,1}:std::vector<int>{0};
            blocks=static_cast<int>(orbits.size()*epsilons.size());
            for (const auto &orbit:orbits) for (int eps:epsilons) {
                const auto full_basis=curve.cyclic_involution?
                    generate_cyclic_basis(m,curve.cyclic_order,
                                          curve.total_degree(),orbit,eps):
                    generate_cyclic_character_basis(m,curve.cyclic_order,
                                                    curve.total_degree(),orbit,1);
                maximum=std::max(maximum,static_cast<i64>(full_basis.size()));
                for (int layer=0;layer<=m/3;++layer) {
                    const auto layer_basis=curve.cyclic_involution?
                        generate_cyclic_basis(m,curve.cyclic_order,
                                              curve.total_degree(),orbit,eps,layer):
                        generate_cyclic_character_basis(m,curve.cyclic_order,
                                                        curve.total_degree(),orbit,1,layer);
                    maximum_layer=std::max(maximum_layer,static_cast<i64>(
                        layer_basis.size()));
                }
            }
        } else maximum=maximum_layer=raw_count(m,curve.total_degree());
        std::cout << curve.d1 << '_' << curve.d2 << ',' << m << ',' << t << ','
                  << raw_count(m,curve.total_degree()) << ',' << blocks << ','
                  << maximum << ',' << maximum_layer << '\n';
    }
}

void print_shards(const Options &opt,const CurveConfig &curve,
                  const std::vector<std::pair<int,int>> &cases) {
    std::vector<Orbit> orbits;
    if (curve.symmetry==CurveConfig::Symmetry::product_mu3)
        orbits.assign(ORBITS.begin(),ORBITS.end());
    else if (curve.symmetry==CurveConfig::Symmetry::cyclic)
        orbits=curve.cyclic_involution?cyclic_orbits(curve.cyclic_order):
                                       cyclic_characters(curve.cyclic_order);
    for (const auto &[m,t]:cases) {
        if (curve.symmetry==CurveConfig::Symmetry::none) {
            std::cout << "two_components_finite_vanishing_O3 --degrees "
                      << curve.d1 << ' ' << curve.d2 << " --m " << m << " --t "
                      << t << " --prime " << opt.prime
                      << " --mode full --shard-prefix SHARD\n";
            continue;
        }
        const std::vector<int> epsilons=curve.cyclic_involution?
            std::vector<int>{-1,1}:std::vector<int>{0};
        for (const auto &orbit:orbits) for (int eps:epsilons) {
            std::cout << "two_components_finite_vanishing_O3 --degrees "
                      << curve.d1 << ' ' << curve.d2 << " --profile " << opt.profile
                      << " --m " << m << " --t " << t << " --prime " << opt.prime
                      << " --mode full --orbit " << orbit.name();
            if (curve.cyclic_involution) std::cout << " --epsilon " << eps;
            std::cout << " --shard-prefix SHARD\n";
        }
    }
}

} // namespace fv

int main(int argc, char **argv) {
    using namespace fv;
    try {
        Options opt=parse_options(argc,argv);
        const CurveConfig curve=curve_config(opt.d1,opt.d2);
        MODULUS=opt.prime;
        warn_legacy_profile(opt.profile);
        if (opt.self_test) {self_test();return 0;}
        if (!opt.all && (opt.m<1 || opt.t<1)) {
            usage(std::cerr);
            return 2;
        }
        if (curve.symmetry==CurveConfig::Symmetry::none && opt.mode!="full")
            throw std::runtime_error("unequal-degree cases require --mode full");
        if (cubic_only_profile(opt.profile) && !(curve.d1==3 && curve.d2==3))
            throw std::runtime_error("non-baseline profiles are defined only for (3,3)");

        if (!opt.shard_prefix.empty()) {
            if (opt.all)
                throw std::runtime_error("--shard-prefix is intended for one --m/--t case");
            std::ostringstream stem;
            stem << opt.shard_prefix << "_d" << curve.d1 << '_' << curve.d2
                 << "_m" << opt.m << "_t" << opt.t << "_p" << opt.prime;
            if (!opt.orbit.empty())
                stem << "_chi" << opt.orbit << "_eps" << (opt.epsilon>0?"plus":"minus");
            opt.certificate=stem.str()+".jsonl";
            opt.report=stem.str()+".txt";
        }

        const auto cases=selected_cases(opt,curve);
        if (opt.estimate_only || opt.list_shards) {
            if (opt.estimate_only) print_estimates(curve,cases);
            if (opt.list_shards) print_shards(opt,curve,cases);
            return 0;
        }

        std::ofstream cert(opt.certificate,std::ios::trunc);
        if (!cert) throw std::runtime_error("cannot open certificate file: "+opt.certificate);
        std::ofstream report(opt.report,std::ios::trunc);
        if (!report) throw std::runtime_error("cannot open report file: "+opt.report);
        write_human_header(report,opt.prime,opt.mode,curve,opt.profile);
        cert << "{\"kind\":\"finite-vanishing-run\",\"version\":\""
             << PROGRAM_VERSION << "\",\"d1\":" << curve.d1
             << ",\"d2\":" << curve.d2 << ",\"prime\":" << opt.prime
             << ",\"test_pair\":\"" << json_escape(curve.description()) << "\""
             << ",\"cyclic_denominator_shift\":"
             << (curve.linear_component?1:0)
             << ",\"divisibility\":\""
             << (curve.linear_component?"separate-z-a-b":"product-remainder-z")
             << "\""
             << ",\"mode\":\"" << json_escape(opt.mode)
             << "\",\"profile\":\"" << json_escape(opt.profile)
             << "\",\"range\":\"" << json_escape(finite_range_description(curve,opt.profile))
             << "\"}\n";
        bool all_proved=true;
        for (auto [m,t]:cases) {
            std::cerr << "=== finite vanishing m=" << m << " t=" << t
                      << " mod " << opt.prime << " ===\n";
            auto blocks=run_case(opt,m,t);
            bool proved=std::all_of(blocks.begin(),blocks.end(),
                                    [](const BlockResult &b){return b.proved;});
            all_proved &= proved;
            write_case_json(cert,m,t,opt.prime,curve,blocks,opt.full_certificate);
            cert.flush();
            write_human_case(report,m,t,blocks);
            report.flush();
            std::cout << "(m,t)=(" << m << ',' << t << "): "
                      << (proved?"VANISHING PROVED":"NOT PROVED") << "\n";
        }
        if (opt.all && curve.symmetry==CurveConfig::Symmetry::product_mu3 &&
            !opt.all_explicit && all_proved) {
            if (opt.profile=="smt38" || opt.profile=="smt57")
                std::cout << "All 14 SMT-38 minimal-twist cases vanished.\n";
            else if (opt.profile=="smt23")
                std::cout << "All 17 SMT-23 minimal-twist cases vanished.\n";
            else if (opt.profile=="smt27")
                std::cout << "All 20 legacy smt27 minimal-twist cases vanished.\n";
            else
                std::cout << "All 12 baseline minimal-twist cases vanished.\n";
        }
        return all_proved?0:1;
    } catch (const std::exception &e) {
        std::cerr << "ERROR: " << e.what() << "\n";
        return 2;
    }
}
