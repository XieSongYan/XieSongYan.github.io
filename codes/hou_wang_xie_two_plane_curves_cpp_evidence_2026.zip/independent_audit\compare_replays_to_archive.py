#!/usr/bin/env python3
"""Compare fresh proof-case replays with the archived block records."""

from __future__ import annotations

import json
from pathlib import Path


ROOT = Path(__file__).resolve().parents[1]
STAGE = ROOT / "evidence_release_stage_v3"
FRESH = Path(__file__).with_name("proof_case_replays")

SPECS = [
    ("p33_m3t1_p5.jsonl", STAGE / "certificates/proof/cubic_smt38_p5.jsonl", 3, 1),
    ("p33_m9t2_p5.jsonl", STAGE / "certificates/proof/cubic_smt38_p5.jsonl", 9, 2),
    ("p34_m3t3_p5.jsonl", STAGE / "certificates/proof/pair_34_p5.jsonl", 3, 3),
    ("p26_m3t3_p7.jsonl", STAGE / "certificates/proof/pair_26_p7.jsonl", 3, 3),
    ("p25_m3t2_p5.jsonl", STAGE / "certificates/proof/pair_25_p5.jsonl", 3, 2),
    ("p18_m3t2_p5.jsonl", STAGE / "certificates/proof/pair_18_p5.jsonl", 3, 2),
    ("p19_m3t3_p5.jsonl", STAGE / "certificates/proof/pair_19_p5.jsonl", 3, 3),
]


def case(path: Path, m: int, t: int):
    for line in path.read_text(encoding="utf-8").splitlines():
        record = json.loads(line)
        if record.get("kind") == "finite-vanishing-case" and record["m"] == m and record["t"] == t:
            return record
    raise KeyError((path, m, t))


def keyed(record):
    return {(block["character_orbit"], block["epsilon"]): block for block in record["blocks"]}


def main():
    summary = []
    for fresh_name, archived_path, m, t in SPECS:
        fresh = keyed(case(FRESH / fresh_name, m, t))
        archived = keyed(case(archived_path, m, t))
        mismatches = []
        for key in sorted(fresh):
            if key not in archived:
                mismatches.append(f"missing archived block {key}")
                continue
            fdata = fresh[key]["rank_data"]
            adata = archived[key]["rank_data"]
            fields = ["columns", "rows", "rank", "nullity", "det_mod_p", "pivot_hash"]
            # Modern records also bind the complete input matrix and echelon form.
            if "matrix_hash" in adata:
                fields += ["matrix_hash", "echelon_hash"]
            for field in fields:
                if fdata.get(field) != adata.get(field):
                    mismatches.append(f"{key} {field}: {fdata.get(field)} != {adata.get(field)}")
        if set(fresh) != set(archived):
            mismatches.append("block-key sets differ")
        item = {
            "fresh": fresh_name,
            "archived": str(archived_path.relative_to(ROOT)),
            "blocks": len(fresh),
            "passed": not mismatches,
            "mismatches": mismatches,
        }
        summary.append(item)
        print(json.dumps(item, sort_keys=True))
    output = Path(__file__).with_name("proof_case_replay_comparison.json")
    output.write_text(json.dumps(summary, indent=2) + "\n", encoding="utf-8")
    if not all(item["passed"] for item in summary):
        raise SystemExit(1)


if __name__ == "__main__":
    main()
