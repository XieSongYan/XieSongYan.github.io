# Legacy cubic records (historical only)

These files preserve the mixed-schema cubic proof collection distributed in
release 3 and its assembly reports.  They are retained to make the history of
the computation auditable, but they are **not** used by the release-4 proof or
by its final coverage check.

In the old JSONL file, 144 blocks carried only a legacy `pivot_hash`; the 24
blocks at weights 9 and 14 carried separate `matrix_hash` and
`echelon_hash` fields.  A later audit found that a fresh current-source
weight-3 run reproduced dimensions, ranks, nullities, and pivot-row hashes,
but not 11 of the 12 recorded pivot products.  The discrepancy is compatible
with harmless nonzero column scalings, yet the legacy schema cannot establish
that equivalence.

Release 4 therefore replaces the proof-effective cubic file with a complete
single-run regeneration from the frozen current source and executable.  All
168 proof blocks in that file use the modern schema.  Consult
`../../reports/CURRENT_SOURCE_CUBIC_RUN_PROVENANCE.md` and
`../../independent_audit/` for the source-bound run and independent audit.
