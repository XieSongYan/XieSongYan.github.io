#define main finite_generator_embedded_main
#include "../evidence_release_stage_v3/source/two_components_finite_vanishing_O3.cpp"
#undef main

// Audit-only extractor.  It includes the unmodified production source and
// serializes tiny matrices so that an independently derived symbolic oracle
// can compare individual entries rather than merely ranks.
int main(int argc, char **argv) {
    using namespace fv;
    if (argc != 2) return 2;
    MODULUS = 5;
    std::ofstream out(argv[1]);
    if (!out) return 3;

    auto dump = [&](const std::string &name, Context &ctx,
                    const std::vector<BasisVector> &basis) {
        ctx.precompute(true);
        out << "TEST " << name << ' ' << basis.size() << "\n";
        for (std::size_t column = 0; column < basis.size(); ++column) {
            const SparseVector values = build_column(ctx, basis[column], true);
            out << "COL " << column << ' ' << values.size() << "\n";
            for (const auto &[row, coefficient] : values)
                out << row << ' ' << coefficient << "\n";
        }
    };

    {
        auto cc = curve_config(3,4); Context ctx(1,1,cc);
        dump("p34_m1_all",ctx,generate_unsplit_basis(1,7));
    }
    {
        auto cc = curve_config(2,5); Context ctx(1,1,cc);
        dump("p25_m1_c0_plus",ctx,generate_cyclic_basis(1,5,7,{0,0,"c0"},1));
    }
    {
        auto cc = curve_config(1,8); Context ctx(1,1,cc);
        dump("p18_m1_c0",ctx,generate_cyclic_character_basis(1,8,9,{0,0,"c0"},1));
    }
    {
        auto cc = curve_config(3,3); Context ctx(3,1,cc);
        dump("p33_m3_00_plus",ctx,generate_basis(3,{0,0,"00"},1));
    }
    return 0;
}
