# Independent mathematics-to-C++ audit

This directory records an audit written independently of the production
generator's sparse-polynomial and elimination classes.

The principal report is `paper4_math_to_cpp_correctness_audit.md`.  It traces
the mathematical normal form, chart transition, divisibility conditions,
symmetry splitting, and modular-rank implication to the frozen C++ source.
The audit found no fatal implementation defect.

`independent_symbolic_oracle.py` reconstructs representative matrices with
SymPy directly from the displayed rational formulas.  The resulting matrices
cover the unsplit `(3,4)` path, the mixed-conic path including the
theorem-relevant `(2,5),(m,t)=(3,2),p=5` block, the line three-factor path,
and the full cubic Wronskian cross-layer path.  Small cases were also ranked
directly over `Q`.  The JSON result files record matching matrix fingerprints
and exact entrywise comparisons with an audit-only production extractor.

The original report identified one P1 release issue: 144 old cubic records
were legacy run logs rather than uniformly source-bound certificates.  That
issue is closed in release 4 by the complete source-bound regeneration in
`../certificates/proof/cubic_smt38_p5.jsonl`, produced by the exact
pre-nomenclature source and executable preserved under
`../provenance/producer_snapshot`.  The provenance and final output hashes are
recorded in `../reports/CURRENT_SOURCE_CUBIC_RUN_PROVENANCE.md`.

The fast program in `../bin/verify_finite_vanishing_certificates.exe` remains
a structural coverage checker.  It is not described here as an independent
rank verifier.
