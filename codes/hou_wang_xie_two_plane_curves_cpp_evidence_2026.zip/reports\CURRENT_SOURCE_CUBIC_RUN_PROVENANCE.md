# Complete cubic proof-run provenance

Date: 2026-08-23 (Asia/Shanghai)

## Mathematical scope

The files
`certificates/proof/cubic_smt38_p5.jsonl` and
`certificates/proof/cubic_smt38_p5.txt` record one complete full-profile run
for degrees `(3,3)` at prime 5.  The historical profile label `smt38` and the
theorem label `smt57` enumerate the same fourteen pairs
`t=ceil((m+1)/5)`, `1<=m<=14`.  The run contains all 168 required symmetry
blocks, 280,798 coefficient columns in total, and reports
`rank=columns` and `nullity=0` in every block.  The JSONL records use the
current certificate schema, including matrix hashes, echelon hashes, and
pivot rows.

## Producing executable

The complete run was produced before the theorem-profile nomenclature was
renamed.  Its producer had the following SHA-256 digests:

| object | SHA-256 |
|---|---|
| pre-nomenclature generator source | `F1E397FFA22FF4A6B4E86D729601AF4B9489B40839C4FA6258A46C840F9BAE9F` |
| pre-nomenclature generator executable | `8CE4AE756DAE16D5FAF3E47C54D43DC657B81B9F14B9AAC824EC661DCDFB688A` |

The exact producer source and executable are included as
`provenance/producer_snapshot/two_components_finite_vanishing_O3_pre_nomenclature.cpp`
and
`provenance/producer_snapshot/two_components_finite_vanishing_O3_pre_nomenclature.exe`.

The source changes between that producer and the archived generator are
profile-label and documentation changes; they do not alter the enumerated
matrices.  The archived source and executable have digests
`CC7A1825ADCC2226C882F78F3F239DD3C026EF25C9D32E0F1F8CC2BAF27766D0`
and
`23CD4C43235207E0733BDECDB3B1A48448D510AA08FAEF637333F9477859D03F`,
respectively.  Their generator self-tests pass at primes 5, 7, and 11.

## Output identity and timing record

| object | SHA-256 |
|---|---|
| `cubic_smt38_p5.jsonl` | `BC69BF57240A6E49C68DF8BDCB146CD25D2C4F9DFEFCF200FF6D9BC71C303085` |
| `cubic_smt38_p5.txt` | `5D407B869DDC56DEFD2EFA56FEBFAE1FBAC6E8DBD7CE3B1E6DF9B1F8D8B55546` |

The output file was created at 06:17:12 and last written at 10:03:14 on
2026-08-23.  The largest block has 8,830 columns; the largest recorded
single-block time is 2,919.931 seconds.  The exact historical launch command
and concurrency level were not retained, so no stronger wall-clock or
parallelism claim is made.

## Independent checking and canonical reproduction

The archived structural verifier accepts the complete JSONL file under
`--profile smt57`; it checks coverage, dimensions, ranks, nullities, and
deterministic fingerprints, but it does not reconstruct the matrices or
replay a maximal minor.  An independent audit recomputed the stored
pivot-row-label hashes for all 168 blocks without mismatch; this checks label
integrity, not nonsingularity of the selected minor.  Independent rank
verification therefore requires rebuilding and rerunning the exact generator.
A canonical new run is obtained with the archived generator by selecting
degrees `(3,3)`, prime 5, and profile `smt57`; `smt38` is retained only as a
backward-compatible historical label.  The final `SHA256SUMS.txt` binds the
sources, executables, certificates, reports, and guide included in this
release.
