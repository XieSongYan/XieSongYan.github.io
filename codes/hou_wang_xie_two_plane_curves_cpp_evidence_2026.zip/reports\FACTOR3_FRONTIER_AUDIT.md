# Factor-three profile and frontier audit

Date: 2026-08-23 (Asia/Shanghai)

## Certified profile

The theorem profile is `smt57`, namely
`t=ceil((m+1)/5)` for `1<=m<=14`.  The archived cubic certificate was
created under the historical name `smt38`; the two profile names enumerate
exactly the same 14 cases and 168 symmetry blocks.  The rebuilt structural
checker accepted the archived certificate under `--profile smt57`.

All six proof sets were accepted:

| degrees | required full-rank blocks |
|---|---:|
| `(3,3)` | 168 |
| `(3,4)` | 1 |
| `(2,6)` | 8 |
| `(2,5)` | 36 |
| `(1,8)` | 48 |
| `(1,9)` | 18 |

The `(2,5)` count includes the separately archived `(m,t)=(8,3)` proof and
prime-7 replay.  Generator self-tests passed at primes 5, 7, and 11, and the
separate O(3) identity checker passed.

## Uncomputed fixed-method frontier

The generator's matrix-free `--estimate-only` path was run on every new
minimal target required for the conditional constants 27, 17, and 18.

| degrees | new targets | raw coefficient variables | exact shards | endpoint raw variables | largest shard | largest W-layer |
|---|---:|---:|---:|---:|---:|---:|
| `(3,3)` | 12 | 1,248,727 | 144 | 280,686 | 31,931 | 12,257 |
| `(2,5)` | 10 | 288,129 | 60 | 84,865 | 16,973 | 8,848 |
| `(1,8)` | 11 | 704,491 | 88 | 195,750 | 24,725 | 12,184 |
| total | 33 | 2,241,347 | 292 | - | - | - |

These numbers are exact combinatorial counts, not extrapolations.  The
running-time figures in the manuscript and guide are engineering estimates
calibrated from completed proof runs.  The matrix-free estimator does not
construct the target matrices, so it does not determine their row counts,
numbers of nonzero entries, elimination fill-in, or peak memory.  Accordingly,
we make no minimum-hardware claim for the uncomputed frontier.  No frontier
rank is claimed until its full-column-rank certificate has actually been
produced.

## Parallel feasibility

Each shard fixes the degree pair, `(m,t)`, prime, character orbit, and, where
present, involution sign.  It generates and eliminates its own exact modular
matrix and writes its own certificate.  There is no cross-shard state or
communication, so all 292 primary-prime jobs can be scheduled independently.  The
generator exposes them through `--list-shards` and accepts `--orbit`,
`--epsilon`, and `--shard-prefix` for one-job execution.

The 33 exact estimate rows are frozen in `FRONTIER_ESTIMATES.csv`, and the
292 primary-prime commands emitted by the executable are frozen in
`FRONTIER_PRIMARY_PRIME_SHARDS.txt`.

For scale only, a dense square array whose side is the largest recorded shard
width would occupy approximately 3.80 GiB, 1.07 GiB, and 2.28 GiB for the
three families at 32 bits per entry.  These are baselines, not allocation
predictions: an actual rank computation also depends on the unknown row count,
sparsity pattern, representation, and elimination fill-in.  Selected large
certificates should be replayed at a second prime as an implementation audit.
