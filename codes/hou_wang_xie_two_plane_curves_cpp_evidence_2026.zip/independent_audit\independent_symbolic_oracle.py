#!/usr/bin/env python3
"""Independent small-case oracle for the Paper 4 finite matrices.

This script deliberately reconstructs the mixed-chart map from the displayed
symbolic formula, using SymPy rational functions over Q.  It does not import
or call the C++ implementation.  It then imposes the stated divisibility
conditions over Z, computes exact Q-ranks, reduces the same matrices modulo p,
and reproduces the documented canonical matrix fingerprint.
"""

from __future__ import annotations

from dataclasses import dataclass
import json
from pathlib import Path

import sympy as sp


u, z, zp, q, wx = sp.symbols("u z zp q wx")
MASK64 = (1 << 64) - 1
FNV_OFFSET = 1469598103934665603
FNV_PRIME = 1099511628211


@dataclass(frozen=True)
class Curve:
    d1: int
    d2: int
    a: sp.Expr
    b: sp.Expr
    delta: sp.Expr
    eform: sp.Expr
    symmetry: str
    order: int = 0

    @property
    def total_degree(self) -> int:
        return self.d1 + self.d2

    @property
    def line(self) -> bool:
        return self.symmetry == "line"


def curve(d1: int, d2: int) -> Curve:
    d1, d2 = sorted((d1, d2))
    if (d1, d2) == (3, 3):
        a = 1 + 2 * u**3 + z**3
        b = 2 + u**3 + z**3
        return Curve(3, 3, a, b, 2 * u**2 * b - a * u**2,
                     z**2 * b - a * z**2, "mu3xmu3", 3)
    if (d1, d2) == (3, 4):
        a = 1 + u**3 + z**3
        b = 1 + u**4 + z**4
        return Curve(3, 4, a, b, u**2 * b - a * u**3,
                     z**2 * b - a * z**3, "none")
    if d1 == 2 and d2 in (5, 6):
        a = u + z**2
        b = 1 + u**d2 + z**d2
        return Curve(2, d2, a, b, b - 2 * a * u ** (d2 - 1),
                     2 * z * b - 2 * a * z ** (d2 - 1), "cyclic", d2)
    if d1 == 1 and d2 == 8:
        a = u
        b = 1 + u**8 + z**8 + u**4
        return Curve(1, 8, a, b, 8 + 8 * z**8 + 4 * u**4,
                     -8 * u * z**7, "line", 8)
    if d1 == 1 and d2 == 9:
        a = u
        b = 1 + u**9 + z**9 + u**3 * z**3
        return Curve(1, 9, a, b, 9 + 9 * z**9 + 6 * u**3 * z**3,
                     -9 * u * z**8 - 3 * u**4 * z**2, "line", 9)
    raise ValueError((d1, d2))


@dataclass(frozen=True)
class Atom:
    k: int
    i: int
    j: int
    xr: int
    ys: int
    scalar: int = 1

    def sigma(self, scalar: int) -> "Atom":
        return Atom(self.k, self.j, self.i, self.ys, self.xr, scalar)

    def order_key(self):
        return self.k, self.i, self.j, self.xr, self.ys


def raw_atoms(m: int, total_degree: int):
    for k in range(m // 3, -1, -1):
        jet_degree = m - 3 * k
        polynomial_degree = (total_degree - 1) * m - (2 * total_degree - 1) * k
        for i in range(jet_degree + 1):
            j = jet_degree - i
            for xr in range(polynomial_degree + 1):
                for ys in range(polynomial_degree - xr + 1):
                    yield Atom(k, i, j, xr, ys)


def basis(cur: Curve, m: int, orbit: str, epsilon: int):
    if cur.symmetry == "none":
        return [[a] for a in raw_atoms(m, cur.total_degree)]

    if cur.symmetry == "line":
        character = int(orbit[1:])
        ans = []
        for a in raw_atoms(m, cur.total_degree):
            n = m - 2 * a.k
            if (a.xr - a.ys + a.i - a.j + n) % cur.order == character:
                ans.append([a])
        return ans

    if cur.symmetry == "mu3xmu3":
        ca, cb = map(int, orbit)
        diagonal = ca == cb

        def accepts(a: Atom):
            return ((a.xr + a.i + a.k) % 3 == ca and
                    (a.ys + a.j + a.k) % 3 == cb)
    else:
        ca = int(orbit[1:])
        cb = (-ca) % cur.order
        diagonal = ca == cb

        def accepts(a: Atom):
            return (a.xr - a.ys + a.i - a.j) % cur.order == ca

    ans = []
    for a in raw_atoms(m, cur.total_degree):
        if not accepts(a):
            continue
        sign = epsilon * (-1 if a.k % 2 else 1)
        b = a.sigma(sign)
        if not diagonal:
            ans.append([a, b])
        elif b.order_key() < a.order_key():
            continue
        elif b.order_key() == a.order_key():
            if sign == 1:
                ans.append([a])
        else:
            ans.append([a, b])
    return ans


def template(cur: Curve, m: int, k: int, i: int) -> sp.Expr:
    j = m - 3 * k - i
    A = cur.a * cur.b / cur.delta
    B = -cur.eform / cur.delta
    first = z * A * q + (z * B - u) * zp
    wfull = (-A * wx + A * sp.diff(A, u) * q**2 * zp
             + (sp.diff(A, u) * B + sp.diff(A, z) + A * sp.diff(B, u))
             * q * zp**2
             + (B * sp.diff(B, u) + sp.diff(B, z)) * zp**3)
    return sp.expand(zp**i * first**j * wfull**k)


def integral_poly(expr: sp.Expr) -> dict[tuple[int, int], int]:
    expr = sp.cancel(expr)
    numerator, denominator = sp.fraction(expr)
    if denominator != 1:
        raise AssertionError(f"denominator survived clearing: {denominator}")
    pol = sp.Poly(sp.expand(numerator), u, z, domain=sp.ZZ)
    out = {}
    for (du, dz), coeff in pol.terms():
        out[(du, dz)] = int(coeff)
    return out


def add_scaled(dst, src, factor=1):
    for key, coefficient in src.items():
        new = dst.get(key, 0) + factor * coefficient
        if new:
            dst[key] = new
        elif key in dst:
            del dst[key]


def multiply_poly(a, b):
    ans = {}
    for (ua, za), ca in a.items():
        for (ub, zb), cb in b.items():
            key = (ua + ub, za + zb)
            ans[key] = ans.get(key, 0) + ca * cb
    return {key: value for key, value in ans.items() if value}


def poly_power(expr: sp.Expr, exponent: int):
    return integral_poly(sp.expand(expr**exponent))


def remainder_z(dividend, divisor):
    """Exact long division in Z[u][z]; all test divisors are z-monic."""
    result = dict(dividend)
    dd = max(dz for _, dz in divisor)
    leading = {(du, dz): c for (du, dz), c in divisor.items() if dz == dd}
    if leading != {(0, dd): 1}:
        raise AssertionError(f"nonmonic divisor: {leading}")
    while result and max(dz for _, dz in result) >= dd:
        top = max(dz for _, dz in result)
        leading_terms = [(du, c) for (du, dz), c in result.items() if dz == top]
        for du, coeff in leading_terms:
            for (dv, dz), dc in divisor.items():
                key = (du + dv, top - dd + dz)
                new = result.get(key, 0) - coeff * dc
                if new:
                    result[key] = new
                elif key in result:
                    del result[key]
    return result


def row_key(K, target_k, qdegree, udegree, zdegree, condition=0):
    qslot = 32 * condition + qdegree
    return ((K - target_k) << 56) | (qslot << 48) | (zdegree << 24) | udegree


def atom_rows(cur: Curve, m: int, t: int, atom: Atom):
    K = m // 3
    nr = m - 2 * atom.k
    degree = atom.xr + atom.ys
    sign = atom.scalar * (-1 if (atom.i + atom.k) % 2 else 1)
    expanded = sp.Poly(template(cur, m, atom.k, atom.i), wx, q, zp)
    rows = {}
    for (target_k, qdegree, _zpdegree), coefficient in expanded.terms():
        nt = m - 2 * target_k
        base = ((cur.total_degree - 2) * m
                + (-2 * cur.total_degree + 3) * atom.k - degree)
        source = (sign * u**atom.ys * z**base * coefficient
                  / (cur.a * cur.b) ** nr)
        cleared = (source * z**nt * cur.a**nt * cur.b**nt * cur.delta**nt)
        N = integral_poly(cleared)
        if cur.line:
            for (du, dz), c in N.items():
                if dz < nt + t:
                    rows[row_key(K, target_k, qdegree, du, dz, 1)] = c
                if du < nt:
                    rows[row_key(K, target_k, qdegree, du, dz, 2)] = c
            rem = remainder_z(N, poly_power(cur.b, nt))
            for (du, dz), c in rem.items():
                rows[row_key(K, target_k, qdegree, du, dz, 3)] = c
        else:
            divisor_expr = z ** (nt + t) * cur.a**nt * cur.b**nt
            rem = remainder_z(N, integral_poly(divisor_expr))
            for (du, dz), c in rem.items():
                rows[row_key(K, target_k, qdegree, du, dz, 0)] = c
    return rows


def vector_rows(cur: Curve, m: int, t: int, atoms):
    ans = {}
    for atom in atoms:
        add_scaled(ans, atom_rows(cur, m, t, atom))
    return ans


def hash_u64(state: int, value: int):
    value &= MASK64
    for byte in range(8):
        state ^= (value >> (8 * byte)) & 0xFF
        state = (state * FNV_PRIME) & MASK64
    return state


def reduce_column(column, prime):
    return {row: coefficient % prime for row, coefficient in column.items()
            if coefficient % prime}


def matrix_fingerprint(columns, prime):
    state = FNV_OFFSET
    rows = set()
    reduced = []
    for col_number, column in enumerate(columns):
        col = reduce_column(column, prime)
        reduced.append(col)
        state = hash_u64(state, col_number)
        state = hash_u64(state, len(col))
        for row, coefficient in sorted(col.items()):
            state = hash_u64(state, row)
            state = hash_u64(state, coefficient)
            rows.add(row)
    return state, rows, reduced


def modular_rank(columns, prime):
    pivots = {}
    rank = 0
    for input_column in columns:
        col = reduce_column(input_column, prime)
        while col:
            row = min(col)
            coeff = col[row]
            if row not in pivots:
                inv = pow(coeff, -1, prime)
                pivots[row] = {r: c * inv % prime for r, c in col.items()}
                rank += 1
                break
            factor = coeff
            for r, c in pivots[row].items():
                new = (col.get(r, 0) - factor * c) % prime
                if new:
                    col[r] = new
                elif r in col:
                    del col[r]
    return rank


def rational_rank(columns):
    row_labels = sorted({row for column in columns for row in column})
    row_number = {row: i for i, row in enumerate(row_labels)}
    matrix = sp.MutableSparseMatrix(len(row_labels), len(columns), {})
    for j, column in enumerate(columns):
        for row, coefficient in column.items():
            matrix[row_number[row], j] = coefficient
    return int(matrix.rank()), len(row_labels)


TESTS = [
    # no symmetry: checks the complete ordinary two-component frame
    {"name": "p34_m1_all", "degrees": (3, 4), "m": 1, "t": 1,
     "orbit": "all", "epsilon": 0, "prime": 5,
     "expected": (56, 115, "89769bc49dcd8c97")},
    # involutive cyclic symmetry and the mixed conic frame
    {"name": "p25_m1_c0_plus", "degrees": (2, 5), "m": 1, "t": 1,
     "orbit": "c0", "epsilon": 1, "prime": 5,
     "expected": (6, 22, "7ca17d90d533ed90")},
    # theorem-relevant conic--quintic case at p=5 (which divides the
    # unnormalized q-scaling and the cyclic-group order)
    {"name": "p25_m3_t2_c0_plus", "degrees": (2, 5), "m": 3, "t": 2,
     "orbit": "c0", "epsilon": 1, "prime": 5,
     "expected": (77, 512, "d6928cfdb4d1eb53")},
    # degree-one denominator character shift and three coprime conditions
    {"name": "p18_m1_c0", "degrees": (1, 8), "m": 1, "t": 1,
     "orbit": "c0", "epsilon": 0, "prime": 5,
     "expected": (13, 24, "711295a4c77f900e")},
    # W layer and the complete triangular cross-layer O(3) transformation
    {"name": "p33_m3_00_plus", "degrees": (3, 3), "m": 3, "t": 1,
     "orbit": "00", "epsilon": 1, "prime": 5,
     "expected": (36, 223, "0578690cbbe1c476")},
]


def run_one(test):
    cur = curve(*test["degrees"])
    vectors = basis(cur, test["m"], test["orbit"], test["epsilon"])
    columns = [vector_rows(cur, test["m"], test["t"], atoms) for atoms in vectors]
    fingerprint, rows, _ = matrix_fingerprint(columns, test["prime"])
    rank_mod = modular_rank(columns, test["prime"])
    # Direct fraction-free Q elimination is useful for the genuinely tiny
    # matrices.  For the 77-column theorem block, the independently built
    # matrix is still over Z and its exact F_p full rank already certifies the
    # same lower bound over Q; avoiding a slow generic CAS elimination keeps
    # this audit script lightweight.
    if len(columns) <= 60:
        rank_q_direct, exact_rows = rational_rank(columns)
    else:
        rank_q_direct = None
        exact_rows = len({row for column in columns for row in column})
    expected_columns, expected_rows, expected_hash = test["expected"]
    result = {
        "name": test["name"],
        "columns": len(columns),
        "rows_mod_p": len(rows),
        "rows_exact": exact_rows,
        "rank_mod_p": rank_mod,
        "rank_Q_direct": rank_q_direct,
        "rank_Q_certified_from_integral_mod_p_matrix": rank_mod,
        "matrix_hash": f"{fingerprint:016x}",
        "expected_hash": expected_hash,
    }
    result["passed"] = (
        len(columns) == expected_columns
        and len(rows) == expected_rows
        and rank_mod == expected_columns
        and (rank_q_direct is None or rank_q_direct == expected_columns)
        and result["matrix_hash"] == expected_hash
    )
    return result


def main():
    results = []
    for test in TESTS:
        print(f"building {test['name']} ...", flush=True)
        result = run_one(test)
        results.append(result)
        print(json.dumps(result, sort_keys=True), flush=True)
    output = Path(__file__).with_name("independent_symbolic_oracle_results.json")
    output.write_text(json.dumps(results, indent=2) + "\n", encoding="utf-8")
    if not all(item["passed"] for item in results):
        raise SystemExit(1)


if __name__ == "__main__":
    main()
