# Run provenance for the largest cubic case

## Certified case

- degrees: `(3,3)`;
- jet weight and twist: `(m,t)=(14,3)`;
- field: `F_5`;
- mode: `full`;
- symmetry blocks: 12;
- columns: 76,905;
- summed nonzero rows: 571,741;
- result: every block has `rank=columns` and `nullity=0`;
- largest block: 8,830 columns;
- maximum recorded block time: 2,423.014278 seconds;
- process exit code: 0.

The raw JSONL and text files were created at `2026-08-23 00:02:19` and last
written at `2026-08-23 01:46:23` (Asia/Shanghai), an observed filesystem
interval of `01:44:04`.

## Historical producer

The case was produced by the following preserved binary:

```text
provenance/two_components_finite_vanishing_O3_m14_actual_producer.exe
SHA-256 21A25093DE0A55727FCDB565CC9FD288DC4ED30B1615606BC9595F0DCE9D1252
size    1,614,336 bytes
```

The raw outputs had these hashes before their exact case record was inserted
into the canonical combined cubic file:

```text
finite_vanishing_33_m14t3_p5_full_v2.jsonl
SHA-256 81408C73F83CFE55867B3FD83F6C5FDADB8F3CC3CF9835954BB2A508C6D6B4A0
size    1,058,812 bytes

finite_vanishing_33_m14t3_p5_full_v2.txt
SHA-256 C96326F65F4490766E1F3492C7E12B8C20F5CADDEFF14954E6FCB0924D4F569D
size    1,753 bytes
```

The raw JSONL header retained the program's default `baseline` profile name
because the case was launched explicitly rather than through a profile-wide
run. The case record itself fixes `(3,3),(14,3),p=5`, full mode, all twelve
block keys, ranks, nullities, fingerprints, timings, and pivot rows. During
release assembly, only that exact case line was copied under a new truthful
SMT-38 run header.

The original shell command was not retained after the process exited. It
would therefore be misleading to print a reconstructed command as the exact
historical invocation. The preceding parameters are recoverable directly
from the output record; the degree of concurrency is not.

## Resource observations

Monitoring recorded the following maximum observed process counters:

- `PeakWorkingSet64 = 20,753,010,688` bytes (about 19.33 GiB);
- `PeakPagedMemorySize64 = 22,957,387,776` bytes (about 21.38 GiB).

These are the largest values sampled during monitoring. They are not asserted
to be the exact final operating-system peaks after process exit, and they are
not part of the mathematical proof.

## Canonical reproducer

The later frozen release executable is:

```text
bin/two_components_finite_vanishing_O3.exe
SHA-256 8CE4AE756DAE16D5FAF3E47C54D43DC657B81B9F14B9AAC824EC661DCDFB688A
size    1,635,840 bytes
```

It is the maintained reproducer, not the byte-identical historical producer.
Its source is archived under `source/`, warning-clean rebuilding is recorded
in `BUILD_AND_TOOLCHAIN.txt`, and its self-tests pass at primes 5, 7, and 11.
This maintained reproducer also contains the audited degree-one `A=Y`
implementations; that later addition does not alter the preserved historical
producer or the recorded `(14,3)` certificate.
A canonical single-case reproduction command, clearly not claimed as the
historical command, is:

```powershell
.\bin\two_components_finite_vanishing_O3.exe --degrees 3 3 --profile smt38 --m 14 --t 3 --prime 5 --jobs 4 --mode full --full-certificate --certificate reproduction\m14_t3_p5.jsonl --report reproduction\m14_t3_p5.txt
```

The full released cubic set is independently accepted by the structural
checker with 168 required full-rank blocks.
