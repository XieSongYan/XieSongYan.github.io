# Exact finite-vanishing computation

## Scope

The engine tests

`H^0(P^2,E_{2,m}T^*_{P^2}(log(C1+C2)) tensor O(-t))=0`

at one explicit simple-normal-crossing pair. Full column rank modulo one prime exhibits an integer maximal minor that is nonzero over `Q`. Upper semicontinuity then gives vanishing on a nonempty parameter open.

The six certified models are:

- `(3,3)`: `A=X^3+2Y^3+Z^3`, `B=2X^3+Y^3+Z^3`;
- `(3,4)`: `A=X^3+Y^3+Z^3`, `B=X^4+Y^4+Z^4`;
- `(2,e)`, `e=5,6`: `A=XY+Z^2`, `B=X^e+Y^e+Z^e`;
- `(1,8)`: `A=Y`, `B=X^8+Y^8+Z^8+X^4Y^4`;
- `(1,9)`: `A=Y`, `B=X^9+Y^9+Z^9+X^3Y^3Z^3`.

The line `L={Z=0}` is auxiliary. It is distinct from every component in the six models. In particular, no experimental `A=Z` calculation is valid evidence or included in this release.

## Normal form and mixed frame

Put `S=d1+d2`, `n_k=m-2k`, and `s_k=m-3k`. On `ZAB != 0`, a candidate has the finite ambient form

`sum P_{i,j,k}(x,y) (x')^i (y')^j W_xy^k / (a^{n_k} b^{n_k})`,

where `i+j=s_k` and

`deg P_{i,j,k} <= (S-1)m-(2S-1)k`.

On the `X`-chart set `u=Y/X`, `z=Z/X`. For the line cases,

`a_X=u`.

The program uses the integral projectively invariant form

`q=e dlog(a_X)-dlog(b_X)`.

For `e=8`:

`b_X=1+u^8+z^8+u^4`,

`Delta=8+8z^8+4u^4`,

`E=-8uz^7`.

For `e=9`:

`b_X=1+u^9+z^9+u^3z^3`,

`Delta=9+9z^9+6u^3z^3`,

`E=-9uz^8-3u^4z^2`.

In both cases

`q=(Delta u'+E z')/(a_X b_X)`.

The exact triangular Wronskian substitution is expanded in the frame `(z',q,W_X)` with `W_X=qz''-q'z'`.

## Degree-one divisibility

For a target Wronskian layer `k`, let

`N=z^{n_k}a_X^{n_k}b_X^{n_k}Delta^{n_k}R`.

The required divisibility is

`z^{n_k+t}u^{n_k}b_X^{n_k} | N`.

Because the product is not monic in `z`, it is not passed to the old one-variable remainder routine. The factors are pairwise coprime, so the code imposes three equivalent linear systems:

1. all terms of `N` have `z`-degree at least `n_k+t`;
2. all terms have `u`-degree at least `n_k`;
3. the remainder modulo the monic polynomial `b_X^{n_k}` in `F_p[u][z]` is zero.

The three row families receive disjoint row labels.

## Degree-one symmetry

The action

`[X:Y:Z] -> [zeta X:zeta^{-1}Y:Z]`, `zeta^e=1`,

preserves each degree-one pair. Coordinate exchange is not a symmetry because the distinguished line is `Y=0`; no involution eigenspaces are used.

Since `a=y` has character `-1`, its denominator contributes a layer-dependent shift. The character of a source monomial is

`r-s+i-j+n_k (mod e)`.

Consequently `(1,8)` splits into eight character blocks and `(1,9)` into nine. The self-test verifies exhaustion and checks the character of every transformed row for `m=3`.

## Exact completed ranges

| pair | cases | blocks | columns | proof/replay primes |
|---|---|---:|---:|---|
| `(3,3)` | SMT-57, `1<=m<=14` | 168 | 280,798 | 5; case `(9,2)` at 7 |
| `(3,4)` | `(3,3)` | 1 | 781 | 5, 7 |
| `(2,6)` | `(3,3)` | 8 | 1,040 | 7, 11 |
| `(2,5)` | `(3,2),(4,2),(5,2),(6,3),(7,3),(8,3)` | 36 | 38,286 | 5, 7 |
| `(1,8)` | `(3,2),(4,2),(5,2),(6,3),(7,3),(8,3)` | 48 | 67,011 | 5, 11 |
| `(1,9)` | `(3,3),(4,3)` | 18 | 5,526 | 5, 11 |

## Build

The release binaries are built warning-clean with LLVM-MinGW Clang 22.1.8:

```powershell
clang++.exe -std=c++17 -O3 -DNDEBUG -pthread -static `
  -Wall -Wextra -Wpedantic -Wconversion -Wshadow -Wsign-conversion `
  source/two_components_finite_vanishing_O3.cpp `
  -o bin/two_components_finite_vanishing_O3.exe

clang++.exe -std=c++17 -O2 -DNDEBUG -static `
  -Wall -Wextra -Wpedantic -Wconversion -Wshadow -Wsign-conversion `
  source/verify_finite_vanishing_certificates.cpp `
  -o bin/verify_finite_vanishing_certificates.exe
```

`-static` links the C++ support libraries into the executable; ordinary Windows UCRT/KERNEL32 system imports remain.

## Degree-one reproduction

```powershell
./bin/two_components_finite_vanishing_O3.exe --degrees 1 8 --all `
  --prime 5 --jobs 6 --mode full --full-certificate `
  --certificate certificates/proof/pair_18_p5.jsonl `
  --report certificates/proof/pair_18_p5.txt

./bin/two_components_finite_vanishing_O3.exe --degrees 1 9 --all `
  --prime 5 --jobs 6 --mode full --full-certificate `
  --certificate certificates/proof/pair_19_p5.jsonl `
  --report certificates/proof/pair_19_p5.txt
```

Structural aggregation:

```powershell
./bin/verify_finite_vanishing_certificates.exe --degrees 1 8 `
  certificates/proof/pair_18_p5.jsonl certificates/replays/pair_18_p11.jsonl

./bin/verify_finite_vanishing_certificates.exe --degrees 1 9 `
  certificates/proof/pair_19_p5.jsonl certificates/replays/pair_19_p11.jsonl
```

Expected counts are 48 and 18 complete full-rank blocks.

## Boundaries not certified

The current cubic theorem uses SMT-57.  Its certificate filenames retain the
historical string `smt38`, but the fourteen-case range is identical.  The
stronger fixed-method frontier is the SMT-27 profile; it is enumerated but
unrun and is not part of the evidence in this release.

For `(1,7)`, the formal Riemann--Roch window contains 178 cases: `3<=m<=60` at twist 1, `61<=m<=120` at twist 2, and `121<=m<=180` at twist 3. The calculation is deferred to a large cluster, and genuine nonvanishing may occur. No `(1,7)` file or theorem claim is present here.

The finite degree-one matrices also do not by themselves establish the separate global `O(3)` differentiation package.
