# Evidence release v3: staged audit

Date: 2026-08-23 (Asia/Shanghai)

## Result

**PASS.** The staged tree contains six proof-effective certificate sets and
their available independent-prime replays. Every proof block has full column
rank and nullity zero. The conic--quintic set now includes the additional
case `(m,t)=(8,3)` required for the coefficient `A_{2,5}=30`.

| pair | proof prime | replay prime | required blocks | certified columns |
|---|---:|---:|---:|---:|
| `(3,3)` | 5 | 7 for `(9,2)` | 168 | 280,798 |
| `(3,4)` | 5 | 7 | 1 | 781 |
| `(2,6)` | 7 | 11 | 8 | 1,040 |
| `(2,5)` | 5 | 7 | 36 | 38,286 |
| `(1,8)` | 5 | 11 | 48 | 67,011 |
| `(1,9)` | 5 | 11 | 18 | 5,526 |

For `(2,5),(m,t)=(8,3)`, both primes give full rank in all six
character--eigenvalue blocks. The case has 15,849 columns. The prime-5 files
are proof-effective; the prime-7 files are an independent implementation
replay, not an additional hypothesis.

## Checks performed

- Rebuilt the generator and independent structural checker warning-clean
  from the staged C++17 sources with LLVM-MinGW Clang 22.1.8.
- Ran the generator self-test at primes 5, 7, and 11; all passed.
- Ran the independent structural checker on all six degree pairs; it reported
  the exact required block counts `168, 1, 8, 36, 48, 18`.
- Verified the additional `(8,3)` proof and replay separately.
- Confirmed that the deficient `(2,6),p=5` record remains isolated as a
  diagnostic and is not used in the proof.
- Recompiled the standalone TeX guide without errors, undefined references,
  or layout warnings.
- Regenerated `SHA256SUMS.txt` from the final release-relative payload tree;
  the manifest deliberately excludes itself.

## Frozen executable hashes

```text
8CE4AE756DAE16D5FAF3E47C54D43DC657B81B9F14B9AAC824EC661DCDFB688A  bin/two_components_finite_vanishing_O3.exe
1BE2BAE10E86C5E1DB6B2D84CADB9A4E70E77089D6E76451CE481705DDE9AC84  bin/verify_finite_vanishing_certificates.exe
F2A95CB0F2E12BB1C2352BAC6BABA3A4C7EB95ACC841BEBC86B750C23C8262F2  bin/O3_identity_checker.exe
```

The archive is a reproducibility package for exact finite-rank certificates;
timings and resource observations are not mathematical proof inputs.
