/*
  Independent structural verifier for finite-vanishing JSONL certificates.

  This program deliberately does not share algebraic code with the matrix
  generator.  It checks that a collection of full-mode certificates covers
  every required case/block, that every reported block has full column rank,
  and that deterministic matrix/echelon fingerprints are present and
  consistent across duplicate shards.  It is an audit/aggregation layer; the
  mathematical proof still rests on the separately audited matrix generator.

  Build:
    clang++ -std=c++17 -O2 -static -Wall -Wextra -Wpedantic -Wconversion \
      -Wshadow -Wsign-conversion verify_finite_vanishing_certificates.cpp \
      -o verify_finite_vanishing_certificates.exe

  Run:
    verify_finite_vanishing_certificates.exe --degrees 3 3 cert1.jsonl ...

  Cubic profiles:
    smt57: t=ceil((m+1)/5), 1<=m<=14 (168 required shards)
    smt27: limiting t=ceil((m+1)/7), 1<=m<=20 profile
    smt38: historical exact alias of smt57
    smt23: historical intermediate profile
*/

#include <cstdint>
#include <fstream>
#include <iostream>
#include <map>
#include <set>
#include <sstream>
#include <stdexcept>
#include <string>
#include <tuple>
#include <utility>
#include <vector>

namespace {

struct Key {
    int m=0,t=0;
    std::string orbit;
    int epsilon=0;
    bool operator<(const Key &other) const {
        return std::tie(m,t,orbit,epsilon)<
               std::tie(other.m,other.t,other.orbit,other.epsilon);
    }
};

struct Fingerprint {
    std::int64_t columns=0,rank=0,nullity=0;
    std::string matrix_hash,echelon_hash;
};

bool known_profile(const std::string &profile) {
    return profile=="baseline" || profile=="smt38" || profile=="smt23" ||
           profile=="smt57" || profile=="smt27";
}

bool cubic_only_profile(const std::string &profile) {
    return profile!="baseline";
}

int cubic_profile_maximum(const std::string &profile) {
    if (profile=="baseline") return 12;
    if (profile=="smt38" || profile=="smt57") return 14;
    if (profile=="smt23") return 17;
    if (profile=="smt27") return 20;
    throw std::runtime_error("unknown finite-range profile: "+profile);
}

int cubic_profile_twist(const std::string &profile,int m) {
    if (profile=="baseline") return (m+3)/4;
    if (profile=="smt38" || profile=="smt57") return (m+5)/5;
    if (profile=="smt23") return (m+6)/6;
    if (profile=="smt27") return (m+7)/7;
    throw std::runtime_error("unknown finite-range profile: "+profile);
}

void warn_legacy_profile(const std::string &profile) {
    if (profile=="smt38")
        std::cerr << "WARNING: smt38 is a historical exact alias of smt57 "
                     "(168 required shards).\n";
    else if (profile=="smt23")
        std::cerr << "WARNING: smt23 is a historical intermediate profile "
                     "retained for reproducibility.\n";
}

std::size_t value_start(const std::string &line,const std::string &field,
                        std::size_t from=0) {
    const std::string needle="\""+field+"\":";
    const auto pos=line.find(needle,from);
    if (pos==std::string::npos)
        throw std::runtime_error("missing JSON field: "+field);
    return pos+needle.size();
}

std::int64_t integer_field(const std::string &line,const std::string &field,
                           std::size_t from=0) {
    auto pos=value_start(line,field,from);
    bool negative=false;
    if (line.at(pos)=='-') {negative=true;++pos;}
    if (pos>=line.size() || line.at(pos)<'0' || line.at(pos)>'9')
        throw std::runtime_error("invalid integer field: "+field);
    std::int64_t value=0;
    while (pos<line.size() && line.at(pos)>='0' && line.at(pos)<='9') {
        const int digit=line.at(pos)-'0';
        if (value>900000000000000000LL)
            throw std::runtime_error("integer overflow while parsing: "+field);
        value=value*10+digit;
        ++pos;
    }
    return negative?-value:value;
}

std::string string_field(const std::string &line,const std::string &field,
                         std::size_t from=0) {
    auto pos=value_start(line,field,from);
    if (line.at(pos)!='\"') throw std::runtime_error("invalid string field: "+field);
    const auto end=line.find('\"',pos+1);
    if (end==std::string::npos) throw std::runtime_error("unterminated JSON string");
    return line.substr(pos+1,end-pos-1);
}

bool true_field(const std::string &line,const std::string &field,
                std::size_t from=0) {
    const auto pos=value_start(line,field,from);
    if (line.compare(pos,4,"true")==0) return true;
    if (line.compare(pos,5,"false")==0) return false;
    throw std::runtime_error("invalid Boolean field: "+field);
}

std::set<Key> expected_keys(int d1,int d2,const std::string &profile) {
    if (d1>d2) std::swap(d1,d2);
    std::set<Key> out;
    if (d1==3 && d2==3) {
        const std::vector<std::string> orbits{"00","11","22","01","02","12"};
        const int maximum=cubic_profile_maximum(profile);
        for (int m=1;m<=maximum;++m) for (const auto &orbit:orbits)
            for (int eps:{-1,1}) {
                const int t=cubic_profile_twist(profile,m);
                out.insert({m,t,orbit,eps});
            }
    } else if (d1==3 && d2==4) {
        out.insert({3,3,"all",0});
    } else if (d1==2 && (d2==5 || d2==6)) {
        const std::vector<std::string> orbits=d2==5?
            std::vector<std::string>{"c0","c1","c2"}:
            std::vector<std::string>{"c0","c1","c2","c3"};
        const std::vector<std::pair<int,int>> cases=d2==5?
            std::vector<std::pair<int,int>>{{3,2},{4,2},{5,2},{6,3},{7,3},{8,3}}:
            std::vector<std::pair<int,int>>{{3,3}};
        for (const auto &[m,t]:cases)
            for (const auto &orbit:orbits) for (int eps:{-1,1})
                out.insert({m,t,orbit,eps});
    } else if (d1==1 && (d2==8 || d2==9)) {
        const std::vector<std::pair<int,int>> cases=d2==8?
            std::vector<std::pair<int,int>>{{3,2},{4,2},{5,2},{6,3},{7,3},{8,3}}:
            std::vector<std::pair<int,int>>{{3,3},{4,3}};
        for (const auto &[m,t]:cases)
            for (int character=0;character<d2;++character)
                out.insert({m,t,"c"+std::to_string(character),0});
    } else {
        throw std::runtime_error("unsupported degree pair");
    }
    return out;
}

} // namespace

int main(int argc,char **argv) {
    try {
        if (argc<5 || std::string(argv[1])!="--degrees") {
            std::cerr << "Usage: verify_finite_vanishing_certificates --degrees D1 D2 "
                         "[--profile baseline|smt57|smt27|smt38|smt23] FILE...\n";
            return 2;
        }
        int d1=std::stoi(argv[2]),d2=std::stoi(argv[3]);
        if (d1>d2) std::swap(d1,d2);
        std::string profile="baseline";
        int first_file=4;
        if (first_file<argc && std::string(argv[first_file])=="--profile") {
            if (first_file+2>=argc) throw std::runtime_error("missing profile or certificate file");
            profile=argv[first_file+1];
            first_file+=2;
        }
        if (!known_profile(profile))
            throw std::runtime_error("invalid profile");
        if (cubic_only_profile(profile) && !(d1==3 && d2==3))
            throw std::runtime_error("non-baseline profiles are cubic-only");
        warn_legacy_profile(profile);
        const auto expected=expected_keys(d1,d2,profile);
        std::map<Key,std::map<int,Fingerprint>> found;

        for (int arg=first_file;arg<argc;++arg) {
            std::ifstream input(argv[arg]);
            if (!input) throw std::runtime_error("cannot open certificate: "+std::string(argv[arg]));
            std::string line;
            bool saw_run_header=false;
            while (std::getline(input,line)) {
                if (line.find("\"kind\":\"finite-vanishing-run\"")!=
                    std::string::npos) {
                    saw_run_header=true;
                    if (d1==1 && (d2==8 || d2==9)) {
                        const std::string expected_pair=d2==8?
                            "A=Y, B=X^8+Y^8+Z^8+X^4Y^4":
                            "A=Y, B=X^9+Y^9+Z^9+X^3Y^3Z^3";
                        if (string_field(line,"version")!="2.3-degree-one-lines" ||
                            string_field(line,"test_pair")!=expected_pair ||
                            integer_field(line,"cyclic_denominator_shift")!=1 ||
                            string_field(line,"divisibility")!="separate-z-a-b")
                            throw std::runtime_error(
                                "degree-one run header does not identify the audited model");
                    }
                    continue;
                }
                if (line.find("\"kind\":\"finite-vanishing-case\"")==std::string::npos)
                    continue;
                const bool legacy_cubic=line.find("\"d1\":")==std::string::npos;
                const int ld1=legacy_cubic?3:static_cast<int>(integer_field(line,"d1"));
                const int ld2=legacy_cubic?3:static_cast<int>(integer_field(line,"d2"));
                if (ld1!=d1 || ld2!=d2) throw std::runtime_error("degree mismatch in certificate");
                const int m=static_cast<int>(integer_field(line,"m"));
                const int t=static_cast<int>(integer_field(line,"t"));
                const int prime=static_cast<int>(integer_field(line,"prime"));
                if (!true_field(line,"proved")) continue;

                std::size_t pos=0;
                while ((pos=line.find("\"character_orbit\":",pos))!=std::string::npos) {
                    const auto next=line.find("\"character_orbit\":",pos+1);
                    const std::string block=line.substr(pos,next==std::string::npos?
                        std::string::npos:next-pos);
                    const std::string orbit=string_field(block,"character_orbit");
                    const int epsilon=static_cast<int>(integer_field(block,"epsilon"));
                    if (string_field(block,"proof")!="full")
                        throw std::runtime_error("aggregator accepts only exact full-mode blocks");
                    if (!true_field(block,"proved")) {pos=(next==std::string::npos?line.size():next);continue;}
                    Fingerprint fp;
                    fp.columns=integer_field(block,"columns");
                    fp.rank=integer_field(block,"rank");
                    fp.nullity=integer_field(block,"nullity");
                    if (legacy_cubic) {
                        const std::string pivot_hash=string_field(block,"pivot_hash");
                        fp.matrix_hash="legacy-pivot:"+pivot_hash;
                        fp.echelon_hash="legacy-pivot:"+pivot_hash;
                    } else {
                        fp.matrix_hash=string_field(block,"matrix_hash");
                        fp.echelon_hash=string_field(block,"echelon_hash");
                    }
                    if (fp.columns<=0 || fp.rank!=fp.columns || fp.nullity!=0 ||
                        fp.matrix_hash.empty() || fp.echelon_hash.empty())
                        throw std::runtime_error("non-full-rank or incomplete fingerprint");
                    const Key key{m,t,orbit,epsilon};
                    auto &by_prime=found[key];
                    const auto prior=by_prime.find(prime);
                    if (prior!=by_prime.end() &&
                       (prior->second.columns!=fp.columns ||
                        prior->second.matrix_hash!=fp.matrix_hash ||
                        prior->second.echelon_hash!=fp.echelon_hash))
                        throw std::runtime_error("conflicting duplicate shard fingerprint");
                    by_prime[prime]=std::move(fp);
                    pos=(next==std::string::npos?line.size():next);
                }
            }
            if (d1==1 && (d2==8 || d2==9) && !saw_run_header)
                throw std::runtime_error("degree-one certificate lacks an audited run header");
        }

        std::vector<Key> missing;
        for (const auto &key:expected)
            if (!found.count(key) || found.at(key).empty()) missing.push_back(key);
        for (const auto &[key,primes]:found)
            if (!expected.count(key))
                throw std::runtime_error("unexpected case/block in certificate set");
        if (!missing.empty()) {
            std::cerr << "CERTIFICATE SET INCOMPLETE: " << missing.size() << " missing block(s)\n";
            for (const auto &key:missing)
                std::cerr << "  m=" << key.m << " t=" << key.t << " orbit="
                          << key.orbit << " epsilon=" << key.epsilon << '\n';
            return 1;
        }
        std::cout << "CERTIFICATE SET VERIFIED: " << expected.size()
                  << " required full-rank block(s), deterministic fingerprints present.\n";
        return 0;
    } catch (const std::exception &error) {
        std::cerr << "ERROR: " << error.what() << '\n';
        return 2;
    }
}
