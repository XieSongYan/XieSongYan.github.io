# Two-component computational evidence guide

This directory contains the standalone guide source and compiled PDF:

- `two_component_computational_evidence.tex`;
- `two_component_computational_evidence.pdf`.

The guide documents six checked proof sets:

| degrees | cases | blocks | columns | proof prime | replay prime |
|---|---:|---:|---:|---:|---:|
| `(3,3)` | 14 | 168 | 280,798 | 5 | case `(9,2)` at 7 |
| `(3,4)` | 1 | 1 | 781 | 5 | 7 |
| `(2,6)` | 1 | 8 | 1,040 | 7 | 11 |
| `(2,5)` | 6 | 36 | 38,286 | 5 | 7 |
| `(1,8)` | 6 | 48 | 67,011 | 5 | 11 |
| `(1,9)` | 2 | 18 | 5,526 | 5 | 11 |

For the degree-one cases the guide derives the valid `A=Y` SNC pairs, the integral projectively invariant logarithmic form, the layer-dependent character shift, and the separate `z/u/b_X` divisibility equations. It also explains why no obsolete `A=Z` experiment is evidence and why `(1,7)` remains an uncomputed boundary where nonvanishing may occur.

The structural checker accepted all six proof sets together with the listed independent-prime replay files. The complete cubic proof file is a source-bound run in the modern certificate schema; its exact pre-nomenclature producer is preserved under `../provenance/producer_snapshot`, and the primary release generator differs only in profile labels and documentation. Representative matrices were also reconstructed independently and compared entry by entry with the production generator; those audit sources and results are under `../independent_audit`. The PDF is compiled from the TeX file in this directory; bibliography and text are self-contained.
