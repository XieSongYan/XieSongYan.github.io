# Computation host and toolchain

## Recorded host

- Microsoft Surface Pro, 13-inch, 12th Edition;
- Snapdragon X2 Elite at 4.03 GHz, 12 physical / 12 logical cores;
- 33,823,641,600 bytes installed memory (about 31.5 GiB);
- 1 TB local storage class;
- Windows 11 Home, version/build 10.0.28000/28000, ARM64;
- x86_64 Windows proof binaries run under Windows emulation.

The degree-one calculations fit comfortably on this 32 GiB laptop. The largest `(1,8)` character block has 3,543 columns. At prime 5, the 48 recorded block times sum to 139.592 seconds and the largest block time is 14.516 seconds; parallel wall time is smaller than the sum. The two `(1,9)` cases are substantially faster. These timings are reproducibility observations, not proof data.

The cubic SMT-57 endpoint remains the dominant laptop calculation. Its largest case `(14,3)` has 76,905 columns in total, a largest block of 8,830 columns, and a largest recorded block time of 2,423.014 seconds. Monitoring observed at most 20,753,010,688 bytes of working set and 22,957,387,776 bytes of paged memory. Those are sampled maxima, not asserted final operating-system peaks. The underlying certificate files retain their historical `smt38` names.

The added conic--quintic case `(m,t)=(8,3)` was also completed on this host.
It has 15,849 columns in six independent blocks.  At prime 5 the largest
recorded block time is 1,170.066 seconds; the full-rank prime-7 replay has
largest block time 806.143 seconds.  The runs were not instrumented for a
separate peak-memory claim.

## Compiler

- LLVM-MinGW 20260616 UCRT;
- Clang 22.1.8;
- C++17;
- generator flags: `-O3 -DNDEBUG -pthread -static -Wall -Wextra -Wpedantic -Wconversion -Wshadow -Wsign-conversion`;
- checker flags: `-O2 -DNDEBUG -static` with the same warning set.

The frozen generator, structural checker, and `O(3)` identity checker were rebuilt directly from the staged sources. All three compiler invocations exited with code zero and emitted no warning. `-static` removes separate C++ runtime-library deployment; the resulting Windows binaries retain only ordinary UCRT and KERNEL32 system imports.

Self-tests pass at primes 5, 7, and 11. The degree-one test suite includes exact frame fingerprints and transformed-row character equivariance.

## Prime choices

- `(3,3)`, `(3,4)`, `(2,5)`, `(1,8)`, `(1,9)`: proof prime 5;
- `(2,6)`: proof prime 7;
- degree-one independent replay: prime 11.

Prime 7 is not degree-one evidence. The degree-nine test curve has bad reduction there, and several degree-one matrix minors also vanish modulo 7. A deficient reduction is inconclusive; full rank at primes 5 and 11 is the relevant certificate.

## Unrun boundaries

The cubic SMT-23 profile has been enumerated but is unrun. For `(1,7)`, the formal finite window contains 178 cases through `m=180`; it is deferred to a cluster and may contain genuine nonvanishing. Neither boundary belongs to this release.
