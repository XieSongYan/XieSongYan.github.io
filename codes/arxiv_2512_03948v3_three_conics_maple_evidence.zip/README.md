# Maple computational evidence for arXiv:2512.03948v3

This archive preserves the Maple worksheets and accompanying modular-computation record distributed with the authors' source package for

> Lei Hou, Dinh Tuan Huynh, Joel Merker, and Song-Yan Xie,
> *A Second Main Theorem for Entire Curves Intersecting Three Conics*,
> arXiv:2512.03948v3.

## Contents

- `inverse of Psi acts on Delta.mw`: Maple worksheet for the inverse transition calculation.
- `O(-1)7.6.mw`, `O(-2)7.6.mw`, `O(-3)7.6.mw`: Maple worksheets for the indicated twists.
- `mod-p-E-2-m-inexistence.pdf`: saved modular-computation output.

These historical Maple materials are preserved separately from the later full-coupled C++ verification. The corresponding C++ evidence archive contains its own source, executable, exact run logs, certificates, report, and SHA-256 manifest.
