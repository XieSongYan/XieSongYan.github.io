# Maple computational evidence for arXiv:2603.14881v3

This archive consolidates the saved Maple computation records distributed with the authors' source package for

> Lei Hou, Dinh Tuan Huynh, Joel Merker, and Song-Yan Xie,
> *Vanishing of Invariant 2-Jet Differentials and Improved Hyperbolicity Degree Bounds in Dimension Two*,
> arXiv:2603.14881v3.

## Contents

- `17-16-compact-7-7.pdf`: saved compact-case computation record.
- `13-12-logarithmic.pdf`: saved logarithmic-case computation record.

The individual computational files already published on the homepage remain available. This ZIP is an additional consolidated copy for convenient download and archival use.
